(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./dist/tomfism/fesm5/tomfism.js":
/*!***************************************!*\
  !*** ./dist/tomfism/fesm5/tomfism.js ***!
  \***************************************/
/*! exports provided: ButtonViewField, SelectViewField, SimulationModes, AppDataModel, AppViewModel, RoutableCmd, NonSimCmd, NonSimDirectCmd, DirectCmd, ServiceReultStates, ServiceResult, ServiceBase, TaCallerBaseService, CmdRouter, LinkCmd, LoggerService, LogAcitveVMDataModelService, LogInfoService, CheckpointService, KeyValueItem, tomException, tomMsg, BiValues, ComplexComponentBase, DateViewField, DressingSetting, DressingRule, wardrobe, FieldComponentBase, JsonProperty, tomDeserializer, SerializerSkipper, travers, TraversorOutArg, TraversorInArg, tomTraversor, CloneTraversorInArg, ViewModel, ViewField, ListDataModel, ViewListModel, ZeroFill, toString, removeFromArray, isPrimitive, isArray, NullorEmpty, EmptyString, keysOfMap, valuesOfMap, ifNull, padNumber, getUniq, AppMode, CheckPointMode, PopupDataModel, PopupViewModel, AppGlobal, AppSetting, CallItem, Tajax, TAjaxCaller, ContentTypes, LogContent, AjaxContent, CmdContent, DataModelContent, CheckPointContent, CheckResultContent, InfoContent, LogItem, tomLogger, LogItemExported, SessionExported, tomLogReader, AjaxLogReader, SessionMgr, FieldSeqPair, FiledSeqPairList, ShadowSeq, DataModelBase, LinkViewField, SimpleLinkViewField, LogDBDataModel, AutoTestResultDataModel, LogDBViewModel, CheckResultViewModel, SessionIODataModel, SessionIOViewModel, AutoTestResultViewModel, FileDataModel, FileProcessCmd, FileViewField, FileUploadDataModel, UploadCmd, FileUploadViewField, SimDataModel, SimViewModel, LogCmdBase, GetSessionCmd, SimServiceBase, getSessionsService, tomjectorParamInfo, tomjectorParamContainer, tomjectorSetting, tomjector, TomFismModule, tomfismApp, AppDIMap, ɵa */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonViewField", function() { return ButtonViewField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SelectViewField", function() { return SelectViewField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SimulationModes", function() { return SimulationModes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppDataModel", function() { return AppDataModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppViewModel", function() { return AppViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RoutableCmd", function() { return RoutableCmd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NonSimCmd", function() { return NonSimCmd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NonSimDirectCmd", function() { return NonSimDirectCmd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DirectCmd", function() { return DirectCmd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServiceReultStates", function() { return ServiceReultStates; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServiceResult", function() { return ServiceResult; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServiceBase", function() { return ServiceBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TaCallerBaseService", function() { return TaCallerBaseService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CmdRouter", function() { return CmdRouter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LinkCmd", function() { return LinkCmd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoggerService", function() { return LoggerService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogAcitveVMDataModelService", function() { return LogAcitveVMDataModelService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogInfoService", function() { return LogInfoService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckpointService", function() { return CheckpointService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KeyValueItem", function() { return KeyValueItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tomException", function() { return tomException; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tomMsg", function() { return tomMsg; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BiValues", function() { return BiValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ComplexComponentBase", function() { return ComplexComponentBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DateViewField", function() { return DateViewField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DressingSetting", function() { return DressingSetting; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DressingRule", function() { return DressingRule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "wardrobe", function() { return wardrobe; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FieldComponentBase", function() { return FieldComponentBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JsonProperty", function() { return JsonProperty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tomDeserializer", function() { return tomDeserializer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SerializerSkipper", function() { return SerializerSkipper; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "travers", function() { return travers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TraversorOutArg", function() { return TraversorOutArg; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TraversorInArg", function() { return TraversorInArg; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tomTraversor", function() { return tomTraversor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CloneTraversorInArg", function() { return CloneTraversorInArg; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewModel", function() { return ViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewField", function() { return ViewField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ListDataModel", function() { return ListDataModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewListModel", function() { return ViewListModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ZeroFill", function() { return ZeroFill; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toString", function() { return toString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeFromArray", function() { return removeFromArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isPrimitive", function() { return isPrimitive; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isArray", function() { return isArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NullorEmpty", function() { return NullorEmpty; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmptyString", function() { return EmptyString; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "keysOfMap", function() { return keysOfMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "valuesOfMap", function() { return valuesOfMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ifNull", function() { return ifNull; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "padNumber", function() { return padNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getUniq", function() { return getUniq; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppMode", function() { return AppMode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckPointMode", function() { return CheckPointMode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopupDataModel", function() { return PopupDataModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopupViewModel", function() { return PopupViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppGlobal", function() { return AppGlobal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppSetting", function() { return AppSetting; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CallItem", function() { return CallItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tajax", function() { return Tajax; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TAjaxCaller", function() { return TAjaxCaller; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentTypes", function() { return ContentTypes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogContent", function() { return LogContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AjaxContent", function() { return AjaxContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CmdContent", function() { return CmdContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataModelContent", function() { return DataModelContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckPointContent", function() { return CheckPointContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckResultContent", function() { return CheckResultContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InfoContent", function() { return InfoContent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogItem", function() { return LogItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tomLogger", function() { return tomLogger; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogItemExported", function() { return LogItemExported; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SessionExported", function() { return SessionExported; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tomLogReader", function() { return tomLogReader; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AjaxLogReader", function() { return AjaxLogReader; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SessionMgr", function() { return SessionMgr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FieldSeqPair", function() { return FieldSeqPair; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FiledSeqPairList", function() { return FiledSeqPairList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShadowSeq", function() { return ShadowSeq; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DataModelBase", function() { return DataModelBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LinkViewField", function() { return LinkViewField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SimpleLinkViewField", function() { return SimpleLinkViewField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogDBDataModel", function() { return LogDBDataModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AutoTestResultDataModel", function() { return AutoTestResultDataModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogDBViewModel", function() { return LogDBViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckResultViewModel", function() { return CheckResultViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SessionIODataModel", function() { return SessionIODataModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SessionIOViewModel", function() { return SessionIOViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AutoTestResultViewModel", function() { return AutoTestResultViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileDataModel", function() { return FileDataModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileProcessCmd", function() { return FileProcessCmd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileViewField", function() { return FileViewField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileUploadDataModel", function() { return FileUploadDataModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UploadCmd", function() { return UploadCmd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FileUploadViewField", function() { return FileUploadViewField; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SimDataModel", function() { return SimDataModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SimViewModel", function() { return SimViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogCmdBase", function() { return LogCmdBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GetSessionCmd", function() { return GetSessionCmd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SimServiceBase", function() { return SimServiceBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSessionsService", function() { return getSessionsService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tomjectorParamInfo", function() { return tomjectorParamInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tomjectorParamContainer", function() { return tomjectorParamContainer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tomjectorSetting", function() { return tomjectorSetting; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tomjector", function() { return tomjector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomFismModule", function() { return TomFismModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tomfismApp", function() { return tomfismApp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppDIMap", function() { return AppDIMap$1; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵa", function() { return TomFismComponent; });
/* harmony import */ var reflect_metadata__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! reflect-metadata */ "./node_modules/reflect-metadata/Reflect.js");
/* harmony import */ var reflect_metadata__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(reflect_metadata__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");








/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @param {?} num
 * @param {?} len
 * @return {?}
 */
function ZeroFill(num, len) { return (Array(len).join("0") + num).slice(-len); }
/**
 * @param {?} value
 * @return {?}
 */
function toString(value) {
    if (value == null || value == undefined)
        return null;
    else
        return value.toString();
}
/**
 * @param {?} ArrayList
 * @param {?} item
 * @return {?}
 */
function removeFromArray(ArrayList, item) {
    ArrayList.forEach(function (value, index) {
        if (value === item)
            ArrayList.splice(index, 1);
    });
}
/**
 * @param {?} obj
 * @return {?}
 */
function isPrimitive(obj) {
    switch (typeof obj) {
        case "string":
        case "number":
        case "boolean":
            return true;
    }
    return !!(obj instanceof String || obj === String ||
        obj instanceof Number || obj === Number ||
        obj instanceof Boolean || obj === Boolean);
}
/**
 * @param {?} object
 * @return {?}
 */
function isArray(object) {
    if (object === Array) {
        return true;
    }
    else if (typeof Array.isArray === "function") {
        return Array.isArray(object);
    }
    else {
        return !!(object instanceof Array);
    }
}
/** @enum {number} */
var AppMode = {
    debug: 0,
    production: 1,
};
AppMode[AppMode.debug] = 'debug';
AppMode[AppMode.production] = 'production';
/** @enum {number} */
var CheckPointMode = {
    none: 0,
    CheckPointLogging: 1,
    CheckPointCompare: 2,
};
CheckPointMode[CheckPointMode.none] = 'none';
CheckPointMode[CheckPointMode.CheckPointLogging] = 'CheckPointLogging';
CheckPointMode[CheckPointMode.CheckPointCompare] = 'CheckPointCompare';
/**
 * @param {?} obj
 * @return {?}
 */
function NullorEmpty(obj) {
    return (obj == null || obj == undefined);
}
/**
 * @param {?} s
 * @return {?}
 */
function EmptyString(s) {
    if (NullorEmpty(s))
        return true;
    else
        return s.trim() === "";
}
/**
 * @template T
 * @param {?} sourceMap
 * @return {?}
 */
function keysOfMap(sourceMap) {
    /** @type {?} */
    var keys = [];
    sourceMap.forEach(function (value, key) {
        keys.push(key);
    });
    return keys;
}
/**
 * @template T
 * @param {?} sourceMap
 * @return {?}
 */
function valuesOfMap(sourceMap) {
    /** @type {?} */
    var values = [];
    sourceMap.forEach(function (value, key) {
        values.push(value);
    });
    return values;
}
/**
 * @param {?} inputObj
 * @param {?} otherwise
 * @return {?}
 */
function ifNull(inputObj, otherwise) {
    if (NullorEmpty(inputObj)) {
        return otherwise;
    }
    else {
        return inputObj;
    }
}
/**
 * @param {?} value
 * @param {?=} length
 * @return {?}
 */
function padNumber(value, length) {
    if (length === void 0) { length = 2; }
    return ("0" + value).slice(-length);
}
/**
 * @template T
 * @param {?} arr
 * @return {?}
 */
function getUniq(arr) {
    /** @type {?} */
    var uniqueSessions = Array.from(new Set(arr.map(function (item) { return item; })));
    return uniqueSessions;
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var KeyValueItem = /** @class */ (function () {
    function KeyValueItem() {
    }
    /**
     * @param {?} key
     * @param {?} value
     * @return {?}
     */
    KeyValueItem.build = /**
     * @param {?} key
     * @param {?} value
     * @return {?}
     */
    function (key, value) {
        /** @type {?} */
        var b = new KeyValueItem();
        b.key = key;
        b.value = value;
        return b;
    };
    /**
     * @param {?} CodeTableItem
     * @return {?}
     */
    KeyValueItem.buildFromCode = /**
     * @param {?} CodeTableItem
     * @return {?}
     */
    function (CodeTableItem) {
        return KeyValueItem.build(CodeTableItem.Code, CodeTableItem.Description);
    };
    /**
     * @param {?} CodeList
     * @return {?}
     */
    KeyValueItem.buildKeyValueFromCodeTableList = /**
     * @param {?} CodeList
     * @return {?}
     */
    function (CodeList) {
        return CodeList.map(function (item) { return KeyValueItem.buildFromCode(item); });
    };
    return KeyValueItem;
}());
var tomException = /** @class */ (function () {
    function tomException() {
    }
    /**
     * @return {?}
     */
    tomException.prototype.toString = /**
     * @return {?}
     */
    function () {
        return this.msg;
    };
    /**
     * @param {?} msg
     * @param {?=} attachedObj
     * @return {?}
     */
    tomException.build = /**
     * @param {?} msg
     * @param {?=} attachedObj
     * @return {?}
     */
    function (msg, attachedObj) {
        if (attachedObj === void 0) { attachedObj = null; }
        /** @type {?} */
        var b = new tomException();
        b.msg = msg;
        b.attachedObj = attachedObj;
        console.log(b);
        return b;
    };
    return tomException;
}());
var tomMsg = /** @class */ (function () {
    function tomMsg() {
        this.MsgId = null;
        this.content = null;
    }
    /**
     * @return {?}
     */
    tomMsg.prototype.Message = /**
     * @return {?}
     */
    function () {
        return this.content;
    };
    /**
     * @template T
     * @param {?} ctor
     * @param {?} MsgId
     * @param {?} content
     * @param {?=} initializor
     * @return {?}
     */
    tomMsg.createMsg = /**
     * @template T
     * @param {?} ctor
     * @param {?} MsgId
     * @param {?} content
     * @param {?=} initializor
     * @return {?}
     */
    function (ctor, MsgId, content, initializor) {
        if (initializor === void 0) { initializor = null; }
        /** @type {?} */
        var b = new ctor();
        b.MsgId = MsgId;
        b.content = content;
        if (!NullorEmpty(initializor))
            initializor(b);
        return b;
    };
    return tomMsg;
}());
/**
 * @template K, T
 */
var  /**
 * @template K, T
 */
BiValues = /** @class */ (function () {
    function BiValues(key, value) {
        this.key = key;
        this.value = value;
    }
    return BiValues;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @enum {string} */
var ContentTypes = {
    cmd: "cmd",
    DataModel: "DataModel",
    ajax: "ajax",
    CheckPoint: "CheckPoint",
    CheckResult: "CheckResult",
    info: "info",
};
var LogContent = /** @class */ (function () {
    function LogContent() {
    }
    return LogContent;
}());
var AjaxContent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(AjaxContent, _super);
    function AjaxContent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ContentType = ContentTypes.ajax;
        _this.ServiceName = null;
        return _this;
    }
    /**
     * @param {?} ajax
     * @param {?} ServiceName
     * @return {?}
     */
    AjaxContent.build = /**
     * @param {?} ajax
     * @param {?} ServiceName
     * @return {?}
     */
    function (ajax, ServiceName) {
        /** @type {?} */
        var b = new AjaxContent();
        b.content = ajax;
        b.time = new Date();
        b.ServiceName = ServiceName;
        return b;
    };
    return AjaxContent;
}(LogContent));
var CmdContent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(CmdContent, _super);
    function CmdContent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ContentType = ContentTypes.cmd;
        return _this;
    }
    /**
     * @param {?} cmd
     * @return {?}
     */
    CmdContent.build = /**
     * @param {?} cmd
     * @return {?}
     */
    function (cmd) {
        /** @type {?} */
        var b = new CmdContent();
        b.content = cmd;
        b.time = new Date();
        return b;
    };
    return CmdContent;
}(LogContent));
var DataModelContent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(DataModelContent, _super);
    function DataModelContent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ContentType = ContentTypes.DataModel;
        return _this;
    }
    /**
     * @param {?} content
     * @return {?}
     */
    DataModelContent.build = /**
     * @param {?} content
     * @return {?}
     */
    function (content) {
        /** @type {?} */
        var b = new DataModelContent();
        b.content = content;
        b.time = new Date();
        return b;
    };
    return DataModelContent;
}(LogContent));
var CheckPointContent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(CheckPointContent, _super);
    function CheckPointContent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ContentType = ContentTypes.CheckPoint;
        return _this;
    }
    /**
     * @param {?} content
     * @param {?} CheckPointName
     * @return {?}
     */
    CheckPointContent.build = /**
     * @param {?} content
     * @param {?} CheckPointName
     * @return {?}
     */
    function (content, CheckPointName) {
        /** @type {?} */
        var b = new CheckPointContent();
        b.content = content;
        b.CheckPointName = CheckPointName;
        b.time = new Date();
        return b;
    };
    return CheckPointContent;
}(LogContent));
var CheckResultContent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(CheckResultContent, _super);
    function CheckResultContent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ContentType = ContentTypes.CheckResult;
        _this.isResultMatch = true;
        return _this;
    }
    /**
     * @param {?} init
     * @return {?}
     */
    CheckResultContent.build = /**
     * @param {?} init
     * @return {?}
     */
    function (init) {
        /** @type {?} */
        var b = new CheckResultContent();
        Object.assign(b, init);
        return b;
    };
    return CheckResultContent;
}(LogContent));
var InfoContent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(InfoContent, _super);
    function InfoContent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ContentType = ContentTypes.info;
        _this.desc = null;
        return _this;
    }
    /**
     * @param {?} init
     * @return {?}
     */
    InfoContent.build = /**
     * @param {?} init
     * @return {?}
     */
    function (init) {
        /** @type {?} */
        var b = new InfoContent();
        Object.assign(b, init);
        return b;
    };
    return InfoContent;
}(LogContent));
/**
 * @template T
 */
var  /**
 * @template T
 */
LogItem = /** @class */ (function () {
    function LogItem(content) {
        this.content = content;
        this.Session = AppGlobal.session;
        switch (content.ContentType) {
            case ContentTypes.ajax:
                this.seq = AppGlobal.NextAjaxSeq;
                break;
            case ContentTypes.cmd:
                this.seq = AppGlobal.NextCmdSeq;
                break;
            case ContentTypes.DataModel:
                this.seq = AppGlobal.NextDataSeq;
                break;
            case ContentTypes.CheckPoint:
                this.seq = AppGlobal.CheckPointSeq;
                break;
            case ContentTypes.CheckResult:
                this.seq = AppGlobal.CheckResultSeq;
                break;
            case ContentTypes.info:
                this.seq = AppGlobal.InfSeq;
                break;
            default:
                throw tomException.build("unexpected ContentType : " + content.ContentType, { source: this.constructor.name });
        }
    }
    Object.defineProperty(LogItem.prototype, "ItemKey", {
        get: /**
         * @return {?}
         */
        function () {
            return this.content.ContentType + "_" + this.Session + "_" + this.seq;
        },
        enumerable: true,
        configurable: true
    });
    return LogItem;
}());
var tomLogger = /** @class */ (function () {
    function tomLogger() {
    }
    /**
     * @template T
     * @param {?} logItem
     * @return {?}
     */
    tomLogger.prototype.log = /**
     * @template T
     * @param {?} logItem
     * @return {?}
     */
    function (logItem) {
        localStorage.setItem(logItem.ItemKey, JSON.stringify(logItem.content));
    };
    return tomLogger;
}());
var LogItemExported = /** @class */ (function () {
    function LogItemExported(itemKey, itemContent) {
        this.itemKey = itemKey;
        this.itemContent = itemContent;
    }
    return LogItemExported;
}());
var SessionExported = /** @class */ (function () {
    function SessionExported(session, logItems) {
        this.session = session;
        this.logItems = logItems;
    }
    return SessionExported;
}());
/**
 * @template T
 */
var  /**
 * @template T
 */
tomLogReader = /** @class */ (function () {
    function tomLogReader(ctor) {
        this.ContentType = null;
        this.runningSeq = null;
        this.CurrentSession = null;
        /** @type {?} */
        var b = new ctor();
        this.ContentType = b.ContentType;
    }
    /**
     * @param {?} session
     * @param {?} seq
     * @return {?}
     */
    tomLogReader.prototype.itemKey = /**
     * @param {?} session
     * @param {?} seq
     * @return {?}
     */
    function (session, seq) {
        return this.ContentType + "_" + session + "_" + seq;
    };
    /**
     * @param {?} session
     * @param {?} seq
     * @return {?}
     */
    tomLogReader.prototype.read = /**
     * @param {?} session
     * @param {?} seq
     * @return {?}
     */
    function (session, seq) {
        /** @type {?} */
        var key = this.itemKey(session, seq);
        /** @type {?} */
        var s = localStorage.getItem(key);
        if (EmptyString(s)) {
            console.log("LogItem not found : key = " + key);
            return null;
        }
        /** @type {?} */
        var content = JSON.parse(s);
        // console.log ( "log content");
        // console.log ( content);
        return content;
    };
    Object.defineProperty(tomLogReader.prototype, "FullLogs", {
        get: /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (NullorEmpty(this.CurrentSession)) {
                return [];
            }
            /** @type {?} */
            var keys = this.StorageKeys.filter(function (key) { return key.split("_")[1] == _this.CurrentSession; });
            /** @type {?} */
            var logs = keys.map(function (key) { return JSON.parse(localStorage[key]); });
            return logs;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(tomLogReader.prototype, "StorageKeys", {
        get: /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var keys = Array.apply(0, new Array(localStorage.length)).map(function (o, i) { return localStorage.key(i); }).filter(function (value) { return value.startsWith(_this.ContentType + "_"); });
            return keys;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(tomLogReader.prototype, "SeqsOfCurrentSession", {
        get: /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (NullorEmpty(this.CurrentSession)) {
                return [];
            }
            /** @type {?} */
            var seqs = this.StorageKeys.filter(function (key) { return key.split("_")[1] == _this.CurrentSession; }).map(function (key) { return key.split("_")[2]; });
            return seqs;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(tomLogReader.prototype, "AllSessions", {
        get: /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var sessions = this.StorageKeys.map(function (o, i) { return o.split("_")[1]; });
            return sessions;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(tomLogReader.prototype, "MaxSession", {
        get: /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var maxNo = Math.max.apply(Math, this.AllSessions);
            return padNumber(maxNo, 8);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(tomLogReader.prototype, "hasNextSeq", {
        get: /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var logContent = this.read(this.CurrentSession, this.runningSeq + 1);
            return logContent != null;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    tomLogReader.prototype.reset = /**
     * @return {?}
     */
    function () {
        this.CurrentSession = null;
        this.runningSeq = null;
    };
    Object.defineProperty(tomLogReader.prototype, "readInitialted", {
        get: /**
         * @return {?}
         */
        function () {
            return !NullorEmpty(this.CurrentSession);
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @param {?} CurrentSession
     * @return {?}
     */
    tomLogReader.prototype.initRead = /**
     * @param {?} CurrentSession
     * @return {?}
     */
    function (CurrentSession) {
        this.runningSeq = -1;
        this.CurrentSession = CurrentSession;
        return (this.hasNextSeq);
    };
    /**
     * @param {?=} ServiceName
     * @return {?}
     */
    tomLogReader.prototype.readNext = /**
     * @param {?=} ServiceName
     * @return {?}
     */
    function (ServiceName) {
        this.runningSeq++;
        return this.read(this.CurrentSession, this.runningSeq);
    };
    return tomLogReader;
}());
var AjaxLogReader = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(AjaxLogReader, _super);
    // Seq can deviate +-  within range , in the same session but should be same servicne name,
    function AjaxLogReader(SeqDeviationRange) {
        var _this = _super.call(this, AjaxContent) || this;
        _this.SeqDeviationRange = SeqDeviationRange;
        return _this;
    }
    // ReadService (  session: string, seq: number, ServiceName: string  ): AjaxContent{
    //     for ( let i:number = 0; i < this.SeqDeviationRange ; i ++){
    //             for ( let  sign  of [-1, 1] ){
    //                 let content = this.read ( session, seq + i * sign);
    //                 if ( content.ServiceName = ServiceName )
    //                     return content;
    //             }
    //     }
    //     return null;
    // }
    // ReadService (  session: string, seq: number, ServiceName: string  ): AjaxContent{
    //     for ( let i:number = 0; i < this.SeqDeviationRange ; i ++){
    //             for ( let  sign  of [-1, 1] ){
    //                 let content = this.read ( session, seq + i * sign);
    //                 if ( content.ServiceName = ServiceName )
    //                     return content;
    //             }
    //     }
    //     return null;
    // }
    /**
     * @param {?=} ServiceName
     * @return {?}
     */
    AjaxLogReader.prototype.readNext = 
    // ReadService (  session: string, seq: number, ServiceName: string  ): AjaxContent{
    //     for ( let i:number = 0; i < this.SeqDeviationRange ; i ++){
    //             for ( let  sign  of [-1, 1] ){
    //                 let content = this.read ( session, seq + i * sign);
    //                 if ( content.ServiceName = ServiceName )
    //                     return content;
    //             }
    //     }
    //     return null;
    // }
    /**
     * @param {?=} ServiceName
     * @return {?}
     */
    function (ServiceName) {
        var e_1, _a;
        /** @type {?} */
        var seq = this.runningSeq;
        this.runningSeq++;
        for (var i = 0; i < this.SeqDeviationRange; i++) {
            try {
                for (var _b = Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__values"])([-1, 1]), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var sign = _c.value;
                    /** @type {?} */
                    var content = this.read(this.CurrentSession, seq + i * sign);
                    if (!NullorEmpty(content) && content.ServiceName == ServiceName) {
                        //console.log ( ServiceName);
                        //console.log ( content);
                        return content;
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
        }
        return null;
    };
    return AjaxLogReader;
}(tomLogReader));
var SessionMgr = /** @class */ (function () {
    function SessionMgr() {
    }
    Object.defineProperty(SessionMgr.prototype, "sessions", {
        get: /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var sessions = this.StorageKeys.filter(function (o, i) { return o.split("_").length > 2; })
                .map(function (o, i) { return o.split("_")[1]; });
            return getUniq(sessions);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionMgr.prototype, "StorageKeys", {
        get: /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var keys = Array.apply(0, new Array(localStorage.length)).map(function (o, i) { return localStorage.key(i); });
            return keys;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionMgr.prototype, "FullExportLogItems", {
        get: /**
         * @return {?}
         */
        function () {
            var _this = this;
            if (NullorEmpty(this.CurrentSession)) {
                return [];
            }
            /** @type {?} */
            var keys = this.StorageKeys.filter(function (key) { return key.split("_")[1] == _this.CurrentSession; });
            /** @type {?} */
            var logs = keys.map(function (key) { return new LogItemExported(key, JSON.parse(localStorage[key])); });
            return logs;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionMgr.prototype, "FullExportSession", {
        get: /**
         * @return {?}
         */
        function () {
            return new SessionExported(this.CurrentSession, this.FullExportLogItems);
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @param {?} sessionExported
     * @return {?}
     */
    SessionMgr.prototype.importSession = /**
     * @param {?} sessionExported
     * @return {?}
     */
    function (sessionExported) {
        sessionExported.logItems.forEach(function (log) { return localStorage.setItem(log.itemKey, JSON.stringify(log.itemContent)); });
    };
    return SessionMgr;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var AppGlobal = /** @class */ (function () {
    function AppGlobal() {
    }
    Object.defineProperty(AppGlobal, "appData", {
        //private static _UniqNo: number = 0;
        get: 
        //private static _UniqNo: number = 0;
        /**
         * @return {?}
         */
        function () {
            return AppGlobal.appViewModel.dataModel;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppGlobal, "NextUniqNo", {
        get: /**
         * @return {?}
         */
        function () {
            return AppGlobal.appViewModel.dataModel.UniqNo++;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppGlobal, "session", {
        //private static _session : string = null;
        get: 
        //private static _session : string = null;
        /**
         * @return {?}
         */
        function () {
            if (AppGlobal.appData.session == null) {
                /** @type {?} */
                var d = new Date();
                AppGlobal.appData.session = padNumber(d.getMonth()) +
                    padNumber(d.getDate()) +
                    padNumber(d.getHours()) +
                    padNumber(d.getMinutes());
            }
            return AppGlobal.appData.session;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppGlobal, "NextAjaxSeq", {
        //    private static _AjaxSeq : number = 0;
        get: 
        //    private static _AjaxSeq : number = 0;
        /**
         * @return {?}
         */
        function () {
            return AppGlobal.appData.AjaxSeq++;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppGlobal, "NextCmdSeq", {
        //private static _CmdSeq : number = 0;
        get: 
        //private static _CmdSeq : number = 0;
        /**
         * @return {?}
         */
        function () {
            return AppGlobal.appData.CmdSeq++;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppGlobal, "NextDataSeq", {
        //private static _DataSeq : number = 0;
        get: 
        //private static _DataSeq : number = 0;
        /**
         * @return {?}
         */
        function () {
            return AppGlobal.appData.DataSeq++;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppGlobal, "CheckPointSeq", {
        //private static _CheckPointSeq : number = 0;
        get: 
        //private static _CheckPointSeq : number = 0;
        /**
         * @return {?}
         */
        function () {
            return AppGlobal.appData.CheckPointSeq++;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppGlobal, "CheckResultSeq", {
        //private static _CheckResultSeq : number = 0;
        get: 
        //private static _CheckResultSeq : number = 0;
        /**
         * @return {?}
         */
        function () {
            return AppGlobal.appData.CheckResultSeq++;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppGlobal, "InfSeq", {
        //private static _InfoSeq : number = 0;
        get: 
        //private static _InfoSeq : number = 0;
        /**
         * @return {?}
         */
        function () {
            return AppGlobal.appData.InfoSeq++;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppGlobal, "setting", {
        get: /**
         * @return {?}
         */
        function () {
            return AppGlobal._setting;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (AppGlobal._setting == undefined)
                AppGlobal._setting = value;
            else
                throw "AppGlobal values should be singuleton and shold not set twice";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppGlobal, "url", {
        get: /**
         * @return {?}
         */
        function () {
            return AppGlobal._url;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (AppGlobal._url == undefined)
                AppGlobal._url = value;
            else
                throw "AppGlobal values should be singuleton and shold not set twice";
        },
        enumerable: true,
        configurable: true
    });
    AppGlobal.isLoading = false;
    AppGlobal.appMode = AppMode.debug;
    AppGlobal.injector = null;
    AppGlobal._setting = undefined;
    AppGlobal._url = undefined;
    AppGlobal.AjaxLogReader = new AjaxLogReader(4);
    AppGlobal.isAjaxLogging = false;
    AppGlobal.isReplaying = false;
    AppGlobal.simLatency = 2000;
    AppGlobal.checkPointReader = new tomLogReader(CheckPointContent);
    AppGlobal.checkPointMode = CheckPointMode.none;
    AppGlobal.DIMap = new Map();
    return AppGlobal;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var tomjectorParamInfo = /** @class */ (function () {
    function tomjectorParamInfo() {
    }
    return tomjectorParamInfo;
}());
var tomjectorParamContainer = /** @class */ (function () {
    function tomjectorParamContainer() {
        this.firstParam = null;
        this.paramInfo = null;
    }
    return tomjectorParamContainer;
}());
var tomjectorSetting = /** @class */ (function () {
    function tomjectorSetting(id, ctro) {
        this.id = null;
        this.id = id;
        this.ctro = ctro;
    }
    return tomjectorSetting;
}());
var tomjector = /** @class */ (function () {
    function tomjector() {
    }
    /**
     * @param {?} id
     * @param {?} firstParam
     * @param {?=} paramInfo
     * @return {?}
     */
    tomjector.create = /**
     * @param {?} id
     * @param {?} firstParam
     * @param {?=} paramInfo
     * @return {?}
     */
    function (id, firstParam, paramInfo) {
        if (paramInfo === void 0) { paramInfo = null; }
        /** @type {?} */
        var jectorSetting = AppGlobal.DIMap[id];
        //console.log ( id);
        //console.log ( firstParam);
        //console.log ( paramInfo);
        if (NullorEmpty(jectorSetting)) {
            throw tomException.build("injector id not found in DIMaop : " + id + " ");
        }
        /** @type {?} */
        var paramContainer = new tomjectorParamContainer();
        paramContainer.firstParam = firstParam;
        if (paramInfo != null) {
            paramContainer.paramInfo = paramInfo;
            //console.log ( paramInfo);
        }
        /** @type {?} */
        var b = jectorSetting.ctro(paramContainer);
        if (id == "ButtonViewField") {
            console.log("butterrr");
            console.log(b);
        }
        return b;
    };
    return tomjector;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
var jsonMetadataKey = "jsonProperty";
/**
 * @template T
 * @param {?=} metadata
 * @return {?}
 */
function JsonProperty(metadata) {
    //console.log (metadata);
    if (metadata instanceof String || typeof metadata === "string") {
        return Reflect.metadata(jsonMetadataKey, {
            name: metadata,
            clazz: undefined
        });
    }
    else {
        /** @type {?} */
        var metadataObj = (/** @type {?} */ (metadata));
        return Reflect.metadata(jsonMetadataKey, {
            name: metadataObj ? metadataObj.name : undefined,
            clazz: metadataObj ? metadataObj.clazz : undefined,
            jsonTypeField: metadataObj ? metadataObj.jsonTypeField : undefined
        });
    }
}
/**
 * @param {?} target
 * @param {?} propertyKey
 * @return {?}
 */
function getClazz(target, propertyKey) {
    return Reflect.getMetadata("design:type", target, propertyKey);
}
/**
 * @template T
 * @param {?} target
 * @param {?} propertyKey
 * @return {?}
 */
function getJsonProperty(target, propertyKey) {
    return Reflect.getMetadata(jsonMetadataKey, target, propertyKey);
}
var tomDeserializer = /** @class */ (function () {
    function tomDeserializer() {
        this.CtorMap = new Map();
    }
    /**
     * @param {?} obj
     * @return {?}
     */
    tomDeserializer.prototype.isPrimitive = /**
     * @param {?} obj
     * @return {?}
     */
    function (obj) {
        switch (typeof obj) {
            case "string":
            case "number":
            case "boolean":
                return true;
        }
        return !!(obj instanceof String || obj === String ||
            obj instanceof Number || obj === Number ||
            obj instanceof Boolean || obj === Boolean);
    };
    /**
     * @param {?} object
     * @return {?}
     */
    tomDeserializer.prototype.isArray = /**
     * @param {?} object
     * @return {?}
     */
    function (object) {
        if (object === Array) {
            return true;
        }
        else if (typeof Array.isArray === "function") {
            return Array.isArray(object);
        }
        else {
            return !!(object instanceof Array);
        }
    };
    /**
     * @param {?} metadata
     * @param {?} jsonObject
     * @param {?} defaultClazz
     * @return {?}
     */
    tomDeserializer.prototype.getClazzFromJson = /**
     * @param {?} metadata
     * @param {?} jsonObject
     * @param {?} defaultClazz
     * @return {?}
     */
    function (metadata, jsonObject, defaultClazz) {
        //return defaultClazz;
        if (metadata == undefined || metadata.jsonTypeField == undefined)
            return defaultClazz;
        /** @type {?} */
        var TypeKey = jsonObject[metadata.jsonTypeField];
        if (TypeKey == undefined) {
            console.log(jsonObject);
            throw "type key not found in json : " + metadata.jsonTypeField;
        }
        //throw "type key not found in json :";
        //throw { msg : "type key not found in json :", key : metadata.jsonTypeField, json:  jsonObject };
        /** @type {?} */
        var ctor = this.CtorMap.get(TypeKey);
        if (ctor == undefined)
            throw "costructor not found in CtorMap for : " + TypeKey;
        return ctor;
        //return metadata.clazz;
    };
    /**
     * @param {?} propertyMetadata
     * @param {?} jsonObject
     * @param {?} targetObj
     * @param {?} clazzKey
     * @return {?}
     */
    tomDeserializer.prototype.deserializeByMetadata = /**
     * @param {?} propertyMetadata
     * @param {?} jsonObject
     * @param {?} targetObj
     * @param {?} clazzKey
     * @return {?}
     */
    function (propertyMetadata, jsonObject, targetObj, clazzKey) {
        var _this = this;
        /** @type {?} */
        var propertyName = propertyMetadata.name || clazzKey;
        /** @type {?} */
        var innerJson = jsonObject ? jsonObject[propertyName] : undefined;
        //console.log ( targetObj);
        /** @type {?} */
        var metadata = getJsonProperty(targetObj, clazzKey);
        //let targetClazz = this.getClazzFromJson( metadata, jsonObject);
        /** @type {?} */
        var clazz = getClazz(targetObj, clazzKey);
        if (this.isArray(clazz)) {
            //console.log(metadata);
            if (metadata.clazz || metadata.jsonTypeField || this.isPrimitive(clazz)) {
                //console.log ("array");
                //console.log ( innerJson);
                if (innerJson && this.isArray(innerJson)) {
                    //.console.log ( metadata);
                    return innerJson.map(function (item) { return _this.deserialize(_this.getClazzFromJson(metadata, item, metadata.clazz), item); }
                    //(item)=> this.deserialize( metadata.clazz, item)
                    );
                }
                else {
                    return undefined;
                }
            }
            else {
                return innerJson;
            }
        }
        else if (!this.isPrimitive(clazz)) {
            return this.deserialize(this.getClazzFromJson(metadata, innerJson, clazz), innerJson);
            //return this.deserialize( clazz, innerJson);            
        }
        else {
            return jsonObject ? jsonObject[propertyName] : undefined;
        }
    };
    /**
     * @template T
     * @param {?} clazz
     * @param {?} jsonObject
     * @return {?}
     */
    tomDeserializer.prototype.deserialize = /**
     * @template T
     * @param {?} clazz
     * @param {?} jsonObject
     * @return {?}
     */
    function (clazz, jsonObject) {
        var _this = this;
        if ((clazz === undefined) || (jsonObject === undefined))
            return undefined;
        /** @type {?} */
        var targetObj = new clazz();
        /** @type {?} */
        var DIid = targetObj.constructor.name;
        if (!NullorEmpty(AppGlobal.DIMap[DIid])) {
            targetObj = tomjector.create(DIid, null);
            console.log("DI id == " + DIid);
        }
        Object.keys(jsonObject).forEach(function (jKey) {
            // special handling for fields e.g. @type
            if (jKey.startsWith("@")) {
                /** @type {?} */
                var atValue = jsonObject[jKey];
                //console.log ( atType);
                if (atValue != undefined) {
                    targetObj[jKey] = atValue;
                }
            }
        });
        Object.keys(targetObj).forEach(function (clazzKey) {
            /** @type {?} */
            var propertyMetadata = getJsonProperty(targetObj, clazzKey);
            if (propertyMetadata) {
                targetObj[clazzKey] = _this.deserializeByMetadata(propertyMetadata, jsonObject, targetObj, clazzKey);
            }
            else {
                if (jsonObject && jsonObject[clazzKey] !== undefined) {
                    targetObj[clazzKey] = jsonObject[clazzKey];
                }
            }
            // console.log(key);
            // console.log ( jsonObject[key] );
        });
        return targetObj;
    };
    /**
     * @template T
     * @param {?} clazz
     * @param {?} json
     * @return {?}
     */
    tomDeserializer.desrial = /**
     * @template T
     * @param {?} clazz
     * @param {?} json
     * @return {?}
     */
    function (clazz, json) {
        /** @type {?} */
        var deserializer = new tomDeserializer();
        /** @type {?} */
        var r = deserializer.deserialize(clazz, json);
        return r;
    };
    return tomDeserializer;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
// export class ConditionalDressing
// {
//     condition : () => boolean;
//     dressing : () => void ;    
// }
var  
// export class ConditionalDressing
// {
//     condition : () => boolean;
//     dressing : () => void ;    
// }
DressingSetting = /** @class */ (function () {
    function DressingSetting() {
        this.SettingName = null;
        this.TargetPath = null;
        this.ConditonalStatus = null;
        this.StatusValue = null;
        this.TargetBehavior = null;
        this.TargetValue = null;
        this.PathTailOnly = false;
    }
    /**
     * @param {?} json
     * @return {?}
     */
    DressingSetting.deserialize = /**
     * @param {?} json
     * @return {?}
     */
    function (json) {
        /** @type {?} */
        var deserializer = new tomDeserializer();
        /** @type {?} */
        var settings = json.map(function (v) { return deserializer.deserialize(DressingSetting, v); });
        return settings;
    };
    return DressingSetting;
}());
var DressingRule = /** @class */ (function () {
    function DressingRule() {
    }
    /**
     * @param {?} ruleName
     * @param {?} rule
     * @param {?} TargetValue
     * @return {?}
     */
    DressingRule.build = /**
     * @param {?} ruleName
     * @param {?} rule
     * @param {?} TargetValue
     * @return {?}
     */
    function (ruleName, rule, TargetValue) {
        /** @type {?} */
        var b = new DressingRule();
        b.ruleName = ruleName;
        b.rule = rule;
        b.TargetValue = TargetValue;
        return b;
    };
    /**
     * @param {?} ModelPath
     * @param {?} setting
     * @return {?}
     */
    DressingRule.comparePath = /**
     * @param {?} ModelPath
     * @param {?} setting
     * @return {?}
     */
    function (ModelPath, setting) {
        if (NullorEmpty(setting.TargetPath))
            return false;
        if (ModelPath == setting.TargetPath)
            return true;
        if (setting.PathTailOnly) {
            if (setting.TargetPath.length <= ModelPath.length) {
                /** @type {?} */
                var startPos = ModelPath.length - setting.TargetPath.length;
                /** @type {?} */
                var modelTail = ModelPath.substring(startPos);
                return modelTail == setting.TargetPath;
            }
        }
        return false;
    };
    return DressingRule;
}());
var wardrobe = /** @class */ (function () {
    function wardrobe() {
        this.rules = [];
    }
    /**
     * @return {?}
     */
    wardrobe.prototype.pickDress = /**
     * @return {?}
     */
    function () {
        var e_1, _a;
        try {
            for (var _b = Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__values"])(this.rules), _c = _b.next(); !_c.done; _c = _b.next()) {
                var rule = _c.value;
                if (rule.rule()) {
                    return rule.TargetValue;
                }
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            }
            finally { if (e_1) throw e_1.error; }
        }
        return this.defaultValue();
    };
    /**
     * @param {?} defaultValue
     * @return {?}
     */
    wardrobe.build = /**
     * @param {?} defaultValue
     * @return {?}
     */
    function (defaultValue) {
        /** @type {?} */
        var b = new wardrobe();
        b.defaultValue = defaultValue;
        return b;
    };
    return wardrobe;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ViewField = /** @class */ (function () {
    function ViewField(vfParam) {
        var _this = this;
        this.getViewModel = null;
        this.getDataModel = null;
        //visibleRules : ( () => boolean | null) [] = [];
        this.visibleWardrobe = null;
        this.editableWardrobe = null;
        //FieldType : string = "text"
        this.validators = [];
        this.VirtualFieldComponent = null;
        //markClean : () => void = null;
        //forceValidation : () => void = null;
        this.ErrorMsgMap = new Map();
        this.fieldName = vfParam.fieldName;
        this.getViewModel = vfParam.getViewModel;
        this.getDataModel = ifNull(vfParam.getDataModel, function () { return _this.getViewModel().dataModel; });
        this.getFieldValue = ifNull(vfParam.getFieldValue, function () { return _this.getDataModel()[_this.fieldName]; });
        this.setFieldValue = ifNull(vfParam.setFieldValue, function (value) { return _this.getDataModel()[_this.fieldName] = value; });
        this.getVisible = vfParam.getVisible;
        this.getEditable = vfParam.getEditable;
        this.validators = vfParam.validators;
        this.createErrorMsgMap();
        this.visibleWardrobe = wardrobe.build(function () { return _this.getViewModel().visibleWardrobe.defaultValue(); });
        this.editableWardrobe = wardrobe.build(function () { return _this.getViewModel().editableWardrobe.defaultValue(); });
    }
    Object.defineProperty(ViewField.prototype, "showErrorMsg", {
        get: /**
         * @return {?}
         */
        function () {
            return this.getViewModel().showErrorMsg;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewField.prototype, "FieldPath", {
        get: /**
         * @return {?}
         */
        function () {
            //console.log ( this.getViewModel().getModelPath() + "." + this.fieldName );
            return (this.getViewModel().getModelPath() + "." + this.fieldName);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewField.prototype, "visible", {
        get: /**
         * @return {?}
         */
        function () {
            if (!NullorEmpty(this.getVisible) && !this.getVisible())
                return false;
            /** @type {?} */
            var byRules = this.visibleWardrobe.rules.filter(function (r) { return r.rule(); }).map(function (d) { return d.TargetValue; });
            if (byRules.length > 0) {
                return byRules[0];
            }
            else
                return true;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewField.prototype, "editable", {
        get: /**
         * @return {?}
         */
        function () {
            if (!NullorEmpty(this.getEditable) && !this.getEditable())
                return false;
            /** @type {?} */
            var byRules = this.editableWardrobe.rules.filter(function (r) { return r.rule(); }).map(function (d) { return d.TargetValue; });
            if (byRules.length > 0) {
                return byRules[0];
            }
            return this.getViewModel().editable;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewField.prototype, "FieldValue", {
        get: /**
         * @return {?}
         */
        function () {
            return this.getFieldValue();
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.setFieldValue(value);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewField.prototype, "ErrMsgs", {
        get: /**
         * @return {?}
         */
        function () {
            if (!this.valid)
                return this.getFirstErrMsg();
            else
                return null;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewField.prototype, "valid", {
        get: /**
         * @return {?}
         */
        function () {
            if (NullorEmpty(this.VirtualFieldComponent))
                return false;
            /** @type {?} */
            var errors = this.VirtualFieldComponent.errors();
            if (NullorEmpty(errors) || errors.length == 0)
                return true;
            else
                return false;
        },
        enumerable: true,
        configurable: true
    });
    //errors :   () => ValidationErrors = () => this.VirtualFieldComponent.errors;
    // errors () : ValidationErrors
    // {
    //   return this.VirtualFieldComponent.errors;
    // }
    //errors :   () => ValidationErrors = () => this.VirtualFieldComponent.errors;
    // errors () : ValidationErrors
    // {
    //   return this.VirtualFieldComponent.errors;
    // }
    /**
     * @return {?}
     */
    ViewField.prototype.startComponentValidation = 
    //errors :   () => ValidationErrors = () => this.VirtualFieldComponent.errors;
    // errors () : ValidationErrors
    // {
    //   return this.VirtualFieldComponent.errors;
    // }
    /**
     * @return {?}
     */
    function () {
        if (NullorEmpty(this.VirtualFieldComponent))
            throw tomException.build("VirtualFieldComponent is not connected");
        //console.log ( this.validators);
        this.VirtualFieldComponent.setValidators(this.validators);
        //console.log ( this.fieldName);
        //console.log ( this.validators);
    };
    /**
     * @return {?}
     */
    ViewField.prototype.createErrorMsgMap = /**
     * @return {?}
     */
    function () {
        this.ErrorMsgMap["required"] = "Required";
        this.ErrorMsgMap["pattern"] = "Invalid Pattern";
    };
    /**
     * @return {?}
     */
    ViewField.prototype.getFirstErrMsg = /**
     * @return {?}
     */
    function () {
        if (NullorEmpty(this.VirtualFieldComponent) || NullorEmpty(this.VirtualFieldComponent.errors()))
            return null;
        /** @type {?} */
        var errs = this.VirtualFieldComponent.errors();
        if (errs == null)
            return null;
        /** @type {?} */
        var err = Object.keys(errs)[0];
        if (this.ErrorMsgMap[err] == undefined)
            alert("msg not found in map for err: " + err);
        // console.log (this.ErrorMsgMap[keyValue]);
        /** @type {?} */
        var msg = this.ErrorMsgMap[err];
        return msg;
    };
    return ViewField;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ButtonViewField = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(ButtonViewField, _super);
    function ButtonViewField(bfParam) {
        var _this = _super.call(this, bfParam) || this;
        _this.routableCmd = null;
        if (NullorEmpty(bfParam.routableCmd)) {
            throw tomException.build("Routable cmd is null : " + bfParam.fieldName + " ", { source: _this.constructor.name });
        }
        _this.routableCmd = bfParam.routableCmd;
        return _this;
        //this.directCmd = bfParam.directCmd;
    }
    //directCmd : () => void;
    //directCmd : () => void;
    /**
     * @return {?}
     */
    ButtonViewField.prototype.runCmd = 
    //directCmd : () => void;
    /**
     * @return {?}
     */
    function () {
        // if ( !NullorEmpty(this.directCmd))
        //       this.directCmd();
        // else 
        // {
        this.routableCmd.ViewNodeSeq = this.seq;
        this.getViewModel().appViewModel.cmdRouter.runCommand(this.routableCmd);
        //}
    };
    return ButtonViewField;
}(ViewField));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var SelectViewField = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(SelectViewField, _super);
    function SelectViewField(sfParam) {
        var _this = _super.call(this, sfParam) || this;
        _this.getOptionList = sfParam.getOptionList;
        return _this;
    }
    Object.defineProperty(SelectViewField.prototype, "OptionList", {
        get: /**
         * @return {?}
         */
        function () {
            return this.getOptionList();
        },
        enumerable: true,
        configurable: true
    });
    return SelectViewField;
}(ViewField));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var SerializerSkipper = /** @class */ (function () {
    function SerializerSkipper(path, SkipCheck) {
        this.path = undefined;
        this.SkipCheck = undefined;
        this.path = path;
        this.SkipCheck = SkipCheck;
    }
    /**
     * @param {?} path
     * @param {?} vModel
     * @param {?} dataModel
     * @param {?} skippers
     * @return {?}
     */
    SerializerSkipper.isSkip = /**
     * @param {?} path
     * @param {?} vModel
     * @param {?} dataModel
     * @param {?} skippers
     * @return {?}
     */
    function (path, vModel, dataModel, skippers) {
        return skippers.some(function (skipper) {
            if (skipper.path == undefined && skipper.SkipCheck == undefined)
                throw "skipper path undefined and SkipCheck undefined";
            if (skipper.path == null) {
                if (skipper.SkipCheck(vModel, dataModel)) {
                    return true;
                }
            }
            else if (path == skipper.path && skipper.SkipCheck(vModel, dataModel))
                return true;
            else
                return false;
        });
    };
    return SerializerSkipper;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var FieldSeqPair = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(FieldSeqPair, _super);
    function FieldSeqPair(key, value) {
        return _super.call(this, key, value) || this;
    }
    return FieldSeqPair;
}(BiValues));
var FiledSeqPairList = /** @class */ (function () {
    function FiledSeqPairList(ParentSeq) {
        this.ParentSeq = ParentSeq;
        this.PairList = [];
    }
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__decorate"])([
        JsonProperty({ clazz: FieldSeqPair }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__metadata"])("design:type", Array)
    ], FiledSeqPairList.prototype, "PairList", void 0);
    return FiledSeqPairList;
}());
var ShadowSeq = /** @class */ (function () {
    function ShadowSeq(RootSeq) {
        this.RootSeq = RootSeq;
        this.ChildrenSeqs = [];
    }
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__decorate"])([
        JsonProperty({ clazz: FiledSeqPairList }),
        Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__metadata"])("design:type", Array)
    ], ShadowSeq.prototype, "ChildrenSeqs", void 0);
    return ShadowSeq;
}());
var DataModelBase = /** @class */ (function () {
    function DataModelBase() {
        this.shadowSeq = null;
    }
    return DataModelBase;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var CallItem = /** @class */ (function () {
    function CallItem() {
        this.isError = false;
    }
    /**
     * @param {?} name
     * @param {?} url
     * @param {?=} PostData
     * @param {?=} ContentRetriever
     * @return {?}
     */
    CallItem.buildCallItem = /**
     * @param {?} name
     * @param {?} url
     * @param {?=} PostData
     * @param {?=} ContentRetriever
     * @return {?}
     */
    function (name, url, PostData, ContentRetriever) {
        if (PostData === void 0) { PostData = null; }
        if (ContentRetriever === void 0) { ContentRetriever = null; }
        /** @type {?} */
        var b = new CallItem();
        b.name = name;
        b.url = url;
        b.PostData = PostData;
        if (NullorEmpty(ContentRetriever))
            b.ContentRetriever = function (body) { return body; };
        else
            b.ContentRetriever = ContentRetriever;
        return b;
    };
    return CallItem;
}());
var Tajax = /** @class */ (function () {
    function Tajax() {
        this.IsBucketReady = false;
        this.SimJsAjax = false;
        this.CallBucket = new Map();
        this.http = AppGlobal.setting.injector.get(_angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]);
    }
    /**
     * @return {?}
     */
    Tajax.prototype.setBucketReady = /**
     * @return {?}
     */
    function () {
        this.IsBucketReady = true;
        this.checkBucket();
    };
    /**
     * @protected
     * @return {?}
     */
    Tajax.prototype.checkBucket = /**
     * @protected
     * @return {?}
     */
    function () {
        //console.log (`check bucket... length = ${this.CallBucket.size}`);
        //console.log( this.CallBucket);
        if (this.IsBucketReady && this.BatchCallback != null && this.CallBucket.size > 0) {
            /** @type {?} */
            var isBucketFull_1 = true;
            this.CallBucket.forEach(function (value, key) {
                //console.log( value);
                if (value != null && !value) {
                    isBucketFull_1 = false;
                }
            });
            if (isBucketFull_1) {
                this.BatchCallback();
                //console.log("fired");
                // fire only once
                this.BatchCallback = null;
                this.notifyLoading(false);
            }
        }
    };
    // public CreateBucketCaller ( BatchCallback, SimJsAjax : boolean = false  ): BatchCaller  {
    //     let newBatch = new BatchCaller( );
    //     newBatch.SimJsAjax = SimJsAjax;
    //     if ( BatchCallback != null )
    //     {
    //       newBatch.BatchCallback = BatchCallback;
    //       newBatch.CallBucket = new Map<string, boolean>();
    //     }
    //       return newBatch;
    // }
    // public CreateBucketCaller ( BatchCallback, SimJsAjax : boolean = false  ): BatchCaller  {
    //     let newBatch = new BatchCaller( );
    //     newBatch.SimJsAjax = SimJsAjax;
    //     if ( BatchCallback != null )
    //     {
    //       newBatch.BatchCallback = BatchCallback;
    //       newBatch.CallBucket = new Map<string, boolean>();
    //     }
    //       return newBatch;
    // }
    /**
     * @param {?} url
     * @return {?}
     */
    Tajax.prototype.makeGet = 
    // public CreateBucketCaller ( BatchCallback, SimJsAjax : boolean = false  ): BatchCaller  {
    //     let newBatch = new BatchCaller( );
    //     newBatch.SimJsAjax = SimJsAjax;
    //     if ( BatchCallback != null )
    //     {
    //       newBatch.BatchCallback = BatchCallback;
    //       newBatch.CallBucket = new Map<string, boolean>();
    //     }
    //       return newBatch;
    // }
    /**
     * @param {?} url
     * @return {?}
     */
    function (url) {
        //const headers = new HttpHeaders({'Content-Type':'application/json; charset=utf-8', "userid": "50000004", "usergroup": "dev"});
        /** @type {?} */
        var headers = AppGlobal.setting.GetHeader;
        //new HttpHeaders({'Content-Type':'application/json; charset=utf-8', "userid": "50000003", "usergroup": "dev", "username":"50000004"});      
        //const headers = new HttpHeaders({'Content-Type':'application/json; charset=utf-8', "userid": "50000003", "usergroup": "UW", "username":"50000003"});      
        /** @type {?} */
        var result = this.http.get(url, { headers: headers, observe: 'response' });
        return result;
    };
    /**
     * @param {?} url
     * @return {?}
     */
    Tajax.prototype.donwload = /**
     * @param {?} url
     * @return {?}
     */
    function (url) {
        //const headers = new HttpHeaders({'Content-Type':'application/json; charset=utf-8', "userid": "50000004", "usergroup": "dev"});
        //const headers = new HttpHeaders() ;//new HttpHeaders({"userid": "50000003", "usergroup": "dev", "username":"50000004"});      
        /** @type {?} */
        var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpHeaders"]({ 'Content-Type': 'application/json; charset=utf-8', "userid": "50000003", "usergroup": "UW", "username": "50000003" });
        /** @type {?} */
        var result = this.http.get(url, { headers: headers, observe: 'response', responseType: "blob" });
        return result;
    };
    /**
     * @param {?} url
     * @param {?} data
     * @return {?}
     */
    Tajax.prototype.makePost = /**
     * @param {?} url
     * @param {?} data
     * @return {?}
     */
    function (url, data) {
        /** @type {?} */
        var headers = AppGlobal.setting.PostHeader;
        //new HttpHeaders({'Content-Type':'application/json; charset=utf-8', "userid": "50000003","username":"50000004","usergroup": "UW"});
        //const headers = new HttpHeaders({'Content-Type':'application/json; charset=utf-8', "userid": "50000003", "usergroup": "UW", "username":"50000003"});      
        /** @type {?} */
        var result = this.http.post(url, data, { headers: headers, observe: 'response' });
        return result;
    };
    /**
     * @param {?} url
     * @param {?} data
     * @return {?}
     */
    Tajax.prototype.fileUpload = /**
     * @param {?} url
     * @param {?} data
     * @return {?}
     */
    function (url, data) {
        var _this = this;
        //const headers = new HttpHeaders({'Content-Type': 'multipart/form-data', "userid": "50000004","username":"50000004"});
        /** @type {?} */
        var headers = AppGlobal.setting.UploadHeader;
        new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpHeaders"]({ "userid": "50000004", "usergroup": "dev", "username": "50000004" });
        //const headers = new HttpHeaders({ "userid": "50000003", "usergroup": "UW", "username":"50000003"});      
        //console.log ( url);
        /** @type {?} */
        var result = this.http.post(url, data, { headers: headers, observe: 'response' })
            .pipe(function (ObvSource) { return _this.intercept(ObvSource, null); });
        return result;
    };
    /**
     * @return {?}
     */
    Tajax.prototype.printButcket = /**
     * @return {?}
     */
    function () {
        console.log("print The bucket");
        this.CallBucket.forEach(function (value, key) { return console.log(key + " = " + value + " "); });
    };
    /**
     * @param {?} url
     * @param {?=} CallId
     * @return {?}
     */
    Tajax.prototype.get = /**
     * @param {?} url
     * @param {?=} CallId
     * @return {?}
     */
    function (url, CallId) {
        var _this = this;
        if (CallId === void 0) { CallId = ""; }
        if (this.CallBucket != null)
            this.CallBucket.set(CallId, false);
        return this.makeGet(url).pipe(function (ObvSource) { return _this.intercept(ObvSource, CallId); });
    };
    /**
     * @param {?} url
     * @param {?} data
     * @param {?=} CallId
     * @return {?}
     */
    Tajax.prototype.post = /**
     * @param {?} url
     * @param {?} data
     * @param {?=} CallId
     * @return {?}
     */
    function (url, data, CallId) {
        var _this = this;
        if (CallId === void 0) { CallId = ""; }
        if (this.CallBucket != null)
            this.CallBucket.set(CallId, false);
        return this.makePost(url, data).pipe(function (ObvSource) { return _this.intercept(ObvSource, CallId); });
    };
    /**
     * @param {?} isLoading
     * @return {?}
     */
    Tajax.prototype.notifyLoading = /**
     * @param {?} isLoading
     * @return {?}
     */
    function (isLoading) {
        //console.log (`isloading = ${isLoading}`);
        AppGlobal.isLoading = isLoading;
    };
    /**
     * @protected
     * @param {?} ObvSource
     * @param {?} CallId
     * @return {?}
     */
    Tajax.prototype.intercept = /**
     * @protected
     * @param {?} ObvSource
     * @param {?} CallId
     * @return {?}
     */
    function (ObvSource, CallId) {
        var _this = this;
        /** @type {?} */
        var ObsObj = rxjs__WEBPACK_IMPORTED_MODULE_1__["Observable"].create(function (subscriber) {
            _this.notifyLoading(true);
            /** @type {?} */
            var subscription = ObvSource.subscribe(function (RetValue) {
                subscriber.next(RetValue);
                //console.log ( `After next of ${CallId}`);              
                if (_this.CallBucket != null) {
                    _this.CallBucket.set(CallId, true);
                    //console.log("checing bucketing");
                    _this.checkBucket();
                }
                else {
                    _this.notifyLoading(false);
                }
            }, function (xerr) {
                console.log("before err of " + CallId);
                // var x = err;
                // console.log (x);
                console.log(xerr);
                //console.log ( subscriber);
                subscriber.error(xerr);
                if (_this.CallBucket != null) {
                    _this.CallBucket.set(CallId, null);
                    _this.checkBucket();
                }
                else {
                    _this.notifyLoading(false);
                }
                //console.log ( `After err of ${CallId}`);              
            }, function () {
                //console.log ("complete");
                // not called by promise
                subscriber.complete();
            });
            return subscription;
        });
        return ObsObj;
    };
    Tajax.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["Injectable"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["NgModule"] }
    ];
    /** @nocollapse */
    Tajax.ctorParameters = function () { return []; };
    return Tajax;
}());
var TAjaxCaller = /** @class */ (function () {
    function TAjaxCaller() {
    }
    /**
     * @param {?} BatchName
     * @param {?} CallItems
     * @param {?=} handller
     * @return {?}
     */
    TAjaxCaller.BatchCall = /**
     * @param {?} BatchName
     * @param {?} CallItems
     * @param {?=} handller
     * @return {?}
     */
    function (BatchName, CallItems, handller) {
        var e_1, _a, e_2, _b;
        if (NullorEmpty(BatchName)) {
            throw tomException.build("no batch name ", CallItems);
        }
        if (AppGlobal.isReplaying) {
            /** @type {?} */
            var reader = AppGlobal.AjaxLogReader;
            if (!reader.initRead) {
                throw tomException.build("Unexpectedly no more log for ajax", { source: this.constructor.name, CallItems: CallItems });
            }
            else {
                /** @type {?} */
                var log = reader.readNext(BatchName);
                console.log(log);
                if (NullorEmpty(log)) {
                    throw tomException.build("unexpectedly ajaxlog is null ", { BatchName: BatchName });
                }
                handller(log.content);
            }
        }
        else {
            /** @type {?} */
            var logger = new tomLogger();
            /** @type {?} */
            var RawContainer_1 = {};
            //let caller =  new BatchCaller();
            /** @type {?} */
            var caller = AppGlobal.setting.injector.get("Tajax")();
            try {
                for (var CallItems_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__values"])(CallItems), CallItems_1_1 = CallItems_1.next(); !CallItems_1_1.done; CallItems_1_1 = CallItems_1.next()) {
                    var item = CallItems_1_1.value;
                    caller.CallBucket.set(item.name, false);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (CallItems_1_1 && !CallItems_1_1.done && (_a = CallItems_1.return)) _a.call(CallItems_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            caller.BatchCallback = function () {
                if (AppGlobal.isAjaxLogging) {
                    /** @type {?} */
                    var content = AjaxContent.build(RawContainer_1, BatchName);
                    /** @type {?} */
                    var logItem = new LogItem(content);
                    //logger.log ( logItem);
                }
                handller(RawContainer_1);
            };
            var _loop_1 = function (item) {
                if (NullorEmpty(item.PostData)) {
                    caller.get(item.url(), item.name).subscribe(function (res) {
                        /** @type {?} */
                        var result = item.ContentRetriever(res.body);
                        RawContainer_1[item.name] = result;
                    }, function (err) { RawContainer_1[item.name] = err; console.log(err); });
                }
                else {
                    caller.post(item.url(), item.PostData(), item.name).subscribe(function (res) { RawContainer_1[item.name] = item.ContentRetriever(res.body); }, function (err) { RawContainer_1[item.name] = err; });
                }
            };
            try {
                for (var CallItems_2 = Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__values"])(CallItems), CallItems_2_1 = CallItems_2.next(); !CallItems_2_1.done; CallItems_2_1 = CallItems_2.next()) {
                    var item = CallItems_2_1.value;
                    _loop_1(item);
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (CallItems_2_1 && !CallItems_2_1.done && (_b = CallItems_2.return)) _b.call(CallItems_2);
                }
                finally { if (e_2) throw e_2.error; }
            }
            caller.setBucketReady();
        }
    };
    /**
     * @param {?} BatchName
     * @param {?} CallItems
     * @param {?} handller
     * @return {?}
     */
    TAjaxCaller.prototype.TaCall = /**
     * @param {?} BatchName
     * @param {?} CallItems
     * @param {?} handller
     * @return {?}
     */
    function (BatchName, CallItems, handller) {
        TAjaxCaller.BatchCall(BatchName, CallItems, handller);
    };
    return TAjaxCaller;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var RoutableCmd = /** @class */ (function () {
    function RoutableCmd(init) {
        this.ServiceName = null;
        this.ViewNodeSeq = null;
        this.CmdName = null;
        this.CmdParam = null;
        Object.assign(this, init);
    }
    /**
     * @return {?}
     */
    RoutableCmd.prototype.runCmd = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @return {?}
     */
    RoutableCmd.prototype.getSourceField = /**
     * @return {?}
     */
    function () {
        return (/** @type {?} */ (AppGlobal.appViewModel.getViewNodeBySeq(this.ViewNodeSeq)));
    };
    return RoutableCmd;
}());
/**
 * @abstract
 */
var  /**
 * @abstract
 */
NonSimCmd = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(NonSimCmd, _super);
    function NonSimCmd(init) {
        return _super.call(this, init) || this;
    }
    return NonSimCmd;
}(RoutableCmd));
var NonSimDirectCmd = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(NonSimDirectCmd, _super);
    function NonSimDirectCmd(init) {
        var _this = _super.call(this, null) || this;
        Object.assign(_this, init);
        return _this;
    }
    /**
     * @return {?}
     */
    NonSimDirectCmd.prototype.runCmd = /**
     * @return {?}
     */
    function () {
        this.directCmd();
    };
    return NonSimDirectCmd;
}(NonSimCmd));
var DirectCmd = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(DirectCmd, _super);
    function DirectCmd(init) {
        var _this = _super.call(this, null) || this;
        Object.assign(_this, init);
        return _this;
    }
    /**
     * @return {?}
     */
    DirectCmd.prototype.runCmd = /**
     * @return {?}
     */
    function () {
        this.directCmd();
    };
    return DirectCmd;
}(RoutableCmd));
/** @enum {number} */
var ServiceReultStates = {
    OK: 0,
    Failed: 1,
};
ServiceReultStates[ServiceReultStates.OK] = 'OK';
ServiceReultStates[ServiceReultStates.Failed] = 'Failed';
var ServiceResult = /** @class */ (function () {
    function ServiceResult(ResultState, ResultContent) {
        if (ResultState === void 0) { ResultState = ServiceReultStates.OK; }
        this.ResultState = ResultState;
        this.ResultContent = ResultContent;
    }
    return ServiceResult;
}());
/**
 * @abstract
 */
var  /**
 * @abstract
 */
ServiceBase = /** @class */ (function () {
    function ServiceBase(completedHandler) {
        this.completedHandler = completedHandler;
        this.ServiceName = null;
    }
    return ServiceBase;
}());
/**
 * @abstract
 */
var  /**
 * @abstract
 */
TaCallerBaseService = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(TaCallerBaseService, _super);
    function TaCallerBaseService(completedHandler) {
        var _this = _super.call(this, completedHandler) || this;
        _this.completedHandler = completedHandler;
        _this.TaCaller = null;
        _this.TaCaller = new TAjaxCaller();
        return _this;
    }
    return TaCallerBaseService;
}(ServiceBase));
var CmdRouter = /** @class */ (function () {
    function CmdRouter() {
        this.logger = new tomLogger();
    }
    /**
     * @param {?} cmd
     * @return {?}
     */
    CmdRouter.prototype.runCommand = /**
     * @param {?} cmd
     * @return {?}
     */
    function (cmd) {
        if (AppGlobal.isAjaxLogging && !(cmd instanceof NonSimCmd)) {
            //LogCmdService.callRunSvc( cmd);
            // let cmdLogService = new LogCmdService( cmd);
            // cmdLogService.runService();
            /** @type {?} */
            var content = CmdContent.build(cmd);
            /** @type {?} */
            var logItem = new LogItem(content);
            this.logger.log(logItem);
            // AppGlobal.appViewModel.ActiveVM.attachShadowSeq();
            // let DataContent : DataModelContent = DataModelContent.build( AppGlobal.appViewModel.ActiveVM.dataModel);
            // let DataLogItem : LogItem<DataModelContent>  = new  LogItem<DataModelContent>  ( DataContent);
            // this.logger.log( DataLogItem);
            /** @type {?} */
            var activeVMLogService = new LogAcitveVMDataModelService();
            activeVMLogService.runService();
        }
        cmd.runCmd();
    };
    return CmdRouter;
}());
var LinkCmd = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(LinkCmd, _super);
    function LinkCmd(init) {
        return _super.call(this, init) || this;
    }
    /**
     * @return {?}
     */
    LinkCmd.prototype.runCmd = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var vf = this.getSourceField();
        /** @type {?} */
        var url = vf.getFieldValue();
        //console.log ( url);
        if (NullorEmpty(url)) {
            throw tomException.build("unexpectedly null virtualComp ", { source: this.constructor.name, ViewField: vf });
        }
        /** @type {?} */
        var virtualComp = vf.getViewModel().VirtualModelComponent;
        if (NullorEmpty(virtualComp)) {
            throw tomException.build("unexpectedly null virtualComp ", { source: this.constructor.name, cmd: this });
        }
        virtualComp.router.navigate([url]);
    };
    return LinkCmd;
}(RoutableCmd));
/**
 * @abstract
 */
var  /**
 * @abstract
 */
LoggerService = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(LoggerService, _super);
    function LoggerService(completedHandler) {
        var _this = _super.call(this, completedHandler) || this;
        _this.logger = new tomLogger();
        return _this;
    }
    return LoggerService;
}(ServiceBase));
var LogAcitveVMDataModelService = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(LogAcitveVMDataModelService, _super);
    //logger : tomLogger = new tomLogger();
    function LogAcitveVMDataModelService(completedHandler) {
        return _super.call(this, completedHandler) || this;
    }
    /**
     * @return {?}
     */
    LogAcitveVMDataModelService.prototype.runService = /**
     * @return {?}
     */
    function () {
        AppGlobal.appViewModel.getActiveVM().attachShadowSeq();
        /** @type {?} */
        var DataContent = DataModelContent.build(AppGlobal.appViewModel.getActiveVM().dataModel);
        /** @type {?} */
        var DataLogItem = new LogItem(DataContent);
        this.logger.log(DataLogItem);
        if (!NullorEmpty(this.completedHandler)) {
            this.completedHandler(new ServiceResult(ServiceReultStates.OK, DataLogItem));
        }
    };
    /**
     * @return {?}
     */
    LogAcitveVMDataModelService.callRunSvc = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var activeVMLogService = new LogAcitveVMDataModelService();
        activeVMLogService.runService();
    };
    return LogAcitveVMDataModelService;
}(LoggerService));
var LogInfoService = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(LogInfoService, _super);
    function LogInfoService(logContent, desc) {
        var _this = _super.call(this) || this;
        _this.logContent = logContent;
        _this.desc = desc;
        return _this;
    }
    /**
     * @return {?}
     */
    LogInfoService.prototype.runService = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var infoContent = InfoContent.build({ content: this.logContent, desc: this.desc });
        /** @type {?} */
        var infoLogItem = new LogItem(infoContent);
        this.logger.log(infoLogItem);
    };
    /**
     * @param {?} logContent
     * @param {?} desc
     * @return {?}
     */
    LogInfoService.callRunSvc = /**
     * @param {?} logContent
     * @param {?} desc
     * @return {?}
     */
    function (logContent, desc) {
        /** @type {?} */
        var loginfoService = new LogInfoService(logContent, desc);
        loginfoService.runService();
    };
    return LogInfoService;
}(LoggerService));
var CheckpointService = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(CheckpointService, _super);
    function CheckpointService(content, checkPointName) {
        var _this = _super.call(this) || this;
        _this.content = content;
        _this.checkPointName = checkPointName;
        _this.isArray = Array.isArray;
        _this.keyList = Object.keys;
        _this.hasProp = Object.prototype.hasOwnProperty;
        return _this;
    }
    /**
     * @param {?} content
     * @param {?} checkPointName
     * @return {?}
     */
    CheckpointService.CheckPoint = /**
     * @param {?} content
     * @param {?} checkPointName
     * @return {?}
     */
    function (content, checkPointName) {
        /** @type {?} */
        var chpSvc = new CheckpointService(content, checkPointName);
        chpSvc.runService();
    };
    /**
     * @return {?}
     */
    CheckpointService.prototype.runService = /**
     * @return {?}
     */
    function () {
        if (AppGlobal.checkPointMode == CheckPointMode.CheckPointLogging) {
            this.logCheckPoint();
        }
        else if (AppGlobal.checkPointMode == CheckPointMode.CheckPointCompare) {
            /** @type {?} */
            var logger = new tomLogger();
            /** @type {?} */
            var resultContent = this.CompareLog();
            /** @type {?} */
            var logItem = new LogItem(resultContent);
            logger.log(logItem);
        }
    };
    /**
     * @protected
     * @return {?}
     */
    CheckpointService.prototype.logCheckPoint = /**
     * @protected
     * @return {?}
     */
    function () {
        /** @type {?} */
        var logger = new tomLogger();
        /** @type {?} */
        var cpContent = CheckPointContent.build(this.content, this.checkPointName);
        /** @type {?} */
        var cpItem = new LogItem(cpContent);
        logger.log(cpItem);
    };
    /**
     * @protected
     * @return {?}
     */
    CheckpointService.prototype.CompareLog = /**
     * @protected
     * @return {?}
     */
    function () {
        //const logReader = new tomLogReader<CheckPointContent>(CheckPointContent);
        //AppGlobal.checkPointReader.read
        if (AppGlobal.checkPointMode == CheckPointMode.CheckPointCompare) {
            /** @type {?} */
            var reader = AppGlobal.checkPointReader;
            if (!reader.initRead) {
                throw tomException.build("Unexpectedly no more log for check point", { source: this.constructor.name, CheckPoint: this.checkPointName });
            }
            else {
                /** @type {?} */
                var log = reader.readNext();
                console.log(log);
                if (NullorEmpty(log)) {
                    throw tomException.build("unexpectedly checkpoint log is null ", { CheckPoint: this.checkPointName });
                }
                /** @type {?} */
                var resultParam = {
                    CheckPointName: this.checkPointName,
                    LogSession: reader.CurrentSession,
                    LogSeq: reader.runningSeq,
                };
                if (this.equal(log.content, this.content)) {
                    resultParam.isResultMatch = true;
                    return CheckResultContent.build(resultParam);
                }
                else {
                    resultParam.isResultMatch = false;
                    resultParam.LoggedContent = log.content;
                    resultParam.TargetContent = this.content;
                    return CheckResultContent.build(resultParam);
                }
            }
        }
        throw tomException.build("unexpectedly code reached ", { source: this.constructor.name });
    };
    /**
     * @param {?} a
     * @param {?} b
     * @return {?}
     */
    CheckpointService.prototype.equal = /**
     * @param {?} a
     * @param {?} b
     * @return {?}
     */
    function (a, b) {
        if (a === b)
            return true;
        if (a && b && typeof a == 'object' && typeof b == 'object') {
            /** @type {?} */
            var arrA = this.isArray(a);
            /** @type {?} */
            var arrB = this.isArray(b);
            /** @type {?} */
            var i;
            /** @type {?} */
            var length;
            /** @type {?} */
            var key;
            if (arrA && arrB) {
                length = a.length;
                if (length != b.length)
                    return false;
                for (i = length; i-- !== 0;)
                    if (!this.equal(a[i], b[i]))
                        return false;
                return true;
            }
            if (arrA != arrB)
                return false;
            /** @type {?} */
            var dateA = a instanceof Date;
            /** @type {?} */
            var dateB = b instanceof Date;
            if (dateA != dateB)
                return false;
            if (dateA && dateB)
                return a.getTime() == b.getTime();
            /** @type {?} */
            var regexpA = a instanceof RegExp;
            /** @type {?} */
            var regexpB = b instanceof RegExp;
            if (regexpA != regexpB)
                return false;
            if (regexpA && regexpB)
                return a.toString() == b.toString();
            /** @type {?} */
            var keys = this.keyList(a);
            length = keys.length;
            if (length !== this.keyList(b).length)
                return false;
            for (i = length; i-- !== 0;)
                if (!this.hasProp.call(b, keys[i]))
                    return false;
            for (i = length; i-- !== 0;) {
                key = keys[i];
                if (!this.equal(a[key], b[key]))
                    return false;
            }
            return true;
        }
        return a !== a && b !== b;
    };
    return CheckpointService;
}(ServiceBase));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ViewModel = /** @class */ (function () {
    function ViewModel(CtorParam) {
        if (CtorParam === void 0) { CtorParam = null; }
        var _this = this;
        this.isReady = false;
        this.ErrMsgs = [];
        this.validatiors = [];
        this.DisplayMsg = null;
        this.isValidateDecendants = true;
        this.visibleWardrobe = wardrobe.build(function () { return _this.DefaultVisible; });
        this.editableWardrobe = wardrobe.build(function () { return _this.DefaultEditable; });
        this.CtorParam = CtorParam;
    }
    Object.defineProperty(ViewModel.prototype, "valid", {
        get: /**
         * @return {?}
         */
        function () {
            // let anyError: boolean = false;
            // this.ViewFields.forEach( 
            //     (v, k) => {
            //         anyError = ( anyError || !v.valid );
            //     }
            // );
            // if ( anyError )
            //     return false;
            // if ( this.ErrMsgs.length > 0)
            //     return false;
            // let subModels = valuesOfMap( this.subModels);
            // if ( subModels.some ( m => m.ErrMsgs.length > 0) )
            //     return false;
            // return true;
            return (this.ErrMsgs.length == 0);
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    ViewModel.prototype.validate = /**
     * @return {?}
     */
    function () {
        var e_1, _a;
        /** @type {?} */
        var anyError = false;
        this.ErrMsgs = this.validatiors.map(function (v) { return v(); }).filter(function (m) { return !NullorEmpty(m); });
        anyError = this.ErrMsgs.length > 0;
        if (this.isValidateDecendants) {
            /** @type {?} */
            var vms = valuesOfMap(this.subModels);
            try {
                for (var vms_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__values"])(vms), vms_1_1 = vms_1.next(); !vms_1_1.done; vms_1_1 = vms_1.next()) {
                    var vm = vms_1_1.value;
                    /** @type {?} */
                    var b = vm.validate();
                    anyError = (anyError && b);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (vms_1_1 && !vms_1_1.done && (_a = vms_1.return)) _a.call(vms_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
        }
        return !anyError;
    };
    /**
     * @param {?} criteria
     * @return {?}
     */
    ViewModel.prototype.findModel = /**
     * @param {?} criteria
     * @return {?}
     */
    function (criteria) {
        /** @type {?} */
        var resultModel = null;
        this.traverseNodes(null, function (key, vm) {
            if (criteria(key, vm)) {
                resultModel = vm;
                return true;
            }
        });
        return resultModel;
    };
    Object.defineProperty(ViewModel.prototype, "showErrorMsg", {
        get: /**
         * @return {?}
         */
        function () {
            if (this.parentViewModel)
                return this.parentViewModel.showErrorMsg;
            else
                return true;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    ViewModel.prototype.getModelName = /**
     * @return {?}
     */
    function () {
        return this.constructor.name;
    };
    /**
     * @return {?}
     */
    ViewModel.prototype.getModelPath = /**
     * @return {?}
     */
    function () {
        if (this.parentViewModel != null) {
            /** @type {?} */
            var parentPath = this.parentViewModel.getModelPath();
            //console.log ( parentPath);
            if (NullorEmpty(parentPath)) {
                return this.getModelName();
            }
            else {
                return parentPath + "." + this.getModelName();
            }
        }
        else
            return this.getModelName();
    };
    Object.defineProperty(ViewModel.prototype, "DefaultVisible", {
        get: /**
         * @return {?}
         */
        function () {
            return this.parentViewModel.DefaultVisible;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewModel.prototype, "DefaultEditable", {
        get: /**
         * @return {?}
         */
        function () {
            return this.parentViewModel.DefaultEditable;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewModel.prototype, "visible", {
        get: /**
         * @return {?}
         */
        function () {
            if (NullorEmpty(this.getVisible))
                return this.visibleWardrobe.pickDress();
            else
                return this.getVisible();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewModel.prototype, "editable", {
        get: /**
         * @return {?}
         */
        function () {
            if (!NullorEmpty(this.parentViewModel))
                if (!this.parentViewModel.editable)
                    return false;
            if (NullorEmpty(this.getEditable))
                return this.editableWardrobe.pickDress();
            else
                return this.getEditable();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewModel.prototype, "dataModel", {
        //subModels :  ViewModel[] = [];
        get: 
        //subModels :  ViewModel[] = [];
        /**
         * @return {?}
         */
        function () {
            return this._getDataModel();
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @protected
     * @template T
     * @return {?}
     */
    ViewModel.prototype._getDataModel = /**
     * @protected
     * @template T
     * @return {?}
     */
    function () {
        if (NullorEmpty(this.CtorParam) || NullorEmpty(this.CtorParam.DataModel))
            return null;
        else
            return (/** @type {?} */ ((/** @type {?} */ (this.CtorParam.DataModel()))));
    };
    /**
     * @return {?}
     */
    ViewModel.prototype.init = /**
     * @return {?}
     */
    function () {
        // if ( ! NullorEmpty( this.CtorParam ) &&  NullorEmpty( this.dataModel ))
        //     this.dataModel = this.CtorParam.DataModel();
        var _this = this;
        this.subModels.forEach(function (model, key) {
            _this.initSubModel(model);
        });
    };
    /**
     * @param {?} model
     * @return {?}
     */
    ViewModel.prototype.initSubModel = /**
     * @param {?} model
     * @return {?}
     */
    function (model) {
        model.parentViewModel = this;
        model.init();
    };
    /**
     * @param {?} viewModelChecker
     * @return {?}
     */
    ViewModel.prototype.traversAncestor = /**
     * @param {?} viewModelChecker
     * @return {?}
     */
    function (viewModelChecker) {
        if (viewModelChecker(this))
            return this;
        else if (this.parentViewModel == null || this.parentViewModel == undefined)
            return null;
        else
            return this.parentViewModel.traversAncestor(viewModelChecker);
    };
    /**
     * @param {?} dataModel
     * @return {?}
     */
    ViewModel.prototype.findChildViewByDataModel = /**
     * @param {?} dataModel
     * @return {?}
     */
    function (dataModel) {
        var e_2, _a;
        //console.log ( this.ChildrenViews);
        /** @type {?} */
        var models = valuesOfMap(this.subModels);
        try {
            for (var models_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__values"])(models), models_1_1 = models_1.next(); !models_1_1.done; models_1_1 = models_1.next()) {
                var vm = models_1_1.value;
                // console.log ( vm);
                // console.log ( dataModel);
                if (vm.dataModel == dataModel) {
                    //alert ( "found");
                    return vm;
                }
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (models_1_1 && !models_1_1.done && (_a = models_1.return)) _a.call(models_1);
            }
            finally { if (e_2) throw e_2.error; }
        }
        return null;
    };
    Object.defineProperty(ViewModel.prototype, "NodePath", {
        get: /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var NodeName = this.constructor.name;
            if (NullorEmpty(this.parentViewModel))
                return NodeName;
            else
                return this.parentViewModel.NodePath + "." + NodeName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewModel.prototype, "subModels", {
        get: /**
         * @protected
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var _ViewModels = new Map();
            Object.keys(this).forEach(function (key) {
                /** @type {?} */
                var value = _this[key];
                if (value == null || value === _this.parentViewModel)
                    return;
                if (value instanceof ViewModel) {
                    _ViewModels.set(key, value);
                }
            });
            return _ViewModels;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewModel.prototype, "ViewFields", {
        get: /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var _ViewFields = new Map();
            Object.keys(this).forEach(function (key) {
                /** @type {?} */
                var value = _this[key];
                if (value instanceof ViewField) {
                    _ViewFields.set(key, value);
                }
            });
            return _ViewFields;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @param {?} containerObj
     * @param {?} path
     * @param {?} skippers
     * @param {?=} dataModel
     * @return {?}
     */
    ViewModel.prototype.serialize = /**
     * @param {?} containerObj
     * @param {?} path
     * @param {?} skippers
     * @param {?=} dataModel
     * @return {?}
     */
    function (containerObj, path, skippers, dataModel) {
        var _this = this;
        if (dataModel === void 0) { dataModel = undefined; }
        if (dataModel == undefined)
            dataModel = this.dataModel;
        if (SerializerSkipper.isSkip(path, this, dataModel, skippers))
            return true;
        if (isArray(containerObj)) {
            if (!isArray(dataModel)) {
                throw "containerObj and dataModel should be both array not neither";
            }
            ((/** @type {?} */ ((dataModel)))).forEach(function (item) {
                //console.log ( item);
                /** @type {?} */
                var newPath = path + "/[]";
                if (isPrimitive(item)) {
                    ((/** @type {?} */ (containerObj))).push(item);
                }
                else {
                    /** @type {?} */
                    var childContainer = {};
                    /** @type {?} */
                    var childVm = _this.findChildViewByDataModel(item);
                    /** @type {?} */
                    var isSkip = false;
                    if (childVm == null) {
                        isSkip = _this.serialize(childContainer, newPath, skippers, item);
                    }
                    else {
                        isSkip = childVm.serialize(childContainer, newPath, skippers, item);
                    }
                    if (!isSkip) {
                        ((/** @type {?} */ (containerObj))).push(childContainer);
                    }
                }
            });
        }
        else {
            Object.keys(dataModel).forEach(function (key) {
                //console.log ( key);
                /** @type {?} */
                var value = dataModel[key];
                /** @type {?} */
                var newPath = path + "/" + key;
                //console.log( value);
                if (value != undefined) {
                    // if ( SerializerSkipper.isSkip( newPath, this, value, skippers) ){
                    //     return  ;
                    // }
                    if (isPrimitive(value)) {
                        //console.log( newPath);
                        if (SerializerSkipper.isSkip(newPath, _this, value, skippers)) {
                            return true;
                        }
                        containerObj[key] = value;
                    }
                    else {
                        /** @type {?} */
                        var childContainer = isArray(value) ? [] : {};
                        /** @type {?} */
                        var childVm = _this.findChildViewByDataModel(value);
                        /** @type {?} */
                        var isSkip = false;
                        if (childVm == null)
                            isSkip = _this.serialize(childContainer, newPath, skippers, value);
                        else
                            isSkip = childVm.serialize(childContainer, newPath, skippers, value);
                        //this.serialize(childContainer,  newPath, skippers,value );
                        if (!isSkip)
                            containerObj[key] = childContainer;
                    }
                }
                //console.log (  vField.dataFieldName );
            });
        }
        return false;
    };
    /**
     * @param {?} testValue
     * @return {?}
     */
    ViewModel.prototype.IsIAppViewModel = /**
     * @param {?} testValue
     * @return {?}
     */
    function (testValue) {
        return ((/** @type {?} */ (testValue))).IAppViewModel_identity !== undefined;
    };
    Object.defineProperty(ViewModel.prototype, "appViewModel", {
        get: /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var v = this.traversAncestor(function (v) { return _this.IsIAppViewModel(v); });
            return (/** @type {?} */ (v));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewModel.prototype, "fullNodePaths", {
        get: /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var nodePaths = [];
            this.traverseNodes(function (fieldName, vf, vm) {
                nodePaths.push(vf.FieldPath);
            }, function (modelName, vm) {
                nodePaths.push(vm.NodePath);
            });
            return nodePaths;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @param {?} FieldHandler
     * @param {?=} ModelHandler
     * @return {?}
     */
    ViewModel.prototype.traverseNodes = /**
     * @param {?} FieldHandler
     * @param {?=} ModelHandler
     * @return {?}
     */
    function (FieldHandler, ModelHandler) {
        //console.log ( this.ViewName);
        //console.log ( this.getModelPath());
        var _this = this;
        if (ModelHandler === void 0) { ModelHandler = null; }
        if (!NullorEmpty(ModelHandler)) {
            /** @type {?} */
            var b = ModelHandler(this.getModelName(), this);
            if (b)
                return;
        }
        if (!NullorEmpty(FieldHandler)) {
            /** @type {?} */
            var canExsit_1 = false;
            this.ViewFields.forEach(function (field, key) {
                /** @type {?} */
                var b = FieldHandler(key, field, _this);
                canExsit_1 = b || canExsit_1;
            });
            if (canExsit_1)
                return;
        }
        /** @type {?} */
        var keys = keysOfMap(this.subModels);
        if (keys.some(function (v, k) { return v == "parentModel"; })) {
            console.log("err:: parent not skipped");
        }
        /** @type {?} */
        var subModels = valuesOfMap(this.subModels);
        if (!NullorEmpty(subModels)) {
            subModels.forEach(function (model) { return model.traverseNodes(FieldHandler, ModelHandler); });
            // if ( ! NullorEmpty(ModelHandler)){
            //     this.subModels.forEach (
            //         (view) => ModelHandler( view.getModelName(), view)
            //     );
            // }
        }
    };
    /**
     * @param {?} dressable
     * @param {?} NodePath
     * @return {?}
     */
    ViewModel.prototype.buildVisibleDressing = /**
     * @param {?} dressable
     * @param {?} NodePath
     * @return {?}
     */
    function (dressable, NodePath) {
        var _this = this;
        this.appViewModel.VisibleSettings.forEach(function (setting) {
            if (DressingRule.comparePath(NodePath, setting)) {
                /** @type {?} */
                var dressing = _this.buildDressing(setting);
                if (dressing) {
                    dressable.visibleWardrobe.rules.push(dressing);
                }
            }
        });
    };
    /**
     * @param {?} dressable
     * @param {?} NodePath
     * @return {?}
     */
    ViewModel.prototype.buildEditableDressing = /**
     * @param {?} dressable
     * @param {?} NodePath
     * @return {?}
     */
    function (dressable, NodePath) {
        var _this = this;
        this.appViewModel.EditSettings.forEach(function (setting) {
            if (DressingRule.comparePath(NodePath, setting)) {
                // if ( setting.TargetBehavior== "editable")
                //     console.log (NodePath);
                /** @type {?} */
                var dressing = _this.buildDressing(setting);
                if (dressing) {
                    dressable.editableWardrobe.rules.push(dressing);
                }
            }
        });
    };
    /**
     * @return {?}
     */
    ViewModel.prototype.furnish = /**
     * @return {?}
     */
    function () {
        var _this = this;
        //console.log ( this.appViewModel.VisibleSettings.length );
        this.traverseNodes(function (key, field, model) {
            model.buildVisibleDressing(field, field.FieldPath);
            model.buildEditableDressing(field, field.FieldPath);
            if (_this.appViewModel.SimulationMode != SimulationModes.simulating) {
                _this.appViewModel.incrementSeq(field);
            }
        }, function (key, model) {
            model.buildVisibleDressing(model, model.getModelPath());
            model.buildEditableDressing(model, model.getModelPath());
            if (_this.appViewModel.SimulationMode != SimulationModes.simulating) {
                _this.appViewModel.incrementSeq(model);
            }
            model.isReady = true;
        });
        this.isReady = true;
    };
    /**
     * @param {?} status
     * @return {?}
     */
    ViewModel.prototype.getStatusValue = /**
     * @param {?} status
     * @return {?}
     */
    function (status) {
        if (NullorEmpty(this.parentViewModel))
            return null;
        return this.parentViewModel.getStatusValue(status);
    };
    /**
     * @param {?} rule
     * @return {?}
     */
    ViewModel.prototype.buildDressing = /**
     * @param {?} rule
     * @return {?}
     */
    function (rule) {
        var _this = this;
        if (rule.ConditonalStatus) {
            /** @type {?} */
            var statusValue = this.getStatusValue(rule.ConditonalStatus);
            if (NullorEmpty(statusValue))
                return null;
            else
                return DressingRule.build(rule.SettingName, function () { return _this.getStatusValue(rule.ConditonalStatus) == rule.StatusValue; }, rule.TargetValue);
        }
        else // if Conditional status null, always apply
         {
            //console.log ( rule) ;
            return DressingRule.build(rule.SettingName, function () { return true; }, rule.TargetValue);
        }
    };
    /**
     * @param {?} fieldName
     * @param {?=} getDataModel
     * @param {?=} validators
     * @return {?}
     */
    ViewModel.prototype.buildSimpleField = /**
     * @param {?} fieldName
     * @param {?=} getDataModel
     * @param {?=} validators
     * @return {?}
     */
    function (fieldName, getDataModel, validators) {
        var _this = this;
        if (getDataModel === void 0) { getDataModel = null; }
        if (validators === void 0) { validators = []; }
        return new ViewField({
            fieldName: fieldName,
            getViewModel: function () { return _this; },
            getDataModel: getDataModel,
            validators: validators
        });
    };
    /**
     * @return {?}
     */
    ViewModel.prototype.attachShadowSeq = /**
     * @return {?}
     */
    function () {
        if (NullorEmpty(this.dataModel))
            return;
        /** @type {?} */
        var shadowSeq = new ShadowSeq(this.seq);
        /** @type {?} */
        var subSeqMap = new FiledSeqPairList(this.seq);
        shadowSeq.ChildrenSeqs.push(subSeqMap);
        this.dataModel.shadowSeq = shadowSeq;
        //set ( this.seq, subSeqMap);
        //Map<string, number> = new Map<string, number> ();
        this.ViewFields.forEach(function (field, key) {
            subSeqMap.PairList.push(new FieldSeqPair(key, field.seq));
        });
        /** @type {?} */
        var keys = keysOfMap(this.subModels);
        if (keys.some(function (v, k) { return v == "parentModel"; })) {
            console.log("err:: parent not skipped");
        }
        this.subModels.forEach(function (model, key) {
            subSeqMap.PairList.push(new FieldSeqPair(key, model.seq));
            //set( key, model.seq);
            model.attachShadowSeq();
        });
    };
    /**
     * @return {?}
     */
    ViewModel.prototype.restoreSeqFromShadow = /**
     * @return {?}
     */
    function () {
        // let parentVm = this.parentViewModel;
        // if (  NullorEmpty( this.dataModel.shadowSeq ) )
        //     throw tomException.build ( " dataModel.shadowSeq unexpectedly null : ", 
        //         {source : this.constructor.name, method : "restoreSeqFromShadow"});
        var _this = this;
        // // must be the page root
        // if ( NullorEmpty( parentVm ) || NullorEmpty(  parentVm.dataModel.shadowSeq  )){
        //     this.seq = this.dataModel.shadowSeq.RootSeq;
        // }
        // else {
        // }
        if (NullorEmpty(this.dataModel))
            return;
        if (NullorEmpty(this.dataModel.shadowSeq)) {
            throw tomException.build("unexpected shadowSeq null : ", { source: this.constructor.name, DataModel: this.dataModel });
        }
        //console.log( this.dataModel.shadowSeq.ChildrenSeqs);
        /** @type {?} */
        var childrenSeqs = this.dataModel.shadowSeq.ChildrenSeqs.filter(function (list) { return list.ParentSeq == _this.seq; })[0];
        childrenSeqs.PairList.forEach(function (fieldSeq) {
            /** @type {?} */
            var field = _this[fieldSeq.key];
            if (NullorEmpty(field)) {
                throw tomException.build("field not found in VM : " + fieldSeq.key, { source: _this.constructor.name, method: "restoreSeqFromShadow" });
            }
            if (!(field instanceof ViewField) && !(field instanceof ViewModel)) {
                throw tomException.build("field not viewfiedl or viewModel : " + fieldSeq.key, { source: _this.constructor.name, method: "restoreSeqFromShadow" });
            }
            field.seq = fieldSeq.value;
        });
        this.subModels.forEach(function (model, key) { model.restoreSeqFromShadow(); });
    };
    /**
     * @param {?} json
     * @return {?}
     */
    ViewModel.prototype.deserializeDataModel = /**
     * @param {?} json
     * @return {?}
     */
    function (json) {
        throw tomException.build(" call failure; deserializeDataModel() is / must  implemented at Page Root VM; ", { source: this.constructor.name });
    };
    /**
     * @param {?=} completedHandler
     * @return {?}
     */
    ViewModel.prototype.bindVirtualComponent = /**
     * @param {?=} completedHandler
     * @return {?}
     */
    function (completedHandler) {
        var _this = this;
        setTimeout(function () {
            _this.traverseNodes(function (k, vf) {
                if (!NullorEmpty(vf.VirtualFieldComponent)) {
                    vf.startComponentValidation();
                }
            });
            if (!NullorEmpty(completedHandler)) {
                completedHandler(new ServiceResult(ServiceReultStates.OK, _this));
            }
        }, 200);
    };
    return ViewModel;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
// export class PopupDataModel implements IPopupDataModel{
//     isShowPopup: boolean = false;
// }
var  
// export class PopupDataModel implements IPopupDataModel{
//     isShowPopup: boolean = false;
// }
PopupDataModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(PopupDataModel, _super);
    function PopupDataModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.isShowPopup = false;
        return _this;
    }
    return PopupDataModel;
}(DataModelBase));
var PopupViewModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(PopupViewModel, _super);
    function PopupViewModel(CtorParam) {
        if (CtorParam === void 0) { CtorParam = null; }
        var _this = _super.call(this, CtorParam) || this;
        //isRenderContent : () => boolean = null;
        // init ()
        // {
        //     if ( NullorEmpty( this.dataModel)){
        //         this.dataModel = this.CtorParam.DataModel();
        //     }
        // }
        _this.isShowPopup = new ViewField({
            fieldName: "isShowPopup",
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; }
        });
        // ViewField.createField( ViewField, ()=> this, "isShowPopup" ,
        //     (vf : ViewField) =>{
        //         vf.getFieldValue = () => this.dataModel.isShowPopup.toString()
        //     }
        // );
        _this.closePopupButton = tomjector.create(ButtonViewField.name, {
            fieldName: "closePopup",
            getViewModel: function () { return _this; },
            routableCmd: new DirectCmd({ CmdName: "ClosePopup", directCmd: function () { return _this.dataModel.isShowPopup = false; } }),
        });
        return _this;
        //this.isRenderContent = ifNull( CtorParam.isRenderContent, () => true);
    }
    Object.defineProperty(PopupViewModel.prototype, "dataModel", {
        get: /**
         * @return {?}
         */
        function () {
            return this._getDataModel();
        },
        enumerable: true,
        configurable: true
    });
    return PopupViewModel;
}(ViewModel));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
//import { setTimeout } from "timers";
var  
//import { setTimeout } from "timers";
SimDataModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(SimDataModel, _super);
    function SimDataModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.PlayToEnd = false;
        _this.IsPlaying = false;
        _this.CheckPointMode = [
            { key: CheckPointMode.none, value: "none" },
            { key: CheckPointMode.CheckPointLogging, value: "Logging" },
            { key: CheckPointMode.CheckPointCompare, value: "Compare" },
        ];
        _this.LogViewerPopupModel = new PopupDataModel();
        return _this;
    }
    return SimDataModel;
}(DataModelBase));
var SimViewModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(SimViewModel, _super);
    function SimViewModel(CtorParam) {
        var _this = _super.call(this, CtorParam) || this;
        _this.LogViewerPopup = new PopupViewModel({
            DataModel: function () { return _this.dataModel.LogViewerPopupModel; }
        });
        _this.SelectedCheckPointMode = new SelectViewField({
            getViewModel: function () { return _this; },
            fieldName: "SelectedCheckPointMode",
            getOptionList: function () { return _this.dataModel.CheckPointMode; },
            getFieldValue: function () { return AppGlobal.checkPointMode; },
            setFieldValue: function (value) { return AppGlobal.checkPointMode = value; }
        });
        _this.SelectedCheckPointSession = new SelectViewField({
            getViewModel: function () { return _this; },
            fieldName: "SelectedCheckPointSession",
            getOptionList: function () { return _this.dataModel.CheckPointSessions; },
            getFieldValue: function () { return _this.dataModel.SelectedCheckPointSession; },
            setFieldValue: function (value) {
                _this.dataModel.SelectedCheckPointSession = value;
                AppGlobal.checkPointReader.initRead(value);
            }
        });
        _this.SelectedCmdSession = new SelectViewField({
            getViewModel: function () { return _this; },
            fieldName: "SelectedCmdSession",
            getOptionList: function () { return _this.dataModel.cmdSessions; },
            validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
        // refresh : ButtonViewField =   new ButtonViewField
        // ( 
        //     {
        //         getViewModel :  () => this,
        //         fieldName : "refresh", 
        //         getEditable : () => true ,
        //         routableCmd : new NonSimDirectCmd
        //         ( 
        //             {
        //                 CmdName : "RefreshSession",
        //                 directCmd : () => this.getSessions()
        //             }
        //         )
        //     }
        // )
        _this.openLogViewer = tomjector.create(ButtonViewField.name, {
            getViewModel: function () { return _this; },
            fieldName: "openLogViewer",
            routableCmd: new NonSimDirectCmd({
                CmdName: "openLogViewer",
                directCmd: function () {
                    _this.dataModel.LogViewerPopupModel.isShowPopup = true;
                }
            })
        });
        _this.record = tomjector.create(ButtonViewField.name, {
            getViewModel: function () { return _this; },
            fieldName: "record",
            getEditable: function () { return !AppGlobal.isAjaxLogging; },
            routableCmd: new NonSimDirectCmd({
                CmdName: "start record",
                directCmd: function () {
                    AppGlobal.isAjaxLogging = true;
                    //LogAcitveVMDataModelService.callRunSvc();
                }
            })
        });
        _this.StopRecord = tomjector.create(ButtonViewField.name, {
            getViewModel: function () { return _this; },
            fieldName: "record",
            getEditable: function () { return AppGlobal.isAjaxLogging; },
            routableCmd: new NonSimDirectCmd({
                CmdName: "start record",
                directCmd: function () {
                    AppGlobal.isAjaxLogging = false;
                }
            })
        });
        _this.PlayToEnd = new ViewField({
            getViewModel: function () { return _this; },
            fieldName: "PlayToEnd",
            getEditable: function () { return !_this.dataModel.IsPlaying; },
        });
        _this.play = tomjector.create(ButtonViewField.name, {
            getViewModel: function () { return _this; },
            fieldName: "play",
            getEditable: function () { return !NullorEmpty(_this.dataModel.SelectedCmdSession) && !_this.dataModel.IsPlaying; },
            routableCmd: new NonSimDirectCmd({
                CmdName: "start play ",
                directCmd: function () {
                    // this.CmdReader.initRead( this.dataModel.SelectedSession);
                    // this.DataModelReader.initRead( this.dataModel.SelectedSession);
                    // this.simRestorFromShadow();
                    //this.simStartPlayFullContent();
                    _this.dataModel.IsPlaying = true;
                    _this.CmdReader.initRead(_this.dataModel.SelectedCmdSession);
                    _this.DataModelReader.initRead(_this.dataModel.SelectedCmdSession);
                    if (_this.dataModel.PlayToEnd) {
                        _this.simStartPlayFullContent();
                    }
                }
            })
        });
        _this.PlayNext = tomjector.create(ButtonViewField.name, {
            getViewModel: function () { return _this; },
            fieldName: "PlayNext",
            getEditable: function () { return (_this.dataModel.IsPlaying && !_this.dataModel.PlayToEnd); },
            routableCmd: new NonSimDirectCmd({
                CmdName: "PlayNext",
                directCmd: function () {
                    //this.simPlayNextCmd();
                    _this.simRestorFromShadow();
                    if (!_this.CmdReader.hasNextSeq) {
                        alert("sim completed");
                        _this.simStopPlay();
                        return;
                    }
                    setTimeout(function () {
                        _this.simPlayNextCmd();
                        if (!_this.CmdReader.hasNextSeq) {
                            alert("sim completed");
                            _this.simStopPlay();
                        }
                    }, AppGlobal.simLatency);
                }
            })
        });
        /**
         * ********* logger related  **********
         */
        _this.CmdReader = new tomLogReader(CmdContent);
        //protected AjaxReader : tomLogReader<AjaxContent> = new tomLogReader<AjaxContent> (AjaxContent) ;
        _this.DataModelReader = new tomLogReader(DataModelContent);
        return _this;
    }
    /**
     * @return {?}
     */
    SimViewModel.prototype.init = /**
     * @return {?}
     */
    function () {
        _super.prototype.init.call(this);
        // let _getSessionsService = new getSessionsService( 
        //     (result : ServiceResult) =>   this.dataModel.sessions = result.ResultContent
        // )
        // _getSessionsService.runService();
        this.getSessions();
    };
    /**
     * @return {?}
     */
    SimViewModel.prototype.getSessions = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var AllSessions = this.CmdReader.AllSessions.concat(this.DataModelReader.AllSessions);
        //.concat ( this.AjaxReader.AllSessions)
        /** @type {?} */
        var uniqueSessions = Array.from(new Set(AllSessions.map(function (item) { return item; })));
        this.dataModel.cmdSessions = uniqueSessions.map(function (item) { return KeyValueItem.build(item, item); });
        AllSessions = AppGlobal.checkPointReader.AllSessions;
        uniqueSessions = Array.from(new Set(AllSessions.map(function (item) { return item; })));
        this.dataModel.CheckPointSessions = uniqueSessions.map(function (item) { return KeyValueItem.build(item, item); });
    };
    /**
     * @return {?}
     */
    SimViewModel.prototype.simRestorFromShadow = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var logContent = this.DataModelReader.readNext();
        /** @type {?} */
        var actieVM = AppGlobal.appViewModel.getActiveVM();
        actieVM.deserializeDataModel(logContent.content);
        //console.log ( logContent.content);
        //console.log ( actieVM.dataModel);
        actieVM.seq = logContent.content.shadowSeq.RootSeq;
        actieVM.restoreSeqFromShadow();
    };
    /**
     * @return {?}
     */
    SimViewModel.prototype.simStopPlay = /**
     * @return {?}
     */
    function () {
        this.dataModel.IsPlaying = false;
        this.CmdReader.reset();
        this.DataModelReader.reset();
    };
    /**
     * @return {?}
     */
    SimViewModel.prototype.simPlayNextCmd = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var logContent = this.CmdReader.readNext();
        /** @type {?} */
        var seq = logContent.content.ViewNodeSeq;
        //console.log(seq);
        /** @type {?} */
        var vf = (/** @type {?} */ (AppGlobal.appViewModel.getViewNodeBySeq(seq)));
        if (NullorEmpty(vf)) {
            throw tomException.build("viewField not found : seq =" + seq, { source: this.constructor.name, method: "simButtonCmd" });
        }
        else {
            //console.log (vf);
            vf.runCmd();
        }
    };
    /**
     * @param {?=} session
     * @return {?}
     */
    SimViewModel.prototype.simStartPlayFullContent = /**
     * @param {?=} session
     * @return {?}
     */
    function (session) {
        if (!NullorEmpty(session)) {
            this.dataModel.SelectedCmdSession = session;
        }
        this.DataModelReader.initRead(this.dataModel.SelectedCmdSession);
        this.CmdReader.initRead(this.dataModel.SelectedCmdSession);
        this.simPlayContentToEnd();
    };
    /**
     * @return {?}
     */
    SimViewModel.prototype.simPlayCmdToEnd = /**
     * @return {?}
     */
    function () {
        var _this = this;
        setTimeout(function () {
            if (_this.CmdReader.hasNextSeq) {
                _this.simPlayNextCmd();
                _this.simPlayContentToEnd();
            }
            else {
                _this.simStopPlay();
                alert("end of full sim");
            }
        }, AppGlobal.simLatency);
    };
    /**
     * @return {?}
     */
    SimViewModel.prototype.simPlayContentToEnd = /**
     * @return {?}
     */
    function () {
        var _this = this;
        setTimeout(function () {
            if (_this.DataModelReader.hasNextSeq) {
                _this.simRestorFromShadow();
                _this.simPlayCmdToEnd();
            }
            else {
                alert("unexpected play content");
            }
        }, AppGlobal.simLatency);
    };
    return SimViewModel;
}(ViewModel));
/**
 * @abstract
 */
var  /**
 * @abstract
 */
LogCmdBase = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(LogCmdBase, _super);
    function LogCmdBase(init) {
        var _this = _super.call(this, null) || this;
        Object.assign(_this, init);
        return _this;
    }
    return LogCmdBase;
}(NonSimCmd));
var GetSessionCmd = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(GetSessionCmd, _super);
    function GetSessionCmd(init) {
        var _this = _super.call(this, null) || this;
        Object.assign(_this, init);
        return _this;
    }
    /**
     * @return {?}
     */
    GetSessionCmd.prototype.runCmd = /**
     * @return {?}
     */
    function () {
    };
    return GetSessionCmd;
}(LogCmdBase));
/**
 * @abstract
 */
var  /**
 * @abstract
 */
SimServiceBase = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(SimServiceBase, _super);
    function SimServiceBase(completedHandler) {
        var _this = _super.call(this, completedHandler) || this;
        _this.completedHandler = completedHandler;
        _this.CmdLogger = new tomLogReader(CmdContent);
        _this.AjaxLogger = new tomLogReader(AjaxContent);
        return _this;
    }
    return SimServiceBase;
}(ServiceBase));
var getSessionsService = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(getSessionsService, _super);
    function getSessionsService(completedHandler) {
        var _this = _super.call(this, completedHandler) || this;
        _this.completedHandler = completedHandler;
        return _this;
    }
    /**
     * @return {?}
     */
    getSessionsService.prototype.runService = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var AllSessions = this.CmdLogger.AllSessions.concat(this.AjaxLogger.AllSessions);
        /** @type {?} */
        var uniqueSessions = Array.from(new Set(AllSessions.map(function (item) { return item; })));
        /** @type {?} */
        var keyValues = uniqueSessions.map(function (item) { return KeyValueItem.build(item, item); });
        this.completedHandler(new ServiceResult(ServiceReultStates.OK, keyValues));
    };
    return getSessionsService;
}(SimServiceBase));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ListDataModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(ListDataModel, _super);
    function ListDataModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.childrenModels = null;
        return _this;
    }
    return ListDataModel;
}(DataModelBase));
var ViewListModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(ViewListModel, _super);
    function ViewListModel(CtorParam) {
        var _this = _super.call(this) || this;
        _this.ViewModelList = null;
        _this.CtorParam = CtorParam;
        return _this;
    }
    Object.defineProperty(ViewListModel.prototype, "dataModel", {
        get: /**
         * @return {?}
         */
        function () {
            return this._getDataModel();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(ViewListModel.prototype, "subModels", {
        get: /**
         * @protected
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var _ViewModels = new Map();
            this.ViewModelList.forEach(function (model, key) {
                _ViewModels.set(key.toString(), model);
            });
            Object.keys(this).filter(function (key) { return key != "ViewModelList"; })
                .forEach(function (key) {
                /** @type {?} */
                var value = _this[key];
                if (value == null || value === _this.parentViewModel)
                    return;
                if (value instanceof ViewModel) {
                    _ViewModels.set(key, value);
                }
            });
            return _ViewModels;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    ViewListModel.prototype.refreshListView = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this.ViewModelList = this.dataModel.childrenModels.map(function (d) {
            //console.log (d);
            return _this.CtorParam.ItemBuilder(d);
        });
        this.ViewModelList.forEach(function (vm) {
            vm.parentViewModel = _this;
            vm.init();
        });
    };
    /**
     * @return {?}
     */
    ViewListModel.prototype.init = /**
     * @return {?}
     */
    function () {
        this.refreshListView();
        // this.ViewModelList.forEach ( vm => 
        //     {
        //         vm.parentViewModel = this;
        //         vm.init();
        //     }
        // );
        _super.prototype.init.call(this);
    };
    /**
     * @return {?}
     */
    ViewListModel.prototype.attachShadowSeq = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var shadowSeq = new ShadowSeq(this.seq);
        /** @type {?} */
        var subSeqMap = new FiledSeqPairList(this.seq);
        shadowSeq.ChildrenSeqs.push(subSeqMap);
        this.dataModel.shadowSeq = shadowSeq;
        this.ViewFields.forEach(function (field, key) {
            subSeqMap.PairList.push(new FieldSeqPair(key, field.seq));
        });
        this.ViewModelList.forEach(function (vm) {
            vm.attachShadowSeq();
        });
    };
    /**
     * @return {?}
     */
    ViewListModel.prototype.restoreSeqFromShadow = /**
     * @return {?}
     */
    function () {
        var _this = this;
        //let childrenSeqs  =  this.dataModel.shadowSeq.ChildrenSeqs.get( this.seq);
        if (NullorEmpty(this.dataModel.shadowSeq))
            return;
        /** @type {?} */
        var childrenSeqs = this.dataModel.shadowSeq.ChildrenSeqs.filter(function (list) { return list.ParentSeq == _this.seq; })[0];
        childrenSeqs.PairList.forEach(function (fieldSeq) {
            /** @type {?} */
            var field = _this[fieldSeq.key];
            if (NullorEmpty(field)) {
                throw tomException.build("field not found in VM : " + fieldSeq.key, { source: _this.constructor.name, method: "restoreSeqFromShadow" });
            }
            if (!(field instanceof ViewField) && !(field instanceof ViewModel)) {
                throw tomException.build("field not viewfiedl or viewModel : " + fieldSeq.key, { source: _this.constructor.name, method: "restoreSeqFromShadow" });
            }
            field.seq = fieldSeq.value;
        });
        this.subModels.forEach(function (model, key) {
            model.seq = model.dataModel.shadowSeq.RootSeq;
            model.restoreSeqFromShadow();
        });
    };
    return ViewListModel;
}(ViewModel));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var LinkViewField = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(LinkViewField, _super);
    function LinkViewField(bfParam) {
        var _this = this;
        if (NullorEmpty(bfParam.routableCmd)) {
            bfParam.routableCmd = new LinkCmd();
        }
        _this = _super.call(this, bfParam) || this;
        return _this;
    }
    return LinkViewField;
}(ButtonViewField));
var SimpleLinkViewField = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(SimpleLinkViewField, _super);
    function SimpleLinkViewField(vfParam) {
        var _this = _super.call(this, vfParam) || this;
        _this.isDownload = false;
        _this.getDisplayText = vfParam.getDisplayText;
        _this.isDownload = NullorEmpty(vfParam.isDownload) ? false : vfParam.isDownload;
        _this.getFileName = vfParam.getFileName;
        return _this;
    }
    Object.defineProperty(SimpleLinkViewField.prototype, "DisplayText", {
        get: /**
         * @return {?}
         */
        function () {
            return this.getDisplayText();
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SimpleLinkViewField.prototype, "FileName", {
        get: /**
         * @return {?}
         */
        function () {
            return this.getFileName();
        },
        enumerable: true,
        configurable: true
    });
    return SimpleLinkViewField;
}(ViewField));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var FileDataModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(FileDataModel, _super);
    function FileDataModel() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(FileDataModel.prototype, "fileName", {
        get: /**
         * @return {?}
         */
        function () {
            if (NullorEmpty(this.uploadFile))
                return null;
            else
                return this.uploadFile.name;
        },
        enumerable: true,
        configurable: true
    });
    return FileDataModel;
}(DataModelBase));
var FileProcessCmd = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(FileProcessCmd, _super);
    function FileProcessCmd(init) {
        return _super.call(this, init) || this;
    }
    /**
     * @return {?}
     */
    FileProcessCmd.prototype.runCmd = /**
     * @return {?}
     */
    function () {
        var _this = this;
        /** @type {?} */
        var vf = this.getSourceField();
        /** @type {?} */
        var fileReader = new FileReader();
        fileReader.onload = function (e) {
            _this.contentHandler(fileReader.result);
            console.log(fileReader.result);
        };
        fileReader.readAsText(vf.getDataModel().uploadFile);
    };
    /**
     * @return {?}
     */
    FileProcessCmd.prototype.getSourceField = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var vf = (/** @type {?} */ (AppGlobal.appViewModel.getViewNodeBySeq(this.ViewNodeSeq)));
        if (NullorEmpty(vf)) {
            tomException.build("Cannot fild view field ", { source: this.constructor.name, ViewNodeSeq: this.ViewNodeSeq });
        }
        return vf;
    };
    return FileProcessCmd;
}(RoutableCmd));
var FileViewField = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(FileViewField, _super);
    function FileViewField(bfParam) {
        var _this = _super.call(this, bfParam) || this;
        _this.getFieldValue = function () { return _this.getDataModel().uploadFile; };
        _this.setFieldValue = function (file) { return _this.getDataModel().uploadFile = file; };
        return _this;
    }
    return FileViewField;
}(ButtonViewField));
var FileUploadDataModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(FileUploadDataModel, _super);
    function FileUploadDataModel() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Object.defineProperty(FileUploadDataModel.prototype, "formData", {
        get: /**
         * @return {?}
         */
        function () {
            var _this = this;
            /** @type {?} */
            var fd = new FormData();
            fd.append("file", this.uploadFile, this.fileName);
            if (!NullorEmpty(this.extraFields)) {
                Object.keys(this.extraFields).forEach(function (key) {
                    /** @type {?} */
                    var value = _this.extraFields[key];
                    if (NullorEmpty(value)) {
                        return;
                    }
                    fd.append(key, value);
                });
            }
            return fd;
        },
        enumerable: true,
        configurable: true
    });
    return FileUploadDataModel;
}(FileDataModel));
var UploadCmd = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(UploadCmd, _super);
    function UploadCmd(init) {
        return _super.call(this, init) || this;
    }
    /**
     * @return {?}
     */
    UploadCmd.prototype.runCmd = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var vf = this.getSourceField();
        if (!vf.validator()) {
            return;
        }
        /** @type {?} */
        var formData = new FormData();
        //formData.append("file", .uploadSource, this.uploadSource.name);
    };
    /**
     * @return {?}
     */
    UploadCmd.prototype.getSourceField = /**
     * @return {?}
     */
    function () {
        return (/** @type {?} */ (AppGlobal.appViewModel.getViewNodeBySeq(this.ViewNodeSeq)));
    };
    return UploadCmd;
}(RoutableCmd));
var FileUploadViewField = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(FileUploadViewField, _super);
    function FileUploadViewField(bfParam) {
        var _this = _super.call(this, bfParam) || this;
        if (NullorEmpty(bfParam.successCmd) || NullorEmpty(bfParam.failCmd)) {
            throw tomException.build("successCmd and failCmd CANNOT be null : " + bfParam.fieldName + " ", { source: _this.constructor.name });
        }
        _this.successCmd = bfParam.successCmd;
        _this.failCmd = bfParam.failCmd;
        if (NullorEmpty(bfParam.validator))
            _this.validator = function () { return true; };
        return _this;
    }
    return FileUploadViewField;
}(ButtonViewField));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var LogDBDataModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(LogDBDataModel, _super);
    function LogDBDataModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.CmdReader = new tomLogReader(CmdContent);
        _this.DataModelReader = new tomLogReader(DataModelContent);
        _this.CheckResultReader = new tomLogReader(CheckResultContent);
        _this.infoReader = new tomLogReader(InfoContent);
        _this.logTypes = [
            { key: ContentTypes.ajax, value: ContentTypes.ajax },
            { key: ContentTypes.CheckPoint, value: ContentTypes.CheckPoint },
            { key: ContentTypes.CheckResult, value: ContentTypes.CheckResult },
            { key: ContentTypes.DataModel, value: ContentTypes.DataModel },
            { key: ContentTypes.cmd, value: ContentTypes.cmd },
            { key: ContentTypes.info, value: ContentTypes.info },
        ];
        _this.selectedLogType = null;
        return _this;
        //_logContent = null;
        // get LogContent () : LogContent{
        //     if ( [ this.selectedReader, this.selectedSession,  this.selectedSeq].some( p => NullorEmpty(p)) ){
        //         return null;
        //     }    
        //     // console.log ( this.selectedSession);
        //     // console.log ( this.selectedSeq)
        //     // if ( this._logContent == null){
        //     //     this._logContent  = this.selectedReader.read( this.selectedSession, parseInt( this.selectedSeq));
        //     // }
        //     setTimeout(() => {
        //         this._logContent  = this.selectedReader.read( this.selectedSession, parseInt( this.selectedSeq));
        //     }, 5000);
        //     return this._logContent;
        //     // const log = this.selectedReader.read( this.selectedSession, parseInt( this.selectedSeq));
        //     // return log;
        // }
    }
    Object.defineProperty(LogDBDataModel.prototype, "selectedReader", {
        get: /**
         * @return {?}
         */
        function () {
            switch (this.selectedLogType) {
                case ContentTypes.ajax:
                    return AppGlobal.AjaxLogReader;
                case ContentTypes.CheckPoint:
                    return AppGlobal.checkPointReader;
                case ContentTypes.CheckResult:
                    return this.CheckResultReader;
                case ContentTypes.DataModel:
                    return this.DataModelReader;
                case ContentTypes.cmd:
                    return this.CmdReader;
                case ContentTypes.info:
                    return this.infoReader;
                default:
                    return null;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LogDBDataModel.prototype, "Sesssions", {
        get: /**
         * @return {?}
         */
        function () {
            if (NullorEmpty(this.selectedReader)) {
                return [];
            }
            /** @type {?} */
            var sessions = getUniq(this.selectedReader.AllSessions).map(function (item) { return KeyValueItem.build(item, item); });
            return sessions;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LogDBDataModel.prototype, "selectedSession", {
        get: /**
         * @return {?}
         */
        function () {
            if (NullorEmpty(this.selectedReader))
                return null;
            return this.selectedReader.CurrentSession;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (NullorEmpty(this.selectedReader)) {
                throw tomException.build("reader not selected yet ", { source: this.constructor.name, method: "selectedSession" });
            }
            this.selectedReader.CurrentSession = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LogDBDataModel.prototype, "seqs", {
        get: /**
         * @return {?}
         */
        function () {
            if (NullorEmpty(this.selectedReader) || NullorEmpty(this.selectedSession)) {
                return [];
            }
            return this.selectedReader.SeqsOfCurrentSession.map(function (item) { return KeyValueItem.build(item, item); });
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    LogDBDataModel.prototype.readLogContent = /**
     * @return {?}
     */
    function () {
        this.isShowJSON = false;
        if ([this.selectedReader, this.selectedSession, this.selectedSeq].some(function (p) { return NullorEmpty(p); })) {
            this.LogContent = "";
        }
        else {
            /** @type {?} */
            var log = this.selectedReader.read(this.selectedSession, parseInt(this.selectedSeq));
            if (NullorEmpty(log)) {
                throw tomException.build("unexpected null log", { source: this.constructor.name, method: "readLogContent" });
            }
            //this.LogContent = JSON.stringify(log);
            this.LogContent = log;
        }
    };
    Object.defineProperty(LogDBDataModel.prototype, "LogKey", {
        get: /**
         * @return {?}
         */
        function () {
            if (NullorEmpty(this.LogContent)) {
                return "nanthing";
            }
            else {
                return this.selectedReader.itemKey(this.selectedSession, parseInt(this.selectedSeq));
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(LogDBDataModel.prototype, "JSONhref", {
        get: /**
         * @return {?}
         */
        function () {
            if (NullorEmpty(this.LogContent)) {
                return "javascript:alert('nothing')_";
            }
            else {
                /** @type {?} */
                var text = JSON.stringify(this.LogContent);
                /** @type {?} */
                var url = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
                return url;
            }
        },
        enumerable: true,
        configurable: true
    });
    return LogDBDataModel;
}(DataModelBase));
var AutoTestResultDataModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(AutoTestResultDataModel, _super);
    function AutoTestResultDataModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.LeftLogDB = new LogDBDataModel();
        _this.RightLogDB = new LogDBDataModel();
        _this.SessionIO = new SessionIODataModel();
        _this.CheckResultReader = new tomLogReader(CheckResultContent);
        _this.childrenModels = [];
        return _this;
    }
    Object.defineProperty(AutoTestResultDataModel.prototype, "Sesssions", {
        get: /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var sessions = getUniq(this.CheckResultReader.AllSessions).map(function (item) { return KeyValueItem.build(item, item); });
            return sessions;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AutoTestResultDataModel.prototype, "selectedSession", {
        get: /**
         * @return {?}
         */
        function () {
            return this.CheckResultReader.CurrentSession;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.CheckResultReader.CurrentSession = value;
        },
        enumerable: true,
        configurable: true
    });
    //CheckPointResults : CheckResultContent[] = null;
    //CheckPointResults : CheckResultContent[] = null;
    /**
     * @return {?}
     */
    AutoTestResultDataModel.prototype.readTestResults = 
    //CheckPointResults : CheckResultContent[] = null;
    /**
     * @return {?}
     */
    function () {
        if (NullorEmpty(this.selectedSession)) {
            this.childrenModels = [];
        }
        this.childrenModels = this.CheckResultReader.FullLogs;
    };
    return AutoTestResultDataModel;
}(ListDataModel));
var LogDBViewModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(LogDBViewModel, _super);
    function LogDBViewModel(CtorParam) {
        if (CtorParam === void 0) { CtorParam = null; }
        var _this = _super.call(this, CtorParam) || this;
        _this.vfSelectedLogType = new SelectViewField({
            getViewModel: function () { return _this; },
            fieldName: "selectedLogType",
            getOptionList: function () { return _this.dataModel.logTypes; },
            validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
        _this.vfSelectedSession = new SelectViewField({
            getViewModel: function () { return _this; },
            fieldName: "selectedSession",
            getOptionList: function () { return _this.dataModel.Sesssions; },
            validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
        _this.vfSelectedSeq = new SelectViewField({
            getViewModel: function () { return _this; },
            fieldName: "selectedSeq",
            getOptionList: function () { return _this.dataModel.seqs; },
            validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
        _this.vfLogContent = new ViewField({
            getViewModel: function () { return _this; },
            fieldName: "LogContent",
        });
        _this.vfLogJsonLink = new SimpleLinkViewField({
            getViewModel: function () { return _this; },
            fieldName: "JSONhref",
            getDisplayText: function () { return _this.dataModel.LogKey; },
            getFieldValue: function () { return _this.dataModel.JSONhref; },
            getFileName: function () { return _this.dataModel.LogKey; },
            isDownload: true
        });
        _this.vfCmdShowContent = tomjector.create(ButtonViewField.name, {
            getViewModel: function () { return _this; },
            fieldName: "ShowLogContent",
            routableCmd: new NonSimDirectCmd({
                CmdName: "ShowLogContent",
                directCmd: function () { return _this.dataModel.readLogContent(); }
            })
        });
        _this.vfIsShowJSON = new ViewField({
            getViewModel: function () { return _this; },
            fieldName: "isShowJSON",
        });
        return _this;
    }
    return LogDBViewModel;
}(ViewModel));
var CheckResultViewModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(CheckResultViewModel, _super);
    function CheckResultViewModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.vfLogSeq = new ViewField({
            getViewModel: function () { return _this; },
            fieldName: "LogSeq",
        });
        _this.vfCheckPointName = new ViewField({
            getViewModel: function () { return _this; },
            fieldName: "CheckPointName",
        });
        _this.vfIsResultMatch = new ViewField({
            getViewModel: function () { return _this; },
            fieldName: "isResultMatch",
        });
        _this.vfCmdShowLog = tomjector.create(ButtonViewField.name, {
            getViewModel: function () { return _this; },
            fieldName: "CmdShowLog",
            routableCmd: new NonSimDirectCmd({
                CmdName: "CmdShowLog",
                directCmd: function () { return console.log(_this.dataModel); }
            })
        });
        return _this;
    }
    return CheckResultViewModel;
}(ViewModel));
var SessionIODataModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(SessionIODataModel, _super);
    function SessionIODataModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.sessionManager = new SessionMgr();
        _this.uploadFile = new FileDataModel();
        return _this;
    }
    Object.defineProperty(SessionIODataModel.prototype, "sesssions", {
        get: /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var sessions = this.sessionManager.sessions.map(function (item) { return KeyValueItem.build(item, item); });
            return sessions;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionIODataModel.prototype, "selectedSession", {
        get: /**
         * @return {?}
         */
        function () {
            return this.sessionManager.CurrentSession;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.sessionManager.CurrentSession = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SessionIODataModel.prototype, "exportedSessionUrl", {
        get: /**
         * @return {?}
         */
        function () {
            if (NullorEmpty(this.selectedSession))
                return null;
            this.sessionManager.CurrentSession = this.selectedSession;
            /** @type {?} */
            var sessionExported = this.sessionManager.FullExportSession;
            /** @type {?} */
            var content = JSON.stringify(sessionExported);
            /** @type {?} */
            var url = URL.createObjectURL(new Blob([content], { type: "text/plain" }));
            return url;
        },
        enumerable: true,
        configurable: true
    });
    return SessionIODataModel;
}(DataModelBase));
var SessionIOViewModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(SessionIOViewModel, _super);
    function SessionIOViewModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.vfExportedSessionLink = new SimpleLinkViewField({
            getViewModel: function () { return _this; },
            fieldName: "exportedSession",
            getDisplayText: function () { return _this.dataModel.selectedSession; },
            getFieldValue: function () { return _this.dataModel.exportedSessionUrl; },
            getFileName: function () { return _this.dataModel.selectedSession + ".json"; },
            isDownload: true
        });
        _this.vfUploadFile = new FileViewField({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel.uploadFile; },
            fieldName: "UploadFile",
            routableCmd: new FileProcessCmd({
                CmdName: "process upload file",
                contentHandler: function (content) {
                    console.log("content" + content);
                    try {
                        /** @type {?} */
                        var session = (/** @type {?} */ (JSON.parse(content)));
                        _this.dataModel.sessionManager.importSession(session);
                    }
                    catch (e) {
                        console.log("error");
                        console.log(e);
                    }
                }
            })
        });
        _this.vfSelectedSession = new SelectViewField({
            getViewModel: function () { return _this; },
            fieldName: "selectedSession",
            getOptionList: function () { return _this.dataModel.sesssions; },
            validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
        return _this;
    }
    return SessionIOViewModel;
}(ViewModel));
var AutoTestResultViewModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(AutoTestResultViewModel, _super);
    function AutoTestResultViewModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.vmLeftLogDB = new LogDBViewModel({ DataModel: function () { return _this.dataModel.LeftLogDB; } });
        _this.vmRightLogDB = new LogDBViewModel({ DataModel: function () { return _this.dataModel.RightLogDB; } });
        _this.vmSessionIO = new SessionIOViewModel({ DataModel: function () { return _this.dataModel.SessionIO; } });
        _this.vfSelectedSession = new SelectViewField({
            getViewModel: function () { return _this; },
            fieldName: "selectedSession",
            getOptionList: function () { return _this.dataModel.Sesssions; },
            validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
        _this.vfCmdListCheckPointResults = tomjector.create(ButtonViewField.name, {
            getViewModel: function () { return _this; },
            fieldName: "ListCheckPointResults",
            routableCmd: new NonSimDirectCmd({
                CmdName: "ListCheckPointResults",
                directCmd: function () {
                    _this.dataModel.readTestResults();
                    _this.refreshListView();
                    console.log(_this.dataModel.childrenModels);
                    console.log(_this.ViewModelList);
                }
            })
        });
        _this.ViewModelList = [];
        return _this;
    }
    return AutoTestResultViewModel;
}(ViewListModel));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @enum {number} */
var SimulationModes = {
    none: 0,
    simulating: 1,
    recording: 2,
};
SimulationModes[SimulationModes.none] = 'none';
SimulationModes[SimulationModes.simulating] = 'simulating';
SimulationModes[SimulationModes.recording] = 'recording';
var AppDataModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(AppDataModel, _super);
    function AppDataModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.SimModel = new SimDataModel();
        _this.LogDBModel = new LogDBDataModel();
        _this.AuotTestModel = new AutoTestResultDataModel();
        _this.CmdSeq = 0;
        _this.UniqNo = 0;
        _this.session = null;
        _this.AjaxSeq = 0;
        _this.DataSeq = 0;
        _this.CheckPointSeq = 0;
        _this.CheckResultSeq = 0;
        _this.InfoSeq = 0;
        return _this;
    }
    return AppDataModel;
}(DataModelBase));
/**
 * @abstract
 */
var  /**
 * @abstract
 */
AppViewModel = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(AppViewModel, _super);
    function AppViewModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.SimulationMode = SimulationModes.none;
        _this.NextSeq = 0;
        _this.PageModels = [];
        _this.SimVM = new SimViewModel({ DataModel: function () { return _this.dataModel.SimModel; } });
        //LogVM : LogDBViewModel = new LogDBViewModel( { DataModel :() => this.dataModel.LogDBModel});
        _this.AutoTestVM = new AutoTestResultViewModel({
            DataModel: function () { return _this.dataModel.AuotTestModel; },
            ItemBuilder: function (content) { return new CheckResultViewModel({
                DataModel: function () { return content; }
            }); }
        });
        //ActiveVM : ViewModel;
        _this.getActiveVM = null;
        _this.VisibleSettings = [];
        _this.EditSettings = [];
        _this.IAppViewModel_identity = true;
        return _this;
    }
    /**
     * @param {?} viewNode
     * @return {?}
     */
    AppViewModel.prototype.incrementSeq = /**
     * @param {?} viewNode
     * @return {?}
     */
    function (viewNode) {
        viewNode.seq = this.NextSeq;
        this.NextSeq++;
    };
    Object.defineProperty(AppViewModel.prototype, "subModels", {
        get: /**
         * @protected
         * @return {?}
         */
        function () {
            /** @type {?} */
            var _ViewModels = new Map();
            this.PageModels.forEach(function (model, key) {
                _ViewModels.set(key.toString(), model);
            });
            _ViewModels.set("AutoTestVM", this.AutoTestVM);
            _ViewModels.set("SimVM", this.SimVM);
            return _ViewModels;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    AppViewModel.prototype.init = /**
     * @return {?}
     */
    function () {
        this.SimVM.parentViewModel = this;
        this.SimVM.init();
        this.SimVM.furnish();
        // this.LogVM.parentViewModel = this;
        // this.LogVM.init();
        // this.LogVM.furnish();
        this.AutoTestVM.parentViewModel = this;
        this.AutoTestVM.init();
        this.AutoTestVM.furnish();
        console.log(this);
    };
    /**
     * @param {?} model
     * @return {?}
     */
    AppViewModel.prototype.appendPageRootModel = /**
     * @param {?} model
     * @return {?}
     */
    function (model) {
        model.parentViewModel = this;
        this.PageModels.push(model);
        //this.subModels.push ( model);
    };
    /**
     * @param {?} seq
     * @return {?}
     */
    AppViewModel.prototype.getViewNodeBySeq = /**
     * @param {?} seq
     * @return {?}
     */
    function (seq) {
        /** @type {?} */
        var viewNode = null;
        this.traverseNodes(function (key, field, model) {
            if (seq == field.seq) {
                viewNode = field;
            }
        }, function (key, model) {
            if (seq == model.seq) {
                viewNode = model;
            }
        });
        return viewNode;
    };
    Object.defineProperty(AppViewModel.prototype, "showErrorMsg", {
        get: /**
         * @return {?}
         */
        function () {
            return false;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppViewModel.prototype, "DefaultEditable", {
        get: /**
         * @return {?}
         */
        function () {
            return true;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppViewModel.prototype, "DefaultVisible", {
        get: /**
         * @return {?}
         */
        function () {
            return true;
        },
        enumerable: true,
        configurable: true
    });
    return AppViewModel;
}(ViewModel));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var ComplexComponentBase = /** @class */ (function () {
    function ComplexComponentBase(injector) {
        this.isBinded = false;
        this._viewModel = null;
        this.dataModel = null;
        this.injector = injector;
        this.htmlEle = injector.get(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"]);
        this.router = injector.get(_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]);
        this.activeRoute = injector.get(_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]);
    }
    Object.defineProperty(ComplexComponentBase.prototype, "viewModel", {
        get: /**
         * @return {?}
         */
        function () {
            return this._viewModel;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (NullorEmpty(value))
                return;
            value.VirtualModelComponent = this;
            this._viewModel = value;
            if (!value.visible) {
                //console.log ( "invisilbe" );
                this.htmlEle.nativeElement.outerHTML = "";
            }
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    ComplexComponentBase.prototype.ifShowErrMsg = /**
     * @return {?}
     */
    function () {
        if (NullorEmpty(this.viewModel)) {
            return false;
        }
        //console.log ( this.viewModel.valid);
        return !this.viewModel.valid;
    };
    /**
     * @return {?}
     */
    ComplexComponentBase.prototype.InitBinding = /**
     * @return {?}
     */
    function () {
        this.isBinded = true;
        //console.log ( this.FieldComps);
        // this.FieldComps.forEach( 
        //     field => {
        //         console.log ( field);
        //         field.InitBinding();
        //     }
        // );
    };
    /**
     * @return {?}
     */
    ComplexComponentBase.prototype.debug_logVM = /**
     * @return {?}
     */
    function () {
        console.log(this.viewModel);
    };
    ComplexComponentBase.propDecorators = {
        viewModel: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["Input"] }]
    };
    return ComplexComponentBase;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var DateViewField = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(DateViewField, _super);
    function DateViewField(vfParam) {
        return _super.call(this, vfParam) || this;
    }
    /**
     * @return {?}
     */
    DateViewField.prototype.createErrorMsgMap = /**
     * @return {?}
     */
    function () {
        _super.prototype.createErrorMsgMap.call(this);
        this.ErrorMsgMap["ngbDate"] = "Date Format Error";
    };
    return DateViewField;
}(ViewField));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var FieldComponentBase = /** @class */ (function () {
    function FieldComponentBase(injector) {
        this.isBinded = false;
        this.htmlEle = injector.get(_angular_core__WEBPACK_IMPORTED_MODULE_6__["ElementRef"]);
        this.router = injector.get(_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]);
    }
    Object.defineProperty(FieldComponentBase.prototype, "disabled", {
        get: /**
         * @return {?}
         */
        function () {
            return !this._viewField.editable;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FieldComponentBase.prototype, "viewField", {
        get: /**
         * @return {?}
         */
        function () {
            return this._viewField;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (NullorEmpty(value))
                return;
            this._viewField = value;
            if (!value.visible) {
                //console.log ( "invisilbe" );
                this.htmlEle.nativeElement.outerHTML = "";
            }
            else {
                this._viewField.VirtualFieldComponent = this;
            }
            this._viewField.VirtualFieldComponent = this;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(FieldComponentBase.prototype, "showErrMsg", {
        get: /**
         * @return {?}
         */
        function () {
            // console.log (this.ValueInput);
            // console.log ( this.viewField.valid );
            // console.log (this.ValueInput);
            // console.log ( this.viewField.valid );
            /** @type {?} */
            var b = (this.ValueInput.touched || this.ValueInput.dirty || this.viewField.showErrorMsg) && !this.viewField.valid;
            //let b : boolean = !this.viewField.valid
            return b;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    FieldComponentBase.prototype.InitBinding = /**
     * @return {?}
     */
    function () {
        //this.isBinded = true;
    };
    /**
     * @param {?} commands
     * @param {?=} extras
     * @return {?}
     */
    FieldComponentBase.prototype.navigate = /**
     * @param {?} commands
     * @param {?=} extras
     * @return {?}
     */
    function (commands, extras) {
        return this.router.navigate(commands);
    };
    /**
     * @return {?}
     */
    FieldComponentBase.prototype.forceValidation = /**
     * @return {?}
     */
    function () {
        //console.log ("entering");
        if (NullorEmpty(this.ValueInput))
            return;
        //throw tomException.build ( "ValueInput is null");
        //console.log ("validating");
        this.ValueInput.control.markAsTouched({ onlySelf: false }); // {3}
        this.ValueInput.control.markAsDirty({ onlySelf: false });
        this.ValueInput.control.updateValueAndValidity();
    };
    /**
     * @param {?} validators
     * @return {?}
     */
    FieldComponentBase.prototype.setValidators = /**
     * @param {?} validators
     * @return {?}
     */
    function (validators) {
        if (NullorEmpty(this.ValueInput))
            return;
        //throw tomException.build ( "ValueInput is null");
        this.ValueInput.control.markAsTouched({ onlySelf: false }); // {3}
        this.ValueInput.control.markAsDirty({ onlySelf: false });
        //console.log ( "validators for " + this.viewField.fieldName)
        //console.log ( validators.length);
        /** @type {?} */
        var vdator = this.ValueInput.control.validator;
        if (!NullorEmpty(vdator)) {
            if (validators.every(function (value, index) { return value != vdator; })) {
                validators.push(vdator);
            }
        }
        this.ValueInput.control.setValidators(this.viewField.validators);
        //console.log ( validators.length);
    };
    /**
     * @return {?}
     */
    FieldComponentBase.prototype.errors = /**
     * @return {?}
     */
    function () {
        if (NullorEmpty(this.ValueInput))
            return null;
        //throw tomException.build ( "ValueInput is null");
        return this.ValueInput.control.errors;
    };
    FieldComponentBase.propDecorators = {
        viewField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["Input"] }],
        label: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["Input"] }],
        placeholder: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["Input"] }],
        ValueInput: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"], args: ["ValueInput",] }]
    };
    return FieldComponentBase;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TraversorOutArg = /** @class */ (function () {
    function TraversorOutArg() {
        this.path = null;
        this.isLeaf = false;
    }
    Object.defineProperty(TraversorOutArg.prototype, "nodeType", {
        get: /**
         * @return {?}
         */
        function () {
            return typeof this.nodeValue;
        },
        enumerable: true,
        configurable: true
    });
    return TraversorOutArg;
}());
var TraversorInArg = /** @class */ (function () {
    function TraversorInArg() {
        this.path = "";
        this.shouldTerminate = false;
    }
    /**
     * @param {?} OutArg
     * @return {?}
     */
    TraversorInArg.prototype.handleNode = /**
     * @param {?} OutArg
     * @return {?}
     */
    function (OutArg) {
        return null;
    };
    return TraversorInArg;
}());
var tomTraversor = /** @class */ (function () {
    function tomTraversor() {
    }
    /**
     * @param {?} inArg
     * @return {?}
     */
    tomTraversor.prototype.travers = /**
     * @param {?} inArg
     * @return {?}
     */
    function (inArg) {
        var _this = this;
        if (!inArg.sourceObject)
            return;
        /** @type {?} */
        var targetObj = inArg.sourceObject;
        if (isPrimitive(targetObj)) {
            /** @type {?} */
            var outArg = new TraversorOutArg();
            outArg.isLeaf = true;
            outArg.nodeValue = targetObj;
            outArg.path = inArg.path;
            outArg.nodeKey = "root";
            inArg.handleNode(outArg);
        }
        else {
            Object.keys(targetObj).forEach(function (key) {
                /** @type {?} */
                var outArg = new TraversorOutArg();
                if (isArray(targetObj)) {
                    outArg.path = inArg.path + "/[]";
                }
                else {
                    outArg.path = inArg.path + "/" + key;
                }
                /** @type {?} */
                var value = targetObj[key];
                outArg.nodeValue = value;
                outArg.nodeKey = key;
                if (isPrimitive(value)) {
                    outArg.isLeaf = true;
                    inArg.handleNode(outArg);
                }
                else {
                    /** @type {?} */
                    var newInArg = inArg.handleNode(outArg);
                    if (!NullorEmpty(newInArg) && newInArg.shouldTerminate) {
                        return;
                    }
                    if (!newInArg) {
                        newInArg = new TraversorInArg();
                        newInArg.handleNode = inArg.handleNode;
                        newInArg.path = outArg.path;
                        newInArg.sourceObject = value;
                    }
                    _this.travers(newInArg);
                }
            });
        }
    };
    return tomTraversor;
}());
/**
 * @param {?} targetObj
 * @param {?} NodeHandler
 * @return {?}
 */
function travers(targetObj, NodeHandler) {
    /** @type {?} */
    var inArg = new TraversorInArg();
    inArg.sourceObject = targetObj;
    inArg.handleNode = NodeHandler;
    /** @type {?} */
    var traversor = new tomTraversor();
    traversor.travers(inArg);
}
var CloneTraversorInArg = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_4__["__extends"])(CloneTraversorInArg, _super);
    function CloneTraversorInArg(sourceObj, targetObj, skipper) {
        var _this = _super.call(this) || this;
        _this.targetObj = targetObj;
        _this.skipper = skipper;
        _this.sourceObject = sourceObj;
        return _this;
    }
    /**
     * @param {?} OutArg
     * @return {?}
     */
    CloneTraversorInArg.prototype.handleNode = /**
     * @param {?} OutArg
     * @return {?}
     */
    function (OutArg) {
        /** @type {?} */
        var ExitInArg = new TraversorInArg();
        ExitInArg.shouldTerminate = true;
        if (!NullorEmpty(this.skipper) && this.skipper(OutArg)) {
            return ExitInArg;
        }
        if (isPrimitive(OutArg.nodeValue)) {
            this.targetObj[OutArg.nodeKey] = OutArg.nodeValue;
            return ExitInArg;
        }
        /** @type {?} */
        var newTargetObj = null;
        if (isArray(OutArg.nodeValue)) {
            newTargetObj = [];
        }
        else {
            newTargetObj = new Object();
        }
        this.targetObj[OutArg.nodeKey] = newTargetObj;
        /** @type {?} */
        var DrillInArg = new CloneTraversorInArg(OutArg.nodeValue, newTargetObj, this.skipper);
        return DrillInArg;
    };
    /**
     * @param {?} source
     * @param {?=} skipper
     * @return {?}
     */
    CloneTraversorInArg.clone = /**
     * @param {?} source
     * @param {?=} skipper
     * @return {?}
     */
    function (source, skipper) {
        /** @type {?} */
        var target = isArray(source) ? [] : new Object();
        /** @type {?} */
        var inArg = new CloneTraversorInArg(source, target, skipper);
        /** @type {?} */
        var traversor = new tomTraversor();
        traversor.travers(inArg);
        return target;
    };
    return CloneTraversorInArg;
}(TraversorInArg));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var AppSetting = /** @class */ (function () {
    function AppSetting(injector) {
        this.injector = undefined;
        //  readonly PostHeader  = new HttpHeaders({'Content-Type':'application/json; charset=utf-8', 'Authorization': 'Basic RVJJQ0NIRU46ZUJhbzEyMzQ='});      
        //  readonly GetHeader =  new HttpHeaders({'Content-Type':'application/json; charset=utf-8', 'Authorization': 'Basic RVJJQ0NIRU46ZUJhbzEyMzQ='});      
        //  readonly UploadHeader = new HttpHeaders({ "userid": "50000004","usergroup": "dev", "username":"50000004"});
        this.PostHeader = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpHeaders"]({ 'Content-Type': 'application/json; charset=utf-8', "userid": "50000003", "usergroup": "dev", "username": "50000004" });
        this.GetHeader = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpHeaders"]({ 'Content-Type': 'application/json; charset=utf-8', "userid": "50000003", "usergroup": "dev", "username": "50000004" });
        this.UploadHeader = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpHeaders"]({ "userid": "50000004", "usergroup": "dev", "username": "50000004" });
        this.cmdRouter = new CmdRouter();
        this.injector = injector;
    }
    return AppSetting;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomFismComponent = /** @class */ (function () {
    function TomFismComponent() {
    }
    /**
     * @return {?}
     */
    TomFismComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    TomFismComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["Component"], args: [{
                    selector: 'lib-TomFism',
                    template: "\n    <p>\n      tomfism works!\n    </p>\n  "
                }] }
    ];
    /** @nocollapse */
    TomFismComponent.ctorParameters = function () { return []; };
    return TomFismComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var tomjectorSetting$1 = /** @class */ (function () {
    function tomjectorSetting(id, ctro) {
        this.id = null;
        this.id = id;
        this.ctro = ctro;
    }
    return tomjectorSetting;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var AppDIMap = /** @class */ (function () {
    function AppDIMap() {
    }
    /**
     * @return {?}
     */
    AppDIMap.overwriteDI = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var jectorSetting = new tomjectorSetting$1(AppSetting.name, function (paramContainer) { return new AppSetting(paramContainer.firstParam); });
        AppGlobal.DIMap[jectorSetting.id] = jectorSetting;
        jectorSetting = new tomjectorSetting$1(ButtonViewField.name, function (paramContainer) { return new ButtonViewField(paramContainer.firstParam); });
        AppGlobal.DIMap[jectorSetting.id] = jectorSetting;
    };
    return AppDIMap;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomFismModule = /** @class */ (function () {
    function TomFismModule() {
    }
    TomFismModule.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["NgModule"], args: [{
                    declarations: [TomFismComponent],
                    imports: [],
                    exports: [TomFismComponent]
                },] }
    ];
    return TomFismModule;
}());
var tomfismApp = /** @class */ (function () {
    function tomfismApp(injector) {
        this.injector = injector;
        AppGlobal.injector = injector;
        this.setupDIMap();
        console.log(AppGlobal.DIMap);
        AppGlobal.setting = tomjector.create(AppSetting.name, null);
    }
    /**
     * @protected
     * @return {?}
     */
    tomfismApp.prototype.setupDIMap = /**
     * @protected
     * @return {?}
     */
    function () {
        AppDIMap.overwriteDI();
        // let jectorSetting = new tomjectorSetting(
        //   AppSetting.name, 
        //   (paramContainer) => new AppSetting ( this.injector)
        // );
        // AppGlobal.DIMap[ jectorSetting.id ]  = jectorSetting;
    };
    return tomfismApp;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var AppDIMap$1 = /** @class */ (function () {
    function AppDIMap() {
    }
    /**
     * @return {?}
     */
    AppDIMap.overwriteDI = /**
     * @return {?}
     */
    function () {
        /** @type {?} */
        var jectorSetting = new tomjectorSetting(AppSetting.name, function (paramContainer) { return new AppSetting(paramContainer.firstParam); });
        AppGlobal.DIMap[jectorSetting.id] = jectorSetting;
        jectorSetting = new tomjectorSetting(ButtonViewField.name, function (paramContainer) { return new ButtonViewField(paramContainer.firstParam); });
        AppGlobal.DIMap[jectorSetting.id] = jectorSetting;
    };
    return AppDIMap;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */



//# sourceMappingURL=tomfism.js.map

/***/ }),

/***/ "./dist/tomgular/fesm5/tomgular.js":
/*!*****************************************!*\
  !*** ./dist/tomgular/fesm5/tomgular.js ***!
  \*****************************************/
/*! exports provided: TomTextComponent, TomButtonComponent, TomCheckBoxComponent, TomDateBoxComponent, TomDebuggerComponent, TomInputBoxComponent, TomMsgListComponent, TomRadioComponent, TomSelectComponent, TomVisibleDirective, TomModule, SimDriverComponent, SimpleLinkComponent, TomButtonInputComponent, TomCmdLinkComponent, TomClickableDirective, tomLink, TomCheckPointResultComponent, TomFileComponent, TomLogComponent, TomPopupComponent, TomTextAreaComponent, TomTextBoxComponent, TomUploaderComponent, TomViewPaginatorComponent, TomViewTableComponent, TomViewSortDirective, TomSessionMgrComponent, LogViewerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomTextComponent", function() { return TomTextComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomButtonComponent", function() { return TomButtonComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomCheckBoxComponent", function() { return TomCheckBoxComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomDateBoxComponent", function() { return TomDateBoxComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomDebuggerComponent", function() { return TomDebuggerComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomInputBoxComponent", function() { return TomInputBoxComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomMsgListComponent", function() { return TomMsgListComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomRadioComponent", function() { return TomRadioComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomSelectComponent", function() { return TomSelectComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomVisibleDirective", function() { return TomVisibleDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomModule", function() { return TomModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SimDriverComponent", function() { return SimDriverComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SimpleLinkComponent", function() { return SimpleLinkComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomButtonInputComponent", function() { return TomButtonInputComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomCmdLinkComponent", function() { return TomCmdLinkComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomClickableDirective", function() { return TomClickableDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "tomLink", function() { return tomLink; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomCheckPointResultComponent", function() { return TomCheckPointResultComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomFileComponent", function() { return TomFileComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomLogComponent", function() { return TomLogComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomPopupComponent", function() { return TomPopupComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomTextAreaComponent", function() { return TomTextAreaComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomTextBoxComponent", function() { return TomTextBoxComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomUploaderComponent", function() { return TomUploaderComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomViewPaginatorComponent", function() { return TomViewPaginatorComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomViewTableComponent", function() { return TomViewTableComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomViewSortDirective", function() { return TomViewSortDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TomSessionMgrComponent", function() { return TomSessionMgrComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogViewerComponent", function() { return LogViewerComponent; });
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var ngx_json_viewer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-json-viewer */ "./node_modules/ngx-json-viewer/ngx-json-viewer.es5.js");









/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomTextComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomTextComponent, _super);
    function TomTextComponent(injector) {
        return _super.call(this, injector) || this;
    }
    /**
     * @return {?}
     */
    TomTextComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    TomTextComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-text',
                    template: "<label *ngIf=\"label\" >{{label}}</label>\n<div class=\"form-group\">\n    <label>\n      <span>{{viewField.FieldValue}}</span>\n    </label>\n  </div>\n",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomTextComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return TomTextComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomButtonComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomButtonComponent, _super);
    function TomButtonComponent(injector) {
        return _super.call(this, injector) || this;
    }
    Object.defineProperty(TomButtonComponent.prototype, "isReady", {
        get: /**
         * @return {?}
         */
        function () {
            return (!Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this._viewField) && this._viewField.visible);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TomButtonComponent.prototype, "viewField", {
        get: /**
         * @return {?}
         */
        function () {
            return this._viewField;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(value)) {
                throw TomFism__WEBPACK_IMPORTED_MODULE_5__["tomException"].build("viewField is set to null pointer. Pls check viewField Path", { source: this.constructor.name });
            }
            this._viewField = value;
            if (!value.visible) {
                //console.log ( "invisilbe" );
                this.htmlEle.nativeElement.outerHTML = "";
            }
            else {
                this._viewField.VirtualFieldComponent = this;
            }
            this._viewField.VirtualFieldComponent = this;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    TomButtonComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    Object.defineProperty(TomButtonComponent.prototype, "CmdLabel", {
        get: /**
         * @return {?}
         */
        function () {
            if (this.isReady && Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this.label) && !Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this.viewField.getFieldValue))
                return this.viewField.FieldValue;
            else
                return this.label;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    TomButtonComponent.prototype.ngAfterViewChecked = /**
     * @return {?}
     */
    function () {
        // this.ValueInput.control.setValidators( this.viewField.validators);
        // this.viewField.errors = () => this.ValueInput.control.errors;
    };
    /**
     * @return {?}
     */
    TomButtonComponent.prototype.click = /**
     * @return {?}
     */
    function () {
        //console.log (AppGlobal.setting.cmdRouter);
        //console.log ( this.viewField.getViewModel().appViewModel.cmdRouter);
        ((/** @type {?} */ (this.viewField))).runCmd();
    };
    TomButtonComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-button',
                    template: "\n\n<button [disabled]=\"disabled\" *ngIf=\" isReady\" class=\"btn input-sm btn-warning\" (click)=\"click()\">\n    <!-- <div #ref style=\"padding: 0px\"><ng-content></ng-content></div> \n    <span *ngIf=\"ref.nativeElement.childNodes?.length == 0\" style=\"padding: 0px\">\n      {{CmdLabel}}\n    </span> -->\n    <ng-content></ng-content>\n      {{CmdLabel}}\n</button>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomButtonComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    TomButtonComponent.propDecorators = {
        viewField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }]
    };
    return TomButtonComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomCheckBoxComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomCheckBoxComponent, _super);
    //@Input() viewField : ViewField 
    //  @ViewChild("ValueInput") ValueInput : any
    function TomCheckBoxComponent(injector) {
        var _this = _super.call(this, injector) || this;
        _this.UniqueName = "";
        return _this;
    }
    /**
     * @return {?}
     */
    TomCheckBoxComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        //this.viewContainer.clear();
        this.UniqueName = "checkbox-" + TomFism__WEBPACK_IMPORTED_MODULE_5__["AppGlobal"].NextUniqNo.toString();
        //this.viewField.errors = () => new Object();
    };
    /**
     * @return {?}
     */
    TomCheckBoxComponent.prototype.ngAfterContentInit = /**
     * @return {?}
     */
    function () {
        // if ( this.ValueInput == undefined )
        // {
        //   console.log ( 'no #');
        //   console.log ( this.ValueInput);
        //   return;
        // }
        // this.ValueInput.control.setValidators( this.viewField.validators);
        // this.viewField.errors = () => this.ValueInput.control.errors;
    };
    Object.defineProperty(TomCheckBoxComponent.prototype, "checkboxValue", {
        //_checkboxValue : boolean = true;
        get: 
        //_checkboxValue : boolean = true;
        /**
         * @return {?}
         */
        function () {
            return this.viewField.FieldValue; // == "true";
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            //console.log ( value);
            //this._checkboxValue = value;
            this.viewField.FieldValue = value;
            //( value ? "true": "false");
        },
        enumerable: true,
        configurable: true
    });
    TomCheckBoxComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-check-box',
                    template: "<!-- <label>\n    <input \n    class=\"custom \" \n    name=\"checkbox\"\n    #ValueInput=\"ngModel\"\n    type=\"checkbox\"\n    [ngModel]=\"viewField.FieldValue\"\n    (click)=\"!viewField.FieldValue\"\n    >\n\n     <i class=\"btn-custom\"></i>\n\n    <span class=\"h3\">{{label}}</span>\n</label> -->\n\n<label>\n    <input [disabled]=\"disabled\"\n    class=\"custom\" \n    id=\"{{UniqueName}}\"\n    name=\"{{UniqueName}}\"\n    type=\"checkbox\"\n    [(ngModel)]=\"checkboxValue\"\n    #ValueInput=\"ngModel\"    \n    >\n\n     <i class=\"btn-custom\"></i>\n\n    <span *ngIf=\"label\" >{{label}}</span>\n\n</label>\n\n<!-- <label>\n        <input \n        class=\"custom\" \n        name=\"{{UniqueName}}\"\n        #ValueInput=\"ngModel\"\n        type=\"checkbox\"\n        [(ngModel)]=\"viewField.FieldValue\"\n        >\n    \n         <i class=\"btn-custom\"></i>\n    \n        <span class=\"h3\" *ngIf=\"label\" >{{label}}</span>\n    </label> -->",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomCheckBoxComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return TomCheckBoxComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomDateBoxComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomDateBoxComponent, _super);
    function TomDateBoxComponent(injector) {
        return _super.call(this, injector) || this;
    }
    /**
     * @return {?}
     */
    TomDateBoxComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        //this.viewField.errors = () => this.ValueInput.control.errors;
        //  this.viewField.forceValidation = () => {
        //     this.ValueInput.control.markAsTouched({ onlySelf:true });       // {3}
        //    this.ValueInput.control.markAsDirty({ onlySelf: true });    
        //    this.ValueInput.control.updateValueAndValidity();
        // }
        // this.viewField.markClean = () => {
        //   this.ValueInput.control.markAsTouched({ onlySelf:false });       // {3}
        //   this.ValueInput.control.markAsDirty({ onlySelf: false });    
        //   console.log (this.ValueInput.control.validator );
        //   let v = this.ValueInput.control.validator;
        //   if ( ! NullorEmpty( v) ){
        //       this.viewField.validators.push( v );
        //   }
        //   this.ValueInput.control.setValidators( this.viewField.validators);
        // };
    };
    TomDateBoxComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-date-box',
                    template: "<label>{{label}}</label>\n\n<!-- <div class='input-group date'>\n      <input type='text' \n      #ValueInput=\"ngModel\" \n      [(ngModel)]=\"viewField.FieldValue\"\n      placeholder=\"{{placeholder}}\" \n      class=\"form-control form-control-sm\"\n>\n\n      <button>DateClick</button>\n      \n  </div> -->\n\n\n\n  <div class='input-group date' >\n        <input type='text' [disabled]=\"disabled\"\n        #ValueInput=\"ngModel\" \n        [(ngModel)]=\"viewField.FieldValue\"\n        placeholder=\"{{placeholder}}\" \n        class=\"form-control form-control-sm\"\n        ngbDatepicker \n        #ngbDate=\"ngbDatepicker\">\n  \n        <!-- <button (click)=\"ngbDate.toggle()\">DateClick</button> -->\n        <span class=\"input-group-addon\" (click)=\"ngbDate.toggle()\">\n                  <span class=\"glyphicon glyphicon-calendar\"></span>\n            </span>\n              \n   </div>\n\n\n  \n  \n    <!-- <div class='input-group date'>\n            <input type='text' \n            #ValueInput=\"ngModel\" \n            [(ngModel)]=\"viewField.FieldValue\"\n            placeholder=\"{{placeholder}}\" \n            class=\"form-control form-control-sm\"\n            ngbDatepicker \n            #ngbDate=\"ngbDatepicker\">\n      \n            <button (click)=\"ngbDate.toggle()\">DateClick</button>\n            \n    </div> -->\n      \n      \n\n <span style=\"color: red\" *ngIf=\"!viewField.valid\">{{viewField.ErrMsgs}}</span>\n  ",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomDateBoxComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return TomDateBoxComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomDebuggerComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomDebuggerComponent, _super);
    function TomDebuggerComponent(injector) {
        var _this = _super.call(this, injector) || this;
        _this.MethodName = null;
        _this.viewModel = null;
        _this.expanded = false;
        return _this;
    }
    Object.defineProperty(TomDebuggerComponent.prototype, "isRender", {
        get: /**
         * @return {?}
         */
        function () {
            return TomFism__WEBPACK_IMPORTED_MODULE_5__["AppGlobal"].appMode == TomFism__WEBPACK_IMPORTED_MODULE_5__["AppMode"].debug;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    TomDebuggerComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @return {?}
     */
    TomDebuggerComponent.prototype.printViewModel = /**
     * @return {?}
     */
    function () {
        console.log(this.viewModel);
    };
    /**
     * @return {?}
     */
    TomDebuggerComponent.prototype.printDataModel = /**
     * @return {?}
     */
    function () {
        console.log(this.viewModel.dataModel);
    };
    /**
     * @return {?}
     */
    TomDebuggerComponent.prototype.expand_collapse = /**
     * @return {?}
     */
    function () {
        this.expanded = !this.expanded;
    };
    /**
     * @return {?}
     */
    TomDebuggerComponent.prototype.runMethod = /**
     * @return {?}
     */
    function () {
        if (Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this.MethodName)) {
            alert("Method name is null ");
            return;
        }
        /** @type {?} */
        var field = this.viewModel[this.MethodName];
        if (Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(field)) {
            alert("field is null : " + field);
            return;
        }
        /** @type {?} */
        var result;
        if (field instanceof Function) {
            result = this.viewModel[this.MethodName]();
        }
        else {
            result = field;
        }
        TomFism__WEBPACK_IMPORTED_MODULE_5__["LogInfoService"].callRunSvc(result, "FullNodePaths");
    };
    TomDebuggerComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-debugger',
                    template: "<div *ngIf=\"isRender\">\n  <div class=\"row\">\n      <div class=\"col-xs-1\">\n          <button (click)=\"expand_collapse()\">\n              <i class=\"glyphicon glyphicon-list-alt\"></i>\n            </button>\n    \n      </div>\n        <div *ngIf=\"expanded\" class=\"col-xs-10\">\n          <button (click)=\"printViewModel()\">ViewModel</button>\n          <button (click)=\"printDataModel()\">DataModel</button>\n      \n          <input [(ngModel)]=\"MethodName\" value=\"\">\n          <button (click)=\"runMethod()\">Run Method</button>\n      \n        </div>\n  </div>\n\n\n</div>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomDebuggerComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    TomDebuggerComponent.propDecorators = {
        viewModel: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }]
    };
    return TomDebuggerComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["ComplexComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomInputBoxComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomInputBoxComponent, _super);
    function TomInputBoxComponent(injector) {
        return _super.call(this, injector) || this;
    }
    /**
     * @return {?}
     */
    TomInputBoxComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @return {?}
     */
    TomInputBoxComponent.prototype.ngAfterViewChecked = /**
     * @return {?}
     */
    function () {
        // this.ValueInput.control.setValidators( this.viewField.validators);
        // this.viewField.errors = () => this.ValueInput.control.errors;
    };
    TomInputBoxComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-input-box',
                    template: "<label *ngIf=\"label\">{{label}}</label>\n\n<input #ValueInput=\"ngModel\" [disabled]=\"disabled\"\n     [(ngModel)]=\"viewField.FieldValue\"\n      placeholder=\"{{placeholder}}\" value=\"\" class=\"form-control form-control-sm\">\n\n \n<span style=\"color: red\" *ngIf=\"showErrMsg\">{{viewField.ErrMsgs}}</span>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomInputBoxComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return TomInputBoxComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomMsgListComponent = /** @class */ (function () {
    function TomMsgListComponent() {
    }
    Object.defineProperty(TomMsgListComponent.prototype, "MsgList", {
        get: /**
         * @return {?}
         */
        function () {
            return this._MsgList;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this._MsgList = value;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    TomMsgListComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    TomMsgListComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-msg-list',
                    template: "\n<ul style=\"color:purple\" >\n  <li *ngFor=\"let message of MsgList\" >\n    <span>{{ message.content }}</span>\n  </li>\n</ul>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomMsgListComponent.ctorParameters = function () { return []; };
    TomMsgListComponent.propDecorators = {
        MsgList: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }]
    };
    return TomMsgListComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomRadioComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomRadioComponent, _super);
    function TomRadioComponent(injector) {
        return _super.call(this, injector) || this;
    }
    /**
     * @return {?}
     */
    TomRadioComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        // this.ValueInput.control.setValidators( this.viewField.validators);
        // this.viewField.errors = () => this.ValueInput.control.errors;
    };
    TomRadioComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-radio',
                    template: "\n<label>\n        <input [disabled]=\"disabled\"\n        class=\"custom \" \n        name=\"{{GroupName}}\"\n        #ValueInput=\"ngModel\"\n        type=\"radio\"\n        [value]= \"value\"\n        [(ngModel)]=\"viewField.FieldValue\"\n        >\n         <i class=\"btn-custom\"></i>\n        <span>{{label}}</span>\n    </label>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomRadioComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    TomRadioComponent.propDecorators = {
        GroupName: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }],
        value: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }]
    };
    return TomRadioComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomSelectComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomSelectComponent, _super);
    function TomSelectComponent(injector) {
        return _super.call(this, injector) || this;
    }
    Object.defineProperty(TomSelectComponent.prototype, "viewField", {
        get: /**
         * @return {?}
         */
        function () {
            return (/** @type {?} */ ((/** @type {?} */ (this._viewField))));
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            if (Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(value)) {
                throw TomFism__WEBPACK_IMPORTED_MODULE_5__["tomException"].build("viewField is set to null pointer. Pls check viewField Path", { source: this.constructor.name });
            }
            this._viewField = value;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    TomSelectComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @return {?}
     */
    TomSelectComponent.prototype.ngAfterContentChecked = /**
     * @return {?}
     */
    function () {
        // this.ValueInput.control.markAsTouched({ onlySelf:false });       // {3}
        // this.ValueInput.control.markAsDirty({ onlySelf: false });    
    };
    TomSelectComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-select',
                    template: "\n<label *ngIf=\"label\" >{{label}}</label>\n\n\n<select #ValueInput=\"ngModel\" [disabled]=\"disabled\"\n  [(ngModel)]=\"viewField.FieldValue\" class=\"form-control form-control-sm\" >\n  <!-- <option value=\"undefined\">Please select</option> -->\n  <option value=\"\" disabled selected >Please Choose...</option>  \n  <option *ngFor=\"let item of viewField.OptionList\" value=\"{{item.key}}\">{{item.value}}</option>\n</select>\n\n\n<span style=\"color: red\" *ngIf=\"!viewField?.valid\">{{viewField.ErrMsgs}}</span>\n\n",
                    styles: ["select:invalid{color:gray}"]
                }] }
    ];
    /** @nocollapse */
    TomSelectComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return TomSelectComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomVisibleDirective = /** @class */ (function () {
    function TomVisibleDirective(element, templateRef, viewContainer) {
        this.element = element;
        this.templateRef = templateRef;
        this.viewContainer = viewContainer;
    }
    Object.defineProperty(TomVisibleDirective.prototype, "TomVisible", {
        set: /**
         * @param {?} val
         * @return {?}
         */
        function (val) {
            // console.log ( val.visible);
            //this.viewContainer.clear();
            if (Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(val) || val.visible) {
                //console.log ( "nothing");
                this.viewContainer.createEmbeddedView(this.templateRef);
            }
            else {
                this.viewContainer.clear();
            }
        },
        enumerable: true,
        configurable: true
    });
    TomVisibleDirective.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Directive"], args: [{
                    selector: '[tom-visible]'
                },] }
    ];
    /** @nocollapse */
    TomVisibleDirective.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ElementRef"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["TemplateRef"] },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewContainerRef"] }
    ]; };
    TomVisibleDirective.propDecorators = {
        TomVisible: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"], args: ["tom-visible",] }]
    };
    return TomVisibleDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var SimDriverComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(SimDriverComponent, _super);
    function SimDriverComponent(injector) {
        var _this = _super.call(this, injector) || this;
        _this.isColapseDebugger = true;
        return _this;
    }
    Object.defineProperty(SimDriverComponent.prototype, "IsReady", {
        get: /**
         * @return {?}
         */
        function () {
            return (!Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this.viewModel) && this.viewModel.isReady);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SimDriverComponent.prototype, "viewModel", {
        get: /**
         * @return {?}
         */
        function () {
            return TomFism__WEBPACK_IMPORTED_MODULE_5__["AppGlobal"].appViewModel.SimVM;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    SimDriverComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @return {?}
     */
    SimDriverComponent.prototype.toggleSimDebugger = /**
     * @return {?}
     */
    function () {
        this.isColapseDebugger = !this.isColapseDebugger;
        //alert ( this.toggleSimDebugger);
    };
    SimDriverComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'sim-driver',
                    template: "<div class=\"float\">\n  <button (click)=\"toggleSimDebugger()\" class=\"float-toggle\">SimDeubgger</button>\n  <tom-button label=\"Log Viewer\" [viewField]=viewModel.openLogViewer></tom-button>\n\n\n  <div [hidden]=\"isColapseDebugger\" *ngIf=\"IsReady\" class=\"sim-button\">\n    <tom-debugger [viewModel]=\"viewModel\"></tom-debugger>\n    <div class=\"row\">\n      <div class=\"form-group col-xs-2\">\n        <tom-button label=\"Start Record\" [viewField]=viewModel.record></tom-button>\n      </div>\n      <div class=\"form-group col-xs-2\">\n        <tom-button label=\"Stop Record\" [viewField]=viewModel.StopRecord></tom-button>\n      </div>\n      <div class=\"form-group col-xs-1\" style=\"background:darkblue\">\n        <tom-check-box label=\"full\" [viewField]=viewModel.PlayToEnd></tom-check-box>\n      </div>\n\n      <div class=\"form-group col-xs-1\">\n        <tom-button label=\"Play\" [viewField]=viewModel.play></tom-button>\n      </div>\n      <div class=\"form-group col-xs-1\">\n        <tom-button label=\"Play Next\" [viewField]=viewModel.PlayNext></tom-button>\n      </div>\n      <div class=\"form-group col-xs-1\">\n        <tom-select label=\"CheckPointMode\" [viewField]=viewModel.SelectedCheckPointMode></tom-select>\n      </div>\n      <div class=\"form-group col-xs-1\">\n        <tom-select label=\"CheckPoint Sessions\" [viewField]=viewModel.SelectedCheckPointSession></tom-select>\n      </div>\n\n      <div class=\"form-group col-xs-1\">\n        <tom-select label=\"Sessions\" [viewField]=viewModel.SelectedCmdSession></tom-select>\n      </div>\n      <!-- <div class=\"form-group col-xs-2\">\n        <tom-button label=\"Refresh\" [viewField]=viewModel.refresh></tom-button>\n      </div> -->\n\n    </div>\n  </div>\n\n  <tom-popup [viewModel]=\"viewModel.LogViewerPopup\" PopupTitle=\"Log Viewer\" class=\"log-viewer-popup\" >\n    <log-viewer></log-viewer>\n  </tom-popup>\n\n</div>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    SimDriverComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return SimDriverComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["ComplexComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var SimpleLinkComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(SimpleLinkComponent, _super);
    function SimpleLinkComponent(injector) {
        var _this = _super.call(this, injector) || this;
        _this.sanitizer = injector.get(_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"]);
        return _this;
    }
    Object.defineProperty(SimpleLinkComponent.prototype, "DisplayText", {
        get: /**
         * @return {?}
         */
        function () {
            if (Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this.label)) {
                return this.viewField.DisplayText;
            }
            else {
                return this.label;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SimpleLinkComponent.prototype, "href", {
        get: /**
         * @return {?}
         */
        function () {
            /** @type {?} */
            var s = this.sanitizer.bypassSecurityTrustUrl(this.viewField.FieldValue);
            return s;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SimpleLinkComponent.prototype, "isDownload", {
        get: /**
         * @return {?}
         */
        function () {
            return this.viewField.isDownload;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SimpleLinkComponent.prototype, "fileName", {
        get: /**
         * @return {?}
         */
        function () {
            return this.viewField.FileName;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    SimpleLinkComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    SimpleLinkComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'simple-link',
                    template: "\r\n\r\n<a *ngIf=\"isDownload\" [href]=\"href\" download=\"{{fileName}}\">{{DisplayText}}</a>\r\n\r\n<a *ngIf=\"!isDownload\" [href]=\"href\" >{{DisplayText}}</a>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    SimpleLinkComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return SimpleLinkComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomButtonInputComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomButtonInputComponent, _super);
    function TomButtonInputComponent(injector) {
        return _super.call(this, injector) || this;
    }
    /**
     * @return {?}
     */
    TomButtonInputComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @return {?}
     */
    TomButtonInputComponent.prototype.ngAfterViewChecked = /**
     * @return {?}
     */
    function () {
        // this.ValueInput.control.setValidators( this.viewField.validators);
        // this.viewField.errors = () => this.ValueInput.control.errors;
        // this.viewField.forceValidation = () => {
        //   this.ValueInput.control.markAsTouched({ onlySelf: true });       // {3}
        //   this.ValueInput.control.markAsDirty({ onlySelf: true });
        //   this.ValueInput.control.updateValueAndValidity();
        // }
    };
    /**
     * @return {?}
     */
    TomButtonInputComponent.prototype.click = /**
     * @return {?}
     */
    function () {
        //console.log (AppGlobal.setting.cmdRouter);
        //console.log ( this.viewField.getViewModel().appViewModel.cmdRouter);
        ((/** @type {?} */ (this.viewField))).runCmd();
    };
    TomButtonInputComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-button-input',
                    template: "<label *ngIf=\"label\">{{label}}</label>\n<div class=\"input-group\">\n\n  <!-- <input #ValueInput=\"ngModel\"  [ngModel]=\"viewField.FieldValue\" placeholder=\"{{placeholder}}\" value=\"\" readonly\n  class=\"form-control form-control-sm\"> -->\n\n  <input #ValueInput=\"ngModel\"  [ngModel]=\"viewField.FieldValue\" placeholder=\"{{placeholder}}\" value=\"\"\n    readonly class=\"form-control form-control-sm\">\n\n  <span class=\"input-group-addon\" attr.disabled=\"{{disabled}}\">\n    <span class=\"glyphicon glyphicon-search pointer\" (click)=\"click()\"></span>\n  </span>\n\n</div>\n<span style=\"color: red\" *ngIf=\"showErrMsg\">{{viewField.ErrMsgs}}</span>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomButtonInputComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return TomButtonInputComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomCmdLinkComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomCmdLinkComponent, _super);
    function TomCmdLinkComponent(injector) {
        return _super.call(this, injector) || this;
    }
    /**
     * @return {?}
     */
    TomCmdLinkComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    TomCmdLinkComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'app-tom-cmd-link',
                    template: "<p>\n  tom-cmd-link works!\n</p>\n",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomCmdLinkComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return TomCmdLinkComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomClickableDirective = /** @class */ (function () {
    function TomClickableDirective(injector) {
    }
    Object.defineProperty(TomClickableDirective.prototype, "CommandField", {
        get: /**
         * @return {?}
         */
        function () {
            return this._CommandField;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this._CommandField = value;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    TomClickableDirective.prototype.click = /**
     * @return {?}
     */
    function () {
        //console.log ( this._CommandField);
        if (!Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this._CommandField))
            this._CommandField.runCmd();
    };
    TomClickableDirective.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Directive"], args: [{
                    selector: '[tom-clickable]',
                    host: { '(click)': 'click()' },
                },] }
    ];
    /** @nocollapse */
    TomClickableDirective.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    TomClickableDirective.propDecorators = {
        CommandField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"], args: ["tom-clickable",] }]
    };
    return TomClickableDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var tomLink = /** @class */ (function () {
    function tomLink(injector) {
        this.injector = injector;
    }
    Object.defineProperty(tomLink.prototype, "viewField", {
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this._viewField = value;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    tomLink.prototype.onClick = /**
     * @return {?}
     */
    function () {
        // console.log ( this._viewField);
        // alert ( "clikced : " + this._viewField.getFieldValue());
        this._viewField.routableCmd.ViewNodeSeq = this._viewField.seq;
        this._viewField.runCmd();
    };
    tomLink.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Directive"], args: [{ selector: 'a[viewField]' },] }
    ];
    /** @nocollapse */
    tomLink.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    tomLink.propDecorators = {
        viewField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }],
        onClick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["HostListener"], args: ['click',] }]
    };
    return tomLink;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomCheckPointResultComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomCheckPointResultComponent, _super);
    function TomCheckPointResultComponent(injector) {
        return _super.call(this, injector) || this;
    }
    Object.defineProperty(TomCheckPointResultComponent.prototype, "IsReady", {
        get: /**
         * @return {?}
         */
        function () {
            return !Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this.viewModel);
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    TomCheckPointResultComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    TomCheckPointResultComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-check-point-result',
                    template: "<div class=\"panel panel-default\" *ngIf=\"IsReady\">\n\n\n  <div class=\"row\">\n    <div class=\"form-group col-xs-6\">\n      <tom-select label=\"Session\" [viewField]=\"viewModel.vfSelectedSession\"></tom-select>\n    </div>\n  </div>\n\n  <div class=\"row\">\n    <div class=\"form-group col-xs-6\">\n      <tom-button label=\"List Result\" [viewField]=\"viewModel.vfCmdListCheckPointResults\"></tom-button>\n    </div>\n  </div>\n\n  <tom-view-table [SourceList]=\"viewModel.ViewModelList\" #container>\n    <thead>\n      <tr class=\"columnHeaderRow\">\n        <th st-ratio=\"14.29\" tom-sort=\"vfLogSeq\"> Seq</th>\n        <th st-ratio=\"14.29\" tom-sort=\"vfCheckPointName\">CheckPoint</th>\n        <th st-ratio=\"14.29\" tom-sort=\"vfIsResultMatch\">Result Match</th>\n      </tr>\n    </thead>\n    <tbody>\n      <tr *ngFor=\"let row of container.DisplaySource\" [tom-clickable]=\"row.vfCmdShowLog\">\n        <td>\n          <tom-text class=\"tom-fake-link\" [viewField]=\"row.vfLogSeq\"></tom-text>\n        </td>\n        <td>\n          <tom-text [viewField]=\"row.vfCheckPointName\"></tom-text>\n        </td>\n        <td>\n          <tom-text [viewField]=\"row.vfIsResultMatch\"></tom-text>\n        </td>\n\n\n      </tr>\n    </tbody>\n\n  </tom-view-table>\n\n\n\n\n\n\n</div>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomCheckPointResultComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return TomCheckPointResultComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["ComplexComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomFileComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomFileComponent, _super);
    function TomFileComponent(injector) {
        return _super.call(this, injector) || this;
    }
    Object.defineProperty(TomFileComponent.prototype, "canProcess", {
        get: /**
         * @return {?}
         */
        function () {
            return !Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this.viewField.FieldValue);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TomFileComponent.prototype, "FileName", {
        get: /**
         * @return {?}
         */
        function () {
            if (Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this.viewField.FieldValue))
                return "";
            else
                return this.viewField.getDataModel().fileName;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    TomFileComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @param {?} event
     * @return {?}
     */
    TomFileComponent.prototype.fileChange = /**
     * @param {?} event
     * @return {?}
     */
    function (event) {
        if (event.target.files.length > 0) {
            /** @type {?} */
            var file = event.target.files[0];
            this.viewField.FieldValue = file;
            console.log(this.viewField.FieldValue);
        }
        else {
            this.viewField.FieldValue = null;
        }
    };
    /**
     * @return {?}
     */
    TomFileComponent.prototype.process = /**
     * @return {?}
     */
    function () {
        this.viewField.runCmd();
    };
    TomFileComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-file',
                    template: "<div style=\"position: relative;\">\n  <input type=\"file\" (change)=\"fileChange($event)\" #uploadBtn name=\"file\" style=\"position:absolute; left:0px; top:0px; opacity:0;filter:alpha(opacity=0); cursor:pointer;overflow: hidden;width:330px; height:36px;\" />\n\n  <input type=\"text\" id=\"copyFile\" value=\"{{FileName}}\" class=\"textbox form-control input-sm\" style=\"float:left; width:250px; margin-right: 4px;\">\n  <button class=\"btn  btn-warning\">{{OpenFileLabel}}</button>\n  <button class=\"btn  btn-warning\" (click)=\"process()\" [disabled]=\"!canProcess\">{{label}}  </button>\n</div>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomFileComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    TomFileComponent.propDecorators = {
        OpenFileLabel: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }]
    };
    return TomFileComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomLogComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomLogComponent, _super);
    function TomLogComponent(injector) {
        return _super.call(this, injector) || this;
    }
    /**
     * @return {?}
     */
    TomLogComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    Object.defineProperty(TomLogComponent.prototype, "isShowJSON", {
        get: /**
         * @return {?}
         */
        function () {
            return this.viewModel.vfIsShowJSON.FieldValue;
        },
        enumerable: true,
        configurable: true
    });
    TomLogComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-log',
                    template: "<div class=\"panel panel-default\"  >\n\n  <div class=\"row\">\n    <div class=\"form-group col-xs-6\">\n      <tom-select label=\"Log Type\" [viewField]=\"viewModel.vfSelectedLogType\"></tom-select>\n    </div>\n  </div>\n\n  <div class=\"row\">\n    <div class=\"form-group col-xs-6\">\n      <tom-select label=\"Session\" [viewField]=\"viewModel.vfSelectedSession\"></tom-select>\n    </div>\n  </div>\n\n  <div class=\"row\">\n      <div class=\"form-group col-xs-6\">\n        <tom-select label=\"seq\" [viewField]=\"viewModel.vfSelectedSeq\"></tom-select>\n      </div>\n  </div>\n\n  <div class=\"row\">\n    <div class=\"form-group col-xs-4\">\n      <tom-button  label=\"Refresh Content\" [viewField]=\"viewModel.vfCmdShowContent\"></tom-button>\n    </div>\n    <div class=\"form-group col-xs-4\"  style=\"text-align:center\">\n      <simple-link  [viewField]=\"viewModel.vfLogJsonLink\"></simple-link>\n    </div>\n    <div class=\"form-group col-xs-4\" style=\"text-align:center\">\n        <tom-check-box label=\"Show JSON\" [viewField]=\"viewModel.vfIsShowJSON\"></tom-check-box>\n     </div>\n  </div>\n\n  <div class=\"row\" *ngIf=\"isShowJSON\" >\n    <div class=\"form-group col-xs-6\">\n      <tom-text-area  label=\"JSON\" [viewField]=\"viewModel.vfLogContent\"></tom-text-area>\n    </div>\n  </div>\n\n\n</div>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomLogComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return TomLogComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["ComplexComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomPopupComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomPopupComponent, _super);
    function TomPopupComponent(injector) {
        var _this = _super.call(this, injector) || this;
        _this.PopupTitle = null;
        return _this;
    }
    /**
     * @return {?}
     */
    TomPopupComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        // console.log ("isRender");
        // console.log ( this.viewModel.isRenderContent());
    };
    TomPopupComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-popup',
                    template: "<div class=\"modal\" [class.show]=\"viewModel.isShowPopup.FieldValue\"  tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModalLabel\">\n\n    <div class=\"modal-dialog\" role=\"document\">\n      <div class=\"modal-content\" >\n        <div class=\"modal-header\">\n          <!-- <button type=\"button\" class=\"close\"  aria-label=\"Close\">\n            <span aria-hidden=\"true\">&times;</span>\n          </button> -->\n          <tom-button  class=\"close\"    [viewField]=\"viewModel.closePopupButton\" >\n              <span style=\"margin:0px;padding:0px\" aria-hidden=\"true\">&times;</span>\n          </tom-button>\n          \n          <!-- <h3 class=\"modal-title\" id=\"myModalLabel\" translate=\"main.Client.TITLE\"></h3> -->\n          <h3 class=\"modal-title\"   id=\"myModalLabel\" >{{PopupTitle}} </h3>\n        </div>\n\n        <div class=\"modal-body\" style=\"overflow-y:scroll\"  >\n            <ng-content></ng-content>\n        </div>\n\n        <!-- <div class=\"modal-footer btn-row text-right\">\n          <tom-button  class=\"btn input-sm btn-default\" label=\"closss\" [viewField]=\"viewModel.closePopup\" ></tom-button>\n        </div> -->\n\n      </div>\n    </div>\n\n  </div>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomPopupComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    TomPopupComponent.propDecorators = {
        PopupTitle: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }]
    };
    return TomPopupComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["ComplexComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomTextAreaComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomTextAreaComponent, _super);
    function TomTextAreaComponent(injector) {
        return _super.call(this, injector) || this;
    }
    /**
     * @return {?}
     */
    TomTextAreaComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    TomTextAreaComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-text-area',
                    template: "<label *ngIf=\"label\">{{label}}</label>\n\n<div class=\"input-group\">\n\n  <!-- <textarea ValueInput=\"ngModel\"  [ngModel]=\"viewField.FieldValue\" placeholder=\"{{placeholder}}\" value=\"\"  \n  class=\"form-control form-control-sm\"></textarea> -->\n\n\n  <ngx-json-viewer  \n      [json]=\"viewField.FieldValue\"  [expanded]=\"true\"></ngx-json-viewer>\n\n</div>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomTextAreaComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return TomTextAreaComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomTextBoxComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomTextBoxComponent, _super);
    function TomTextBoxComponent(injector) {
        return _super.call(this, injector) || this;
    }
    Object.defineProperty(TomTextBoxComponent.prototype, "viewField", {
        get: /**
         * @return {?}
         */
        function () {
            return this._viewField;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this._viewField = value;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    TomTextBoxComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    TomTextBoxComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-text-box',
                    template: "<label *ngIf=\"label\">{{label}}</label>\n\n <input disabled  style=\"word-break: break-word;\"\n     [ngModel]=\"viewField.FieldValue\"\n      placeholder=\"{{placeholder}}\" value=\"\" class=\"form-control form-control-sm\"> \n\n<!-- <textarea disabled [ngModel]=\"viewField.FieldValue\" placeholder=\"{{placeholder}}\" \nvalue=\"\" class=\"form-control form-control-sm\"></textarea> -->",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomTextBoxComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    TomTextBoxComponent.propDecorators = {
        viewField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }]
    };
    return TomTextBoxComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["FieldComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomUploaderComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomUploaderComponent, _super);
    function TomUploaderComponent(injector) {
        return _super.call(this, injector) || this;
    }
    /**
     * @return {?}
     */
    TomUploaderComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @param {?} $event
     * @return {?}
     */
    TomUploaderComponent.prototype.fileChange = /**
     * @param {?} $event
     * @return {?}
     */
    function ($event) {
    };
    /**
     * @return {?}
     */
    TomUploaderComponent.prototype.censusUpload = /**
     * @return {?}
     */
    function () {
    };
    TomUploaderComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-uploader',
                    template: "<div style=\"position: relative;\">\n  <input type=\"file\" (change)=\"fileChange($event)\" #uploadBtn name=\"file\" style=\"position:absolute; left:0px; top:0px; opacity:0;filter:alpha(opacity=0); cursor:pointer;overflow: hidden;width:330px; height:36px;\" />\n\n  <input type=\"text\" id=\"copyFile\" value=\"{{uploadBtn.value}}\" class=\"textbox form-control input-sm\" style=\"float:left; width:250px; margin-right: 4px;\">\n  <button class=\"btn  btn-warning\">{{OpenFileLabel}}</button>\n  <button class=\"btn  btn-warning\" (click)=\"censusUpload()\">{{label}} </button>\n</div>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomUploaderComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    TomUploaderComponent.propDecorators = {
        OpenFileLabel: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }],
        label: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }]
    };
    return TomUploaderComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["ComplexComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomViewPaginatorComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomViewPaginatorComponent, _super);
    function TomViewPaginatorComponent(injector) {
        var _this = _super.call(this, injector) || this;
        _this.CurrentPage = 1;
        _this.pages = [];
        return _this;
    }
    /**
     * @return {?}
     */
    TomViewPaginatorComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @param {?} Source
     * @param {?} DisplaySource
     * @return {?}
     */
    TomViewPaginatorComponent.prototype.setSource = /**
     * @param {?} Source
     * @param {?} DisplaySource
     * @return {?}
     */
    function (Source, DisplaySource) {
        this.Source = Source;
        this.DisplaySource = DisplaySource;
        if (this.Source == null) {
            alert("null source");
            console.log("null source");
            return;
        }
        this.pages = [];
        //alert ( this.Source.toString() );
        if (this.PageSize == null || this.PageSize == 0)
            this.PageSize = 10;
        /** @type {?} */
        var pageNo = 1;
        while (true) {
            this.pages.push(pageNo++);
            if ((pageNo - 1) * this.PageSize >= this.Source.length)
                break;
        }
    };
    Object.defineProperty(TomViewPaginatorComponent.prototype, "Summary", {
        get: /**
         * @return {?}
         */
        function () {
            return (this.DisplaySourceStart + 1).toString() + "-" + (this.DisplaySourceEnd + 1).toString()
                + " of " + (this.Source.length).toString();
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @param {?} pageNo
     * @return {?}
     */
    TomViewPaginatorComponent.prototype.selectPage = /**
     * @param {?} pageNo
     * @return {?}
     */
    function (pageNo) {
        var e_1, _a;
        this.CurrentPage = pageNo;
        this.DisplaySourceStart = (pageNo - 1) * this.PageSize;
        //console.log( this.DisplaySourceStart);
        this.DisplaySourceEnd = this.DisplaySourceStart + this.PageSize - 1;
        //console.log(this.DisplaySourceEnd);
        if (this.DisplaySourceEnd > this.Source.length - 1)
            this.DisplaySourceEnd = this.Source.length - 1;
        /** @type {?} */
        var _DisplaySource = this.Source.slice(this.DisplaySourceStart, this.DisplaySourceEnd + 1);
        this.DisplaySource.length = 0;
        try {
            for (var _DisplaySource_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__values"])(_DisplaySource), _DisplaySource_1_1 = _DisplaySource_1.next(); !_DisplaySource_1_1.done; _DisplaySource_1_1 = _DisplaySource_1.next()) {
                var i = _DisplaySource_1_1.value;
                this.DisplaySource.push(i);
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (_DisplaySource_1_1 && !_DisplaySource_1_1.done && (_a = _DisplaySource_1.return)) _a.call(_DisplaySource_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
        //console.log( this.DisplaySource.length);
        //this.SourceChange.emit( DisplaySource);
    };
    TomViewPaginatorComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-view-paginator',
                    template: "<div *ngIf=\"Source != null && DisplaySource != null\" class=\"pagination-group\">\n  <nav *ngIf=\"pages.length >= 2 \">\n    <ul class=\"pagination\">\n      <li *ngIf=\"CurrentPage > 1\">\n        <a (click)=\"selectPage(CurrentPage -1 )\" class=\"pointer arrow\">&lt;</a>\n      </li>\n      <li *ngFor=\"let page of pages\" [ngClass]=\"{'active': page==CurrentPage}\">\n        <a (click)=\"selectPage(page)\" class=\"pointer\">{{page |number}}</a>\n      </li>\n      <li *ngIf=\"CurrentPage < pages.length\">\n        <a (click)=\"selectPage(CurrentPage + 1)\" class=\"pointer arrow\">&gt;</a>\n      </li>\n      <!--\n        <li ng-if=\"currentPage < numPages\">\n          <a ng-click=\"selectPage(numPages)\">LAST</a></li>\n        -->\n    </ul>\n  </nav>\n\n  <div class=\"pagination-summary\" *ngIf=\"pages.length >= 2\">\n    Showing {{ Summary }}\n  </div>\n</div>\n<!-- {{ DisplaySourceStart + 1  | number }}-{{ DisplaySourceEnd + 1| number }} of \n    {{ Source.length + 1 | number}} -->",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomViewPaginatorComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    TomViewPaginatorComponent.propDecorators = {
        PageSize: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"] }]
    };
    return TomViewPaginatorComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["ComplexComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomViewTableComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomViewTableComponent, _super);
    function TomViewTableComponent(injector) {
        var _this = _super.call(this, injector) || this;
        _this.NonFilteredSource = null;
        _this.DisplaySource = [];
        return _this;
    }
    /**
     * @return {?}
     */
    TomViewTableComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    Object.defineProperty(TomViewTableComponent.prototype, "sortField", {
        get: /**
         * @return {?}
         */
        function () {
            return this._sortField;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this.sortfields.forEach(function (s) {
                if (s != value) {
                    s.clear();
                }
            });
            this._sortField = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(TomViewTableComponent.prototype, "FullSource", {
        get: /**
         * @return {?}
         */
        function () {
            return this._FullSource;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            // if ( value == null)
            //   alert ("null value");
            this._FullSource = value;
            if (Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this.childPaginator)) {
                this.DisplaySource = this.FullSource;
            }
            else {
                this.childPaginator.setSource(this.FullSource, this.DisplaySource);
                this.childPaginator.selectPage(1);
            }
            //console.log ( this._FullSource)
            this.sort();
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @param {?} criteria
     * @return {?}
     */
    TomViewTableComponent.prototype.filter = /**
     * @param {?} criteria
     * @return {?}
     */
    function (criteria) {
        if (criteria == null || criteria == "") {
            if (this.NonFilteredSource != null) {
                this.FullSource = this.NonFilteredSource;
                this.NonFilteredSource = null;
            }
        }
        else {
            if (this.NonFilteredSource == null)
                this.NonFilteredSource = this.FullSource;
            this.FullSource = this.NonFilteredSource.filter(function (item) {
                for (var key in item) {
                    /** @type {?} */
                    var field = item[key];
                    if (field != null && field.includes != undefined && field.includes(criteria))
                        return true;
                }
                return false;
            });
        }
        this.sort();
    };
    /**
     * @return {?}
     */
    TomViewTableComponent.prototype.sort = /**
     * @return {?}
     */
    function () {
        var _this = this;
        if (this.sortField == null || this.DisplaySource == null)
            return;
        else if (this.sortField.sortAscend == null && !Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this.childPaginator)) {
            this.childPaginator.selectPage(this.childPaginator.CurrentPage);
        }
        else {
            /** @type {?} */
            var result = this.DisplaySource.sort(function (a, b) {
                /** @type {?} */
                var fieldName = _this.sortField.SortField;
                /** @type {?} */
                var aValue = a.ViewFields.get(fieldName).FieldValue;
                /** @type {?} */
                var bValue = b.ViewFields.get(fieldName).FieldValue;
                if (aValue < bValue)
                    return -1;
                else if (aValue > bValue)
                    return 1;
                else
                    return 0;
            });
            if (!this.sortField.sortAscend)
                result.reverse();
        }
    };
    /**
     * @param {?} sortField
     * @return {?}
     */
    TomViewTableComponent.prototype.clearSortHeaders = /**
     * @param {?} sortField
     * @return {?}
     */
    function (sortField) {
        this.sortfields.forEach(function (s) {
            if (s != sortField) {
                s.clear();
            }
        });
    };
    TomViewTableComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-view-table',
                    template: "<table class=\"table table-hover table-striped \" >\n    <ng-content></ng-content>\n</table>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomViewTableComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    TomViewTableComponent.propDecorators = {
        childPaginator: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ContentChild"], args: [TomViewPaginatorComponent,] }],
        sortfields: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ContentChildren"], args: [Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["forwardRef"])(function () { return TomViewSortDirective; }),] }],
        FullSource: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"], args: ["SourceList",] }]
    };
    return TomViewTableComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["ComplexComponentBase"]));
var TomViewSortDirective = /** @class */ (function () {
    function TomViewSortDirective(hostTomTable, elRef) {
        this.hostTomTable = hostTomTable;
        this.elRef = elRef;
        this.sortAscend = null;
    }
    Object.defineProperty(TomViewSortDirective.prototype, "SortField", {
        get: /**
         * @return {?}
         */
        function () {
            return this._SortField;
        },
        set: /**
         * @param {?} value
         * @return {?}
         */
        function (value) {
            this._SortField = value;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    TomViewSortDirective.prototype.clear = /**
     * @return {?}
     */
    function () {
        this.elRef.nativeElement.classList.remove("tom-sort-ascent");
        this.elRef.nativeElement.classList.remove("tom-sort-descent");
        this.sortAscend = null;
    };
    /**
     * @return {?}
     */
    TomViewSortDirective.prototype.highlightAscent = /**
     * @return {?}
     */
    function () {
        this.elRef.nativeElement.classList.add("tom-sort-ascent");
    };
    /**
     * @return {?}
     */
    TomViewSortDirective.prototype.highlightDecent = /**
     * @return {?}
     */
    function () {
        this.elRef.nativeElement.classList.add("tom-sort-descent");
    };
    /**
     * @return {?}
     */
    TomViewSortDirective.prototype.click = /**
     * @return {?}
     */
    function () {
        if (this.sortAscend == null) {
            this.sortAscend = true;
            this.highlightAscent();
        }
        else if (this.sortAscend) {
            this.sortAscend = false;
            this.highlightDecent();
        }
        else {
            this.sortAscend = null;
            this.clear();
        }
        this.hostTomTable.sortField = this;
        this.hostTomTable.sort();
    };
    TomViewSortDirective.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Directive"], args: [{
                    selector: 'th[tom-sort]',
                    host: { '(click)': 'click()' },
                },] }
    ];
    /** @nocollapse */
    TomViewSortDirective.ctorParameters = function () { return [
        { type: TomViewTableComponent },
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ElementRef"] }
    ]; };
    TomViewSortDirective.propDecorators = {
        SortField: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"], args: ["tom-sort",] }]
    };
    return TomViewSortDirective;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomSessionMgrComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(TomSessionMgrComponent, _super);
    function TomSessionMgrComponent(injector) {
        return _super.call(this, injector) || this;
    }
    Object.defineProperty(TomSessionMgrComponent.prototype, "IsReady", {
        get: /**
         * @return {?}
         */
        function () {
            return !Object(TomFism__WEBPACK_IMPORTED_MODULE_5__["NullorEmpty"])(this.viewModel);
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    TomSessionMgrComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    TomSessionMgrComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'tom-session-mgr',
                    template: "\n<div class=\"panel panel-default\" *ngIf=\"IsReady\">\n\n\n  <div class=\"row\">\n    \n    <!-- <div class=\"form-group col-xs-2\">\n      <tom-select label=\"Session\" [viewField]=\"viewModel.vfSelectedSession\"></tom-select>\n    </div>\n    <div class=\"form-group col-xs-2\" style=\"text-align:center\">\n      <simple-link [viewField]=\"viewModel.vfExportedSessionLink\"></simple-link>\n    </div> -->\n\n    <div class=\"form-group col-xs-2\">\n        <h2>Download</h2>\n        <tom-select label=\"Session\" [viewField]=\"viewModel.vfSelectedSession\"></tom-select>\n        <simple-link [viewField]=\"viewModel.vfExportedSessionLink\"></simple-link>\n    </div>\n  \n    <div class=\"form-group col-xs-2\"></div>\n    \n    <div class=\"form-group col-xs-6\" style=\"text-align:center\">\n      <h2>Upload</h2>\n      <tom-file label=\"upload\" OpenFileLabel=\"browse\" [viewField]=\"viewModel.vfUploadFile\"></tom-file>\n    </div>\n\n  </div>\n\n</div>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    TomSessionMgrComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return TomSessionMgrComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["ComplexComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var LogViewerComponent = /** @class */ (function (_super) {
    Object(tslib__WEBPACK_IMPORTED_MODULE_3__["__extends"])(LogViewerComponent, _super);
    function LogViewerComponent(injector) {
        return _super.call(this, injector) || this;
    }
    Object.defineProperty(LogViewerComponent.prototype, "viewModel", {
        get: /**
         * @return {?}
         */
        function () {
            return TomFism__WEBPACK_IMPORTED_MODULE_5__["AppGlobal"].appViewModel.AutoTestVM;
        },
        enumerable: true,
        configurable: true
    });
    /**
     * @return {?}
     */
    LogViewerComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    LogViewerComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"], args: [{
                    selector: 'log-viewer',
                    template: "<div>\n\n\n  <h2>Check Point Results</h2>\n  <tom-check-point-result [viewModel]=\"viewModel\"></tom-check-point-result>\n\n  <tom-session-mgr [viewModel]=\"viewModel.vmSessionIO\"></tom-session-mgr>\n\n  <h2> Log details</h2>\n  <div class=\"row\">\n    <div class=\"form-group col-xs-6\">\n      <tom-log [viewModel]=\"viewModel.vmLeftLogDB\"></tom-log>\n    </div>\n    <div class=\"form-group col-xs-6\">\n      <tom-log [viewModel]=\"viewModel.vmRightLogDB\"></tom-log>\n    </div>\n  </div>\n\n\n\n</div>",
                    styles: [""]
                }] }
    ];
    /** @nocollapse */
    LogViewerComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Injector"] }
    ]; };
    return LogViewerComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_5__["ComplexComponentBase"]));

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
var TomModule = /** @class */ (function () {
    function TomModule() {
    }
    TomModule.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["NgModule"], args: [{
                    declarations: [
                        TomTextComponent,
                        TomButtonComponent,
                        TomDateBoxComponent,
                        TomCheckBoxComponent,
                        TomSelectComponent,
                        TomRadioComponent,
                        TomDebuggerComponent,
                        TomMsgListComponent,
                        TomInputBoxComponent,
                        TomVisibleDirective,
                        SimDriverComponent,
                        SimpleLinkComponent,
                        TomButtonInputComponent,
                        TomCmdLinkComponent,
                        //     SafeUrlPipe,
                        TomClickableDirective,
                        tomLink,
                        TomCheckPointResultComponent,
                        TomFileComponent,
                        TomLogComponent,
                        TomPopupComponent,
                        TomTextAreaComponent,
                        TomTextBoxComponent,
                        TomUploaderComponent,
                        TomViewPaginatorComponent,
                        TomViewTableComponent,
                        TomSessionMgrComponent,
                        TomViewSortDirective,
                        LogViewerComponent
                    ],
                    imports: [
                        _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                        _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                        _angular_forms__WEBPACK_IMPORTED_MODULE_0__["FormsModule"],
                        _angular_forms__WEBPACK_IMPORTED_MODULE_0__["ReactiveFormsModule"],
                        _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_6__["NgbModule"],
                        ngx_json_viewer__WEBPACK_IMPORTED_MODULE_7__["NgxJsonViewerModule"]
                    ],
                    exports: [
                        TomTextComponent,
                        TomButtonComponent,
                        TomDateBoxComponent,
                        TomCheckBoxComponent,
                        TomSelectComponent,
                        TomRadioComponent,
                        TomDebuggerComponent,
                        TomMsgListComponent,
                        TomInputBoxComponent,
                        TomVisibleDirective,
                        SimDriverComponent,
                        SimpleLinkComponent,
                        TomButtonInputComponent,
                        TomCmdLinkComponent,
                        //       SafeUrlPipe,
                        TomClickableDirective,
                        tomLink,
                        TomCheckPointResultComponent,
                        TomLogComponent,
                        TomPopupComponent,
                        TomTextAreaComponent,
                        TomTextBoxComponent,
                        TomUploaderComponent,
                        TomViewPaginatorComponent,
                        TomViewTableComponent,
                        TomSessionMgrComponent,
                        LogViewerComponent
                    ],
                    providers: [],
                },] }
    ];
    return TomModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */



//# sourceMappingURL=tomgular.js.map

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/CommandService/RidiQuot.service.ts":
/*!****************************************************!*\
  !*** ./src/app/CommandService/RidiQuot.service.ts ***!
  \****************************************************/
/*! exports provided: NewRidiQuotService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewRidiQuotService", function() { return NewRidiQuotService; });
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _Models_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Models/RidiQuotDataModel */ "./src/app/Models/RidiQuotDataModel.ts");
/* harmony import */ var _Models_RidiQuotViewModel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Models/RidiQuotViewModel */ "./src/app/Models/RidiQuotViewModel.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();




var NewRidiQuotService = /** @class */ (function (_super) {
    __extends(NewRidiQuotService, _super);
    function NewRidiQuotService(completedHandler) {
        var _this = _super.call(this, completedHandler) || this;
        _this.ServiceName = "NewRidiQuotService";
        return _this;
    }
    NewRidiQuotService.prototype.runService = function () {
        var CallItems = [
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CallItem"].buildCallItem("NewRidiQuot", function () { return TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].url.newRidiQuot; }, null),
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CallItem"].buildCallItem("RidiQuotItem", function () { return TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].url.RidiQuotItem; }, null),
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CallItem"].buildCallItem("newRidiLine", function () { return TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].url.newRidiLine; }, null),
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CallItem"].buildCallItem("visibilitySetting", function () { return TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].url.visibilitySetting; }, null),
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CallItem"].buildCallItem("editabilitySetting", function () { return TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].url.editabilitySetting; }, null),
        ];
        this.TaCaller.TaCall(this.ServiceName, CallItems, function (RawContainer) {
            console.log(RawContainer);
            var newQuot = TomFism__WEBPACK_IMPORTED_MODULE_0__["tomDeserializer"].desrial(_Models_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiQuot"], RawContainer.NewRidiQuot);
            var itemList = RawContainer.RidiQuotItem.map(function (v, k) { return TomFism__WEBPACK_IMPORTED_MODULE_0__["tomDeserializer"].desrial(_Models_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiItem"], v); });
            var newRidiLine = TomFism__WEBPACK_IMPORTED_MODULE_0__["tomDeserializer"].desrial(_Models_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiLine"], RawContainer.newRidiLine);
            var visibilitySetting = RawContainer.visibilitySetting;
            var editabilitySetting = RawContainer.editabilitySetting;
            TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel.VisibleSettings = visibilitySetting;
            TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel.EditSettings = editabilitySetting;
            // let dataContainer = new RidiQuotContainer();
            var dataContainer = TomFism__WEBPACK_IMPORTED_MODULE_0__["tomjector"].create(_Models_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiQuotContainer"].name, null);
            //console.log ( dataContainer);
            dataContainer.quot = newQuot;
            dataContainer.items = itemList;
            dataContainer.NewLineTemplate = newRidiLine;
            var ridiQuotVM = new _Models_RidiQuotViewModel__WEBPACK_IMPORTED_MODULE_2__["RidiQuotContainerViewModel"]({
                DataModel: function () { return dataContainer; },
            });
            ridiQuotVM.parentViewModel = TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel;
            TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel.appendPageRootModel(ridiQuotVM);
            TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel.getActiveVM = function () { return ridiQuotVM; };
            TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel.vmRidiQuot = ridiQuotVM;
            ridiQuotVM.init();
            ridiQuotVM.furnish();
            //console.log ( ridiQuotVM.dataModel);
        });
    };
    return NewRidiQuotService;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["TaCallerBaseService"]));



/***/ }),

/***/ "./src/app/CommandService/SMQuot.service.ts":
/*!**************************************************!*\
  !*** ./src/app/CommandService/SMQuot.service.ts ***!
  \**************************************************/
/*! exports provided: InitNewQuotService, SaveNewQuotService, SaveNewClientService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InitNewQuotService", function() { return InitNewQuotService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaveNewQuotService", function() { return SaveNewQuotService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaveNewClientService", function() { return SaveNewClientService; });
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _Models_SmallQuot_ViewModel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Models/SmallQuot.ViewModel */ "./src/app/Models/SmallQuot.ViewModel.ts");
/* harmony import */ var _Models_SmallQuot_DataModel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Models/SmallQuot.DataModel */ "./src/app/Models/SmallQuot.DataModel.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();



var InitNewQuotService = /** @class */ (function (_super) {
    __extends(InitNewQuotService, _super);
    function InitNewQuotService(completedHandler) {
        var _this = _super.call(this, completedHandler) || this;
        _this.ServiceName = "InitNewQuotService";
        return _this;
    }
    InitNewQuotService.prototype.runService = function () {
        var _this = this;
        var CallItems = [
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CallItem"].buildCallItem("QuotEdit", function () { return TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].url.QuotEdit; }, null),
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CallItem"].buildCallItem("ClientList", function () { return TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].url.AllClient; }, null),
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CallItem"].buildCallItem("Codes_BusinessType", function () { return TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].url.getCodeListByCodeType("smallProduct"); }, null),
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CallItem"].buildCallItem("Codes_City", function () { return TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].url.getCodeListByCodeType("City"); }, null)
        ];
        this.TaCaller.TaCall(this.ServiceName, CallItems, function (RawContainer) {
            console.log(RawContainer);
            var QuotEdit = _Models_SmallQuot_DataModel__WEBPACK_IMPORTED_MODULE_2__["smallQuotDataModel"].deserialize(RawContainer.QuotEdit);
            //  console.log ("view Model");
            //  console.log ( AppGlobal.appViewModel);
            console.log(TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel.dataModel);
            QuotEdit.producer1 = TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel.dataModel.loginUser.userid;
            var ClientList = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ListDataModel"]();
            ClientList.childrenModels = RawContainer.ClientList.map(function (c) { return _Models_SmallQuot_DataModel__WEBPACK_IMPORTED_MODULE_2__["smallClientDataModel"].deserialize(c); });
            var Codes_BusinessType = TomFism__WEBPACK_IMPORTED_MODULE_0__["KeyValueItem"].buildKeyValueFromCodeTableList(RawContainer.Codes_BusinessType.map(function (epCode) { return ({ Code: epCode.codevalue, Description: epCode.codedesc }); }));
            var Codes_City = TomFism__WEBPACK_IMPORTED_MODULE_0__["KeyValueItem"].buildKeyValueFromCodeTableList(RawContainer.Codes_City.map(function (epCode) { return ({ Code: epCode.codevalue, Description: epCode.codedesc }); }));
            var dataContainer = new _Models_SmallQuot_DataModel__WEBPACK_IMPORTED_MODULE_2__["SmallQuotDataContainer"]();
            dataContainer.smallQuotModel = QuotEdit;
            dataContainer.Codes_BusinessType = Codes_BusinessType;
            dataContainer.Codes_City = Codes_City;
            dataContainer.ClientList = ClientList;
            // console.log ("container");
            // console.log ( dataContainer);
            var QuotVM = new _Models_SmallQuot_ViewModel__WEBPACK_IMPORTED_MODULE_1__["smallQuotViewModel"]({
                DataModel: function () { return dataContainer; },
            });
            QuotVM.parentViewModel = TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel;
            //AppGlobal.appViewModel.subModels.push ( QuotVM);
            TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel.appendPageRootModel(QuotVM);
            TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel.getActiveVM = function () { return QuotVM; };
            TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel.vmQuot = QuotVM;
            QuotVM.init();
            QuotVM.furnish();
            //CheckpointService.CheckPoint ( QuotVM.CreatingClientPopupModel.dataModel, "first test");
            //QuotVM.CreatingClientPopupModel.dataModel.isShowPopup = true;
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CheckpointService"].CheckPoint(QuotVM.CreatingClientPopupModel.dataModel, "first test");
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CheckpointService"].CheckPoint({ a: "ax", b: "b" }, "2nd test");
            //console.log ( QuotVM.dataModel);
            setTimeout(function () {
                QuotVM.traverseNodes(function (k, vf) {
                    if (!Object(TomFism__WEBPACK_IMPORTED_MODULE_0__["NullorEmpty"])(vf.VirtualFieldComponent)) {
                        vf.startComponentValidation();
                    }
                });
                if (!Object(TomFism__WEBPACK_IMPORTED_MODULE_0__["NullorEmpty"])(_this.completedHandler)) {
                    _this.completedHandler(new TomFism__WEBPACK_IMPORTED_MODULE_0__["ServiceResult"](TomFism__WEBPACK_IMPORTED_MODULE_0__["ServiceReultStates"].OK, QuotVM));
                }
            }, 200);
        });
    };
    return InitNewQuotService;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["TaCallerBaseService"]));

var SaveNewQuotService = /** @class */ (function (_super) {
    __extends(SaveNewQuotService, _super);
    function SaveNewQuotService(dataModel, completedHandler) {
        var _this = _super.call(this, completedHandler) || this;
        _this.dataModel = dataModel;
        _this.ServiceName = "SaveNewQuotService";
        return _this;
    }
    SaveNewQuotService.prototype.runService = function () {
        // CheckpointService.CheckPoint (this.dataModel,  this.ServiceName );
        // return;
        var _this = this;
        var CallItems = [
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CallItem"].buildCallItem("newQuotation", function () { return TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].url.newQuotation; }, function () { return _this.dataModel; }),
        ];
        TomFism__WEBPACK_IMPORTED_MODULE_0__["TAjaxCaller"].BatchCall(this.ServiceName, CallItems, function (RawContainer) {
            console.log(RawContainer); //quotationno
            var quotno = RawContainer.newQuotation.quotationno;
            if (Object(TomFism__WEBPACK_IMPORTED_MODULE_0__["NullorEmpty"])(quotno)) {
                throw TomFism__WEBPACK_IMPORTED_MODULE_0__["tomException"].build("null quotno from saving quot", {
                    module: _this.constructor.name,
                });
            }
            _this.completedHandler(new TomFism__WEBPACK_IMPORTED_MODULE_0__["ServiceResult"](TomFism__WEBPACK_IMPORTED_MODULE_0__["ServiceReultStates"].OK, quotno));
        });
    };
    return SaveNewQuotService;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["TaCallerBaseService"]));

var SaveNewClientService = /** @class */ (function (_super) {
    __extends(SaveNewClientService, _super);
    function SaveNewClientService(dataModel, completedHandler) {
        var _this = _super.call(this, completedHandler) || this;
        _this.dataModel = dataModel;
        _this.ServiceName = "SaveNewClientService";
        return _this;
    }
    SaveNewClientService.prototype.runService = function () {
        var _this = this;
        //console.log ("newclient post data");
        //console.log ( this.dataModel);
        var CallItems = [
            TomFism__WEBPACK_IMPORTED_MODULE_0__["CallItem"].buildCallItem("newClient", function () { return TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].url.newClient; }, function () { return _this.dataModel; }),
        ];
        TomFism__WEBPACK_IMPORTED_MODULE_0__["TAjaxCaller"].BatchCall(this.ServiceName, CallItems, function (RawContainer) {
            //console.log ("result");
            //console.log ( RawContainer);
            _this.completedHandler(new TomFism__WEBPACK_IMPORTED_MODULE_0__["ServiceResult"](TomFism__WEBPACK_IMPORTED_MODULE_0__["ServiceReultStates"].OK, RawContainer));
        });
    };
    return SaveNewClientService;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["TaCallerBaseService"]));



/***/ }),

/***/ "./src/app/CommandService/SmallQuot.cmd.ts":
/*!*************************************************!*\
  !*** ./src/app/CommandService/SmallQuot.cmd.ts ***!
  \*************************************************/
/*! exports provided: smallQuotCmdBase, smallSaveNewClientCmd, smallQuoteSaveNewQuotCmd */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallQuotCmdBase", function() { return smallQuotCmdBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallSaveNewClientCmd", function() { return smallSaveNewClientCmd; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallQuoteSaveNewQuotCmd", function() { return smallQuoteSaveNewQuotCmd; });
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _SMQuot_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SMQuot.service */ "./src/app/CommandService/SMQuot.service.ts");
/* harmony import */ var _Models_SmallQuot_ViewModel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Models/SmallQuot.ViewModel */ "./src/app/Models/SmallQuot.ViewModel.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();



var smallQuotCmdBase = /** @class */ (function (_super) {
    __extends(smallQuotCmdBase, _super);
    function smallQuotCmdBase(init) {
        return _super.call(this, init) || this;
    }
    smallQuotCmdBase.prototype.getQuotVM = function () {
        var vf = this.getSourceField();
        var QuotVM = vf.getViewModel().
            traversAncestor(function (vm) { return vm instanceof _Models_SmallQuot_ViewModel__WEBPACK_IMPORTED_MODULE_2__["smallQuotViewModel"]; });
        return QuotVM;
    };
    return smallQuotCmdBase;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["RoutableCmd"]));

var smallSaveNewClientCmd = /** @class */ (function (_super) {
    __extends(smallSaveNewClientCmd, _super);
    function smallSaveNewClientCmd(init) {
        var _this = _super.call(this, init) || this;
        _this.CmdName = "smallSaveNewClient";
        return _this;
    }
    smallSaveNewClientCmd.prototype.runCmd = function () {
        // let vf : ViewField = this.getSourceField();
        var vf = this.getSourceField();
        var ClientView = vf.getViewModel();
        ClientView.validate();
        if (ClientView.ErrMsgs.length > 0) {
            alert("validation error");
        }
        else {
            //console.log (  ClientView.dataModel);
            var service = new _SMQuot_service__WEBPACK_IMPORTED_MODULE_1__["SaveNewClientService"](ClientView.dataModel, function (result) {
                var quotVM = ClientView.parentViewModel;
                var quotData = quotVM.dataModel.smallQuotModel;
                quotData.clientname = result.ResultContent.newClient.clientname;
                quotData.clientname = result.ResultContent.newClient.clientname;
                var creatClientPopupData = quotVM.CreatingClientPopupModel.dataModel;
                creatClientPopupData.isShowPopup = false;
                // console.log ( result);
                // ClientView.DisplayMsg = "Saved successfully"                
            });
            service.runService();
        }
    };
    return smallSaveNewClientCmd;
}(smallQuotCmdBase));

var smallQuoteSaveNewQuotCmd = /** @class */ (function (_super) {
    __extends(smallQuoteSaveNewQuotCmd, _super);
    function smallQuoteSaveNewQuotCmd(init) {
        var _this = _super.call(this, init) || this;
        _this.CmdName = "smallQuoteSaveNewQuotCmd";
        return _this;
    }
    smallQuoteSaveNewQuotCmd.prototype.runCmd = function () {
        // let vf : ViewField = this.getSourceField();
        var QuotVM = this.getQuotVM();
        QuotVM.validate();
        if (QuotVM.ErrMsgs.length > 0) {
            console.log(QuotVM.ErrMsgs);
            QuotVM.DisplayMsg = "Save not proceeded";
        }
        else {
            console.log(QuotVM.dataModel.smallQuotModel);
            var service = new _SMQuot_service__WEBPACK_IMPORTED_MODULE_1__["SaveNewQuotService"](QuotVM.dataModel.smallQuotModel, function (result) {
                console.log(result);
                QuotVM.dataModel.smallQuotModel.quotationno = result.ResultContent;
                QuotVM.VirtualModelComponent.router.navigate([QuotVM.VersionsLink.FieldValue]);
            });
            service.runService();
        }
    };
    return smallQuoteSaveNewQuotCmd;
}(smallQuotCmdBase));



/***/ }),

/***/ "./src/app/Models/RidiQuotDataModel.ts":
/*!*********************************************!*\
  !*** ./src/app/Models/RidiQuotDataModel.ts ***!
  \*********************************************/
/*! exports provided: RidiItem, RidiLine, RidiStatus, RidiQuot, RidiQuotContainer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RidiItem", function() { return RidiItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RidiLine", function() { return RidiLine; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RidiStatus", function() { return RidiStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RidiQuot", function() { return RidiQuot; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RidiQuotContainer", function() { return RidiQuotContainer; });
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var RidiItem = /** @class */ (function (_super) {
    __extends(RidiItem, _super);
    function RidiItem() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.id = null;
        _this.desc = null;
        _this.price = 0;
        _this.unit = null;
        _this.MinQty = 0;
        return _this;
    }
    return RidiItem;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["DataModelBase"]));

var RidiLine = /** @class */ (function (_super) {
    __extends(RidiLine, _super);
    function RidiLine() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.LineNo = null;
        _this.id = null;
        _this.desc = null;
        _this.unit = null;
        _this.qty = 1;
        _this.price = 0;
        _this.discount = 0;
        return _this;
    }
    Object.defineProperty(RidiLine.prototype, "amount", {
        get: function () {
            console.log("from get_amount :RideLine");
            var amt = Math.round(this.qty * this.price * (1 - this.discount / 100)
                * 100) / 100;
            return amt;
        },
        enumerable: true,
        configurable: true
    });
    return RidiLine;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["DataModelBase"]));

var RidiStatus;
(function (RidiStatus) {
    RidiStatus["edit"] = "edit";
    RidiStatus["view"] = "view";
})(RidiStatus || (RidiStatus = {}));
var RidiQuot = /** @class */ (function (_super) {
    __extends(RidiQuot, _super);
    function RidiQuot() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.status = RidiStatus.edit;
        _this.transDate = null;
        _this.customer = null;
        _this.discount = null;
        _this.total = null;
        _this.deposit = null;
        _this.remaining = null;
        _this.remarks = null;
        _this.childrenModels = [];
        return _this;
    }
    Object.defineProperty(RidiQuot.prototype, "nextLineNo", {
        //lines : RidiLine [] = []
        get: function () {
            if (this.childrenModels.length == 0)
                return 1;
            var lineNOs = this.childrenModels.map(function (v, k) { return v.LineNo; });
            var max = Math.max.apply(Math, lineNOs);
            return ++max;
        },
        enumerable: true,
        configurable: true
    });
    RidiQuot.prototype.reassignLineNos = function () {
        var lineNo = 0;
        for (var _i = 0, _a = this.childrenModels; _i < _a.length; _i++) {
            var l = _a[_i];
            l.LineNo = ++lineNo;
        }
    };
    __decorate([
        Object(TomFism__WEBPACK_IMPORTED_MODULE_0__["JsonProperty"])({ clazz: RidiLine }),
        __metadata("design:type", Array)
    ], RidiQuot.prototype, "childrenModels", void 0);
    return RidiQuot;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["ListDataModel"]));

var RidiQuotContainer = /** @class */ (function (_super) {
    __extends(RidiQuotContainer, _super);
    function RidiQuotContainer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.quot = null;
        _this.items = null;
        _this.NewLineTemplate = null;
        _this.visibilitySettings = [];
        return _this;
    }
    Object.defineProperty(RidiQuotContainer.prototype, "itemKeyValues", {
        get: function () {
            return this.items.map(function (v, k) { return ({ key: v.id, value: v.id }); });
        },
        enumerable: true,
        configurable: true
    });
    __decorate([
        Object(TomFism__WEBPACK_IMPORTED_MODULE_0__["JsonProperty"])({ clazz: RidiQuot }),
        __metadata("design:type", RidiQuot)
    ], RidiQuotContainer.prototype, "quot", void 0);
    __decorate([
        Object(TomFism__WEBPACK_IMPORTED_MODULE_0__["JsonProperty"])({ clazz: RidiItem }),
        __metadata("design:type", Array)
    ], RidiQuotContainer.prototype, "items", void 0);
    return RidiQuotContainer;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["DataModelBase"]));



/***/ }),

/***/ "./src/app/Models/RidiQuotDataOverrideModels.ts":
/*!******************************************************!*\
  !*** ./src/app/Models/RidiQuotDataOverrideModels.ts ***!
  \******************************************************/
/*! exports provided: OverrideRidiLine */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OverrideRidiLine", function() { return OverrideRidiLine; });
/* harmony import */ var _RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./RidiQuotDataModel */ "./src/app/Models/RidiQuotDataModel.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();

// override by DI, add 5% tax
var OverrideRidiLine = /** @class */ (function (_super) {
    __extends(OverrideRidiLine, _super);
    function OverrideRidiLine() {
        return _super.call(this) || this;
        //console.log ( "from constructor: OverrideRidiLine")
    }
    Object.defineProperty(OverrideRidiLine.prototype, "amount", {
        get: function () {
            // console.log ( "from get_amount :OverrideRidiLine")
            // console.log (`qty = ${this.qty}, price = ${this.price}, discount = ${this.discount}`);
            var amt = this.qty * this.price * (1 - this.discount / 100);
            amt = amt * 1.05; // .05 percent tax;
            amt = Math.round(amt * 100) / 100;
            //this.qty * this.price * ( 1 - this.discount/ 100) +700 
            return amt;
        },
        enumerable: true,
        configurable: true
    });
    return OverrideRidiLine;
}(_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_0__["RidiLine"]));



/***/ }),

/***/ "./src/app/Models/RidiQuotViewModel.ts":
/*!*********************************************!*\
  !*** ./src/app/Models/RidiQuotViewModel.ts ***!
  \*********************************************/
/*! exports provided: RidiLineViewModel, RidiQuotViewModel, RidiQuotContainerViewModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RidiLineViewModel", function() { return RidiLineViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RidiQuotViewModel", function() { return RidiQuotViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RidiQuotContainerViewModel", function() { return RidiQuotContainerViewModel; });
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./RidiQuotDataModel */ "./src/app/Models/RidiQuotDataModel.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();



var RidiLineViewModel = /** @class */ (function (_super) {
    __extends(RidiLineViewModel, _super);
    function RidiLineViewModel(CtorParam) {
        var _this = _super.call(this, CtorParam) || this;
        _this.LineNo = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            fieldName: "LineNo"
        });
        _this.id = new TomFism__WEBPACK_IMPORTED_MODULE_0__["SelectViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            fieldName: "id",
            getOptionList: function () { return _this._ParentDataModel.itemKeyValues; },
            setFieldValue: function (value) {
                _this.dataModel.id = value;
                _this.dataModel.price = _this._selectedItem.price;
            },
        });
        _this.desc = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            getFieldValue: function () { return _this._selectedItem ? _this._selectedItem.desc : ""; },
            fieldName: "desc"
        });
        _this.unit = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            getFieldValue: function () { return _this._selectedItem ? _this._selectedItem.unit : ""; },
            fieldName: "unit"
        });
        _this.qty = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            fieldName: "qty"
        });
        _this.price = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            getFieldValue: function () { return _this.dataModel.price; },
            //setFieldValue : (value) => this.dataModel.price = value,
            fieldName: "price"
        });
        _this.discount = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            fieldName: "discount"
        });
        _this.amount = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            // getFieldValue : () => this._selectedItem ?  
            //     Math.round    (
            //         this.dataModel.amount*( 1 -this.dataModel.discount /100)* 100
            //         // (this._selectedItem.price * 
            //         //     this.dataModel.qty * ( 1 -this.dataModel.discount /100) ) * 100
            //     )/ 100
            //     : 0 ,
            fieldName: "amount"
        });
        _this.delete = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ButtonViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "CmdDelete",
            routableCmd: new TomFism__WEBPACK_IMPORTED_MODULE_0__["DirectCmd"]({
                CmdName: "CmdDelete",
                directCmd: function () {
                    var quot = _this._ParentDataModel.quot;
                    Object(TomFism__WEBPACK_IMPORTED_MODULE_0__["removeFromArray"])(quot.childrenModels, _this.dataModel);
                    quot.reassignLineNos();
                    _this.parentViewModel.refreshListView();
                }
            })
        });
        return _this;
    }
    Object.defineProperty(RidiLineViewModel.prototype, "dataModel", {
        get: function () {
            return this._getDataModel();
        },
        enumerable: true,
        configurable: true
    });
    RidiLineViewModel.prototype.items = function () {
        return;
    };
    Object.defineProperty(RidiLineViewModel.prototype, "_selectedItem", {
        get: function () {
            var id = this.id.getFieldValue();
            if (Object(TomFism__WEBPACK_IMPORTED_MODULE_0__["EmptyString"])(id))
                return null;
            //let id = this.id.getFieldValue();
            //console.log ( id.toString());
            //console.log(this._ParentDataModel.items);
            var item = this._ParentDataModel.items.filter(function (v, k) { return v.id == id.toString(); })[0];
            return item;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RidiLineViewModel.prototype, "_ParentDataModel", {
        get: function () {
            return TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].appViewModel.vmRidiQuot.dataModel;
        },
        enumerable: true,
        configurable: true
    });
    return RidiLineViewModel;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewModel"]));

var RidiQuotViewModel = /** @class */ (function (_super) {
    __extends(RidiQuotViewModel, _super);
    function RidiQuotViewModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // constructor ( CtorParam: ViewModel_CtorParam ){
        //     super(CtorParam);
        // }
        //dataModel : RidiQuot;
        _this.ViewModelList = [];
        _this.transDate = new TomFism__WEBPACK_IMPORTED_MODULE_0__["DateViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            fieldName: "transDate",
            validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
        _this.customer = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            fieldName: "customer",
            validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
        });
        _this.discount = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            fieldName: "discount"
        });
        _this.total = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            getFieldValue: function () {
                var _total = 0;
                _this.ViewModelList.forEach(function (v, k) {
                    _total = _total + parseFloat(v.amount.getFieldValue());
                });
                return _total;
            },
            fieldName: "total"
        });
        _this.deposit = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            fieldName: "deposit"
        });
        _this.remaining = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            getFieldValue: function () { return parseFloat(_this.total.getFieldValue()) - parseFloat(_this.deposit.getFieldValue()); },
            fieldName: "remaining"
        });
        _this.remarks = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel; },
            fieldName: "remarks"
        });
        _this.addLine = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ButtonViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "CmdAdd",
            routableCmd: new TomFism__WEBPACK_IMPORTED_MODULE_0__["DirectCmd"]({
                CmdName: "CmdAdd",
                directCmd: function () {
                    var containerData = _this.parentViewModel.dataModel;
                    var json = JSON.stringify(containerData.NewLineTemplate);
                    var line = TomFism__WEBPACK_IMPORTED_MODULE_0__["tomDeserializer"].desrial(_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiLine"], json);
                    line.LineNo = containerData.quot.nextLineNo;
                    containerData.quot.childrenModels.push(line);
                    _this.refreshListView();
                }
            })
        });
        _this.save = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ButtonViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "CmdSave",
            routableCmd: new TomFism__WEBPACK_IMPORTED_MODULE_0__["DirectCmd"]({
                CmdName: "CmdSave",
                directCmd: function () {
                    _this.dataModel.status = _RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiStatus"].view;
                }
            })
        });
        _this.edit = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ButtonViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "CmdEdit",
            routableCmd: new TomFism__WEBPACK_IMPORTED_MODULE_0__["DirectCmd"]({
                CmdName: "CmdEdit",
                directCmd: function () {
                    _this.dataModel.status = _RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiStatus"].edit;
                }
            })
        });
        return _this;
        // buildDressing ( rule:  DressingSetting) : DressingRule {
        //     console.log ("ridi rule")
        //     console.log (rule);
        //     return super.buildDressing( rule);
        // }
        // init(){
        //     super.init();
        //     let c = this.edit;
        //     let key = "editable";
        //     Object.defineProperty(c, key, {                                           
        //         get: () => 
        //         {
        //             let rules = c.editableWardrobe.rules.map ( r => r.rule());
        //             console.log ( rules);
        //              let byRules  : boolean[] = c.editableWardrobe.rules.filter( r => r.rule()).map ( d => d.TargetValue)
        //             if ( byRules.length > 0 ){
        //                 return  byRules[0] ;
        //             }
        //             else
        //                 return true ;
        //         }
        //       });        
        // }
    }
    RidiQuotViewModel.prototype.getStatusValue = function (status) {
        return this.dataModel.status;
    };
    Object.defineProperty(RidiQuotViewModel.prototype, "dataModel", {
        get: function () {
            return this._getDataModel();
        },
        enumerable: true,
        configurable: true
    });
    return RidiQuotViewModel;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewListModel"]));

var RidiQuotContainerViewModel = /** @class */ (function (_super) {
    __extends(RidiQuotContainerViewModel, _super);
    function RidiQuotContainerViewModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.QuotVM = new RidiQuotViewModel({
            DataModel: function () { return _this.dataModel.quot; },
            ItemBuilder: function (content) { return new RidiLineViewModel({
                DataModel: function () { return content; }
            }); }
        });
        return _this;
    }
    Object.defineProperty(RidiQuotContainerViewModel.prototype, "dataModel", {
        get: function () {
            return this._getDataModel();
        },
        enumerable: true,
        configurable: true
    });
    RidiQuotContainerViewModel.prototype.deserializeDataModel = function (json) {
        var deserializer = new TomFism__WEBPACK_IMPORTED_MODULE_0__["tomDeserializer"]();
        //console.log ( json);
        var quoteData = deserializer.deserialize(_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiQuotContainer"], json);
        console.log(quoteData);
        this.CtorParam.DataModel = function () { return quoteData; };
        //dataModel = quoteData;    
        this.init();
    };
    return RidiQuotContainerViewModel;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewModel"]));



/***/ }),

/***/ "./src/app/Models/SmallAppViewModel.ts":
/*!*********************************************!*\
  !*** ./src/app/Models/SmallAppViewModel.ts ***!
  \*********************************************/
/*! exports provided: PolicyStatus, SmallAppDataModel, SmallAppViewModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PolicyStatus", function() { return PolicyStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SmallAppDataModel", function() { return SmallAppDataModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SmallAppViewModel", function() { return SmallAppViewModel; });
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var PolicyStatus;
(function (PolicyStatus) {
    PolicyStatus["NewPolicy"] = "NewPolicy";
    PolicyStatus["EditPolicy"] = "EditPolicy";
})(PolicyStatus || (PolicyStatus = {}));
var SmallAppDataModel = /** @class */ (function (_super) {
    __extends(SmallAppDataModel, _super);
    function SmallAppDataModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.loginUser = { userid: "tomkwan", displayName: "Tom Kwan" };
        _this.urlQuotation = "/quotation";
        _this.urlsmallQuotation = "/editsmallQuotation";
        _this.urlRidiQuot = "/RidiQuot";
        return _this;
    }
    return SmallAppDataModel;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["AppDataModel"]));

var SmallAppViewModel = /** @class */ (function (_super) {
    __extends(SmallAppViewModel, _super);
    function SmallAppViewModel(ctroParam) {
        var _this = _super.call(this, ctroParam) || this;
        _this.policyStatus = PolicyStatus.NewPolicy;
        _this.vmQuot = null;
        _this.vmRidiQuot = null;
        // vfLinkQuotation : ButtonViewField = new ButtonViewField(
        //     {
        //         getFieldValue : () => "/quotation",
        //         routableCmd : new DirectCmd(
        //             {
        //                 directCmd : () =>{}
        //             }
        //         )
        //     }
        // );
        _this.vfLinkQuotation = new TomFism__WEBPACK_IMPORTED_MODULE_0__["LinkViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "urlQuotation",
        });
        _this.vfLinksmallQuotation = new TomFism__WEBPACK_IMPORTED_MODULE_0__["LinkViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "urlsmallQuotation",
        });
        _this.vfLinkRidQuot = new TomFism__WEBPACK_IMPORTED_MODULE_0__["LinkViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "urlRidiQuot",
        });
        return _this;
        ///this.CtorParam = { DataModel = () => new SmallAppDataModel()};
        //super( { DataModel : () => new SmallAppDataModel()});
    }
    Object.defineProperty(SmallAppViewModel.prototype, "dataModel", {
        get: function () {
            return this._getDataModel();
        },
        enumerable: true,
        configurable: true
    });
    SmallAppViewModel.prototype.getStatusValue = function (status) {
        if (status = "PolicyStatus")
            return this.policyStatus.toString();
        else
            return null;
    };
    SmallAppViewModel.build = function (ctroParam, settings) {
        var b = new SmallAppViewModel(ctroParam);
        //b.CtorParam = new SmallAppDataModel();
        return b;
    };
    return SmallAppViewModel;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["AppViewModel"]));



/***/ }),

/***/ "./src/app/Models/SmallQuot.DataModel.ts":
/*!***********************************************!*\
  !*** ./src/app/Models/SmallQuot.DataModel.ts ***!
  \***********************************************/
/*! exports provided: smallQuotDataModel, smallClientDataModel, smallClientListAuxModel, SmallQuotDataContainer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallQuotDataModel", function() { return smallQuotDataModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallClientDataModel", function() { return smallClientDataModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallClientListAuxModel", function() { return smallClientListAuxModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SmallQuotDataContainer", function() { return SmallQuotDataContainer; });
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var smallQuotDataModel = /** @class */ (function (_super) {
    __extends(smallQuotDataModel, _super);
    function smallQuotDataModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.clientname = null;
        _this.clientcode = null;
        _this.producer1 = null;
        _this.businesstype = null;
        _this.commdate = null;
        _this.commdate_string = null;
        _this.quotationno = null;
        return _this;
    }
    smallQuotDataModel.deserialize = function (json) {
        var deserializer = new TomFism__WEBPACK_IMPORTED_MODULE_0__["tomDeserializer"]();
        //console.log ( json);
        var quotModel = deserializer.deserialize(smallQuotDataModel, json);
        return quotModel;
    };
    return smallQuotDataModel;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["DataModelBase"]));

var smallClientDataModel = /** @class */ (function (_super) {
    __extends(smallClientDataModel, _super);
    function smallClientDataModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.clientcode = null;
        _this.mycountry = null;
        _this.mybranch = null;
        _this.clientname = null;
        _this.address1 = null;
        _this.address2 = null;
        _this.address3 = null;
        _this.address4 = null;
        _this.citycode = null;
        _this.postalcode = null;
        _this.telephone = null;
        _this.fax = null;
        _this.personincharge = null;
        _this.position = null;
        _this.email = null;
        return _this;
    }
    smallClientDataModel.deserialize = function (json) {
        var deserializer = new TomFism__WEBPACK_IMPORTED_MODULE_0__["tomDeserializer"]();
        //console.log ( json);
        var client = deserializer.deserialize(smallClientDataModel, json);
        return client;
    };
    return smallClientDataModel;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["DataModelBase"]));

var smallClientListAuxModel = /** @class */ (function (_super) {
    __extends(smallClientListAuxModel, _super);
    function smallClientListAuxModel() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.isShowPopup = false;
        return _this;
    }
    return smallClientListAuxModel;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["DataModelBase"]));

var SmallQuotDataContainer = /** @class */ (function (_super) {
    __extends(SmallQuotDataContainer, _super);
    function SmallQuotDataContainer() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.smallQuotModel = null;
        _this.clientPopupAuxModel = new smallClientListAuxModel();
        _this.CreatingClientPopupAuxModel = new TomFism__WEBPACK_IMPORTED_MODULE_0__["PopupDataModel"]();
        _this.CreatingClientAuxModel = new smallClientDataModel();
        _this.ClientList = null;
        //smallClientDataModel[] ;
        //CreatingClientModel  : smallClientDataModel = null;
        _this.Codes_BusinessType = null;
        _this.Codes_City = null;
        return _this;
    }
    return SmallQuotDataContainer;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["DataModelBase"]));



/***/ }),

/***/ "./src/app/Models/SmallQuot.ViewModel.ts":
/*!***********************************************!*\
  !*** ./src/app/Models/SmallQuot.ViewModel.ts ***!
  \***********************************************/
/*! exports provided: smallQuotSubViewBase, smallClientSearchViewModel, smallCreatingClientViewModel, smallClientListViewModel, smallQuotViewModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallQuotSubViewBase", function() { return smallQuotSubViewBase; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallClientSearchViewModel", function() { return smallClientSearchViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallCreatingClientViewModel", function() { return smallCreatingClientViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallClientListViewModel", function() { return smallClientListViewModel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallQuotViewModel", function() { return smallQuotViewModel; });
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _CommandService_SmallQuot_cmd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../CommandService/SmallQuot.cmd */ "./src/app/CommandService/SmallQuot.cmd.ts");
/* harmony import */ var _SmallQuot_DataModel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./SmallQuot.DataModel */ "./src/app/Models/SmallQuot.DataModel.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();






var smallQuotSubViewBase = /** @class */ (function (_super) {
    __extends(smallQuotSubViewBase, _super);
    function smallQuotSubViewBase(CtorParam) {
        return _super.call(this, CtorParam) || this;
    }
    Object.defineProperty(smallQuotSubViewBase.prototype, "rootQuotViewModel", {
        get: function () {
            return this.traversAncestor(function (vm) { return vm instanceof smallQuotViewModel; });
        },
        enumerable: true,
        configurable: true
    });
    return smallQuotSubViewBase;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewModel"]));

var smallClientSearchViewModel = /** @class */ (function (_super) {
    __extends(smallClientSearchViewModel, _super);
    function smallClientSearchViewModel(CtorParam) {
        var _this = _super.call(this, CtorParam) || this;
        _this.clientname = _this.buildSimpleField("clientname");
        _this.clientcode = _this.buildSimpleField("clientcode");
        _this.address1 = _this.buildSimpleField("address1");
        _this.email = _this.buildSimpleField("email");
        _this.personincharge = _this.buildSimpleField("personincharge");
        _this.telephone = _this.buildSimpleField("telephone");
        _this.PickForQuot = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ButtonViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "PickForQuot",
            routableCmd: new TomFism__WEBPACK_IMPORTED_MODULE_0__["DirectCmd"]({
                CmdName: "PickForQuot",
                directCmd: function () {
                    var QuotVM = _this.rootQuotViewModel;
                    //<smallQuotViewModel>this.traversAncestor( (vm)=> vm instanceof smallQuotViewModel );
                    if (Object(TomFism__WEBPACK_IMPORTED_MODULE_0__["NullorEmpty"])(QuotVM))
                        throw TomFism__WEBPACK_IMPORTED_MODULE_0__["tomException"].build("Quot ViewModel not found from client list picking");
                    else {
                        QuotVM.dataModel.smallQuotModel.clientname = _this.dataModel.clientname;
                        QuotVM.dataModel.smallQuotModel.clientcode = _this.dataModel.clientcode;
                        QuotVM.clientPopupModel.isShowPopup.FieldValue = false;
                    }
                }
            })
        });
        return _this;
    }
    Object.defineProperty(smallClientSearchViewModel.prototype, "dataModel", {
        get: function () {
            return this._getDataModel();
        },
        enumerable: true,
        configurable: true
    });
    return smallClientSearchViewModel;
}(smallQuotSubViewBase));

var smallCreatingClientViewModel = /** @class */ (function (_super) {
    __extends(smallCreatingClientViewModel, _super);
    function smallCreatingClientViewModel(CtorParam) {
        var _this = _super.call(this, CtorParam) || this;
        _this.clientname = _this.buildSimpleField('clientname', null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].setting.config.NameRegex)]);
        _this.address1 = _this.buildSimpleField('address1', null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].setting.config.AddressRegex)]);
        _this.address2 = _this.buildSimpleField('address2', null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].setting.config.AddressRegex)]);
        _this.address3 = _this.buildSimpleField('address3', null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].setting.config.AddressRegex)]);
        _this.address4 = _this.buildSimpleField('address4', null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].setting.config.AddressRegex)]);
        _this.citycode = new TomFism__WEBPACK_IMPORTED_MODULE_0__["SelectViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "citycode",
            getOptionList: function () { return (_this.parentViewModel).dataModel.Codes_City; },
            validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]
        });
        _this.postalcode = _this.buildSimpleField('postalcode');
        _this.telephone = _this.buildSimpleField('telephone');
        _this.fax = _this.buildSimpleField('fax', null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].setting.config.EmailRegex)]);
        _this.personincharge = _this.buildSimpleField('personincharge');
        _this.position = _this.buildSimpleField('position');
        _this.email = _this.buildSimpleField('email', null, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].setting.config.EmailRegex)]);
        _this.SaveClient = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ButtonViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "SaveClient",
            routableCmd: new _CommandService_SmallQuot_cmd__WEBPACK_IMPORTED_MODULE_2__["smallSaveNewClientCmd"]()
        });
        return _this;
    }
    Object.defineProperty(smallCreatingClientViewModel.prototype, "dataModel", {
        get: function () {
            return this._getDataModel();
        },
        enumerable: true,
        configurable: true
    });
    return smallCreatingClientViewModel;
}(smallQuotSubViewBase));

var smallClientListViewModel = /** @class */ (function (_super) {
    __extends(smallClientListViewModel, _super);
    //dataModel : ListDataModel 
    //data : smallClientSearchViewModel[] = null;
    function smallClientListViewModel(CtorParam) {
        var _this = _super.call(this, CtorParam) || this;
        _this.CreateClient = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ButtonViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "CreateClient",
            routableCmd: new TomFism__WEBPACK_IMPORTED_MODULE_0__["DirectCmd"]({
                CmdName: "OpenCreateClientPopup",
                directCmd: function () {
                    var quotVM = _this.parentViewModel;
                    quotVM.doCreateClientFromPopupList();
                }
            })
        });
        _this.SearchClient = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ButtonViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "SearchClient",
            routableCmd: new TomFism__WEBPACK_IMPORTED_MODULE_0__["DirectCmd"]({
                CmdName: "SearchClient",
                directCmd: function () {
                    alert("search client");
                }
            })
        });
        return _this;
    }
    return smallClientListViewModel;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewListModel"]));

var smallQuotViewModel = /** @class */ (function (_super) {
    __extends(smallQuotViewModel, _super);
    function smallQuotViewModel(CtorParam) {
        var _this = _super.call(this, CtorParam) || this;
        _this.Producer = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            fieldName: "producer1",
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel.smallQuotModel; }
        });
        _this.VersionsLink = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewField"]({
            fieldName: "VersionsLink",
            getViewModel: function () { return _this; },
            getFieldValue: function () { return "viewQuotationVersion/" + _this.dataModel.smallQuotModel.quotationno; }
        });
        _this.validatiors = [
            function () {
                for (var _i = 0, _a = Object(TomFism__WEBPACK_IMPORTED_MODULE_0__["valuesOfMap"])(_this.ViewFields); _i < _a.length; _i++) {
                    var f = _a[_i];
                    // exlclude readonly and non-physical
                    if (f.setFieldValue && f.VirtualFieldComponent) {
                        if (f.ErrMsgs) {
                            return TomFism__WEBPACK_IMPORTED_MODULE_0__["tomMsg"].createMsg(TomFism__WEBPACK_IMPORTED_MODULE_0__["tomMsg"], "FieldError(s)", "There are/is error(s) in field(s)");
                        }
                    }
                    else {
                        //debugging
                        console.log(f);
                    }
                }
            },
        ];
        _this.isValidateDecendants = false;
        _this.saveQuot = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ButtonViewField"]({
            getViewModel: function () { return _this; },
            fieldName: "SaveQuot",
            getFieldValue: function () { return _this.dataModel.smallQuotModel.clientname; },
            routableCmd: new _CommandService_SmallQuot_cmd__WEBPACK_IMPORTED_MODULE_2__["smallQuoteSaveNewQuotCmd"]()
        });
        _this.clientname = new TomFism__WEBPACK_IMPORTED_MODULE_0__["ButtonViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel.smallQuotModel; },
            fieldName: "clientname",
            getFieldValue: function () { return _this.dataModel.smallQuotModel.clientname; },
            validators: [function (c) { return _this.dataModel.smallQuotModel.clientname ? null : { "required": "required" }; }],
            routableCmd: new TomFism__WEBPACK_IMPORTED_MODULE_0__["DirectCmd"]({
                CmdName: "PickClientName",
                directCmd: function () { _this.dataModel.clientPopupAuxModel.isShowPopup = true; }
            })
        });
        _this.BusinessType = new TomFism__WEBPACK_IMPORTED_MODULE_0__["SelectViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel.smallQuotModel; },
            fieldName: "businesstype",
            getOptionList: function () { return _this.dataModel.Codes_BusinessType; },
            validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]
        });
        _this.Commdate = new TomFism__WEBPACK_IMPORTED_MODULE_0__["DateViewField"]({
            getViewModel: function () { return _this; },
            getDataModel: function () { return _this.dataModel.smallQuotModel; },
            fieldName: "commdate",
            validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]
        });
        _this.ClientList = new smallClientListViewModel({
            DataModel: function () { return _this.dataModel.ClientList; },
            ItemBuilder: function (clientDataModel) { return new smallClientSearchViewModel({
                DataModel: function () {
                    return clientDataModel;
                }
            }); }
        });
        _this.CreatingClientModel = new smallCreatingClientViewModel({ DataModel: function () { return _this.dataModel.CreatingClientAuxModel; } });
        _this.clientPopupModel = new TomFism__WEBPACK_IMPORTED_MODULE_0__["PopupViewModel"]({
            DataModel: function () { return _this.dataModel.clientPopupAuxModel; },
        });
        _this.CreatingClientPopupModel = new TomFism__WEBPACK_IMPORTED_MODULE_0__["PopupViewModel"]({
            DataModel: function () { return _this.dataModel.CreatingClientPopupAuxModel; },
        });
        return _this;
        //this.dataModel = CtorParam.DataModel();
        // this.dataModel.Codes_BusinessType = CtorParam.Codes_BusinessType
        // this.dataModel.Codes_City= CtorParam.Codes_City
    }
    Object.defineProperty(smallQuotViewModel.prototype, "dataModel", {
        get: function () {
            return this._getDataModel();
        },
        enumerable: true,
        configurable: true
    });
    smallQuotViewModel.prototype.validate = function () {
        var anyError = false;
        this.clientname.VirtualFieldComponent.forceValidation();
        this.BusinessType.VirtualFieldComponent.forceValidation();
        this.Commdate.VirtualFieldComponent.forceValidation();
        //this.clientname.forceValidation();
        //this.BusinessType.forceValidation();
        //this.Commdate.forceValidation();
        return _super.prototype.validate.call(this);
    };
    smallQuotViewModel.prototype.doCreateClientFromPopupList = function () {
        var _this = this;
        //this.dataModel.CreatingClientAuxModel = new smallClientDataModel ( );
        this.CreatingClientModel = new smallCreatingClientViewModel({ DataModel: function () { return _this.dataModel.CreatingClientAuxModel; } });
        this.initSubModel(this.CreatingClientModel);
        this.CreatingClientModel.furnish();
        this.dataModel.clientPopupAuxModel.isShowPopup = false;
        this.dataModel.CreatingClientPopupAuxModel.isShowPopup = true;
    };
    smallQuotViewModel.prototype.init = function () {
        //this.dataModel.clientPopupAuxModel.isShowPopup = true;
        //(<SmallQuotDataContainer>this.CtorParam.DataModel()).clientPopupAuxModel.isShowPopup = true;
        _super.prototype.init.call(this);
    };
    smallQuotViewModel.prototype.deserializeDataModel = function (json) {
        var deserializer = new TomFism__WEBPACK_IMPORTED_MODULE_0__["tomDeserializer"]();
        console.log(json);
        var quoteData = deserializer.deserialize(_SmallQuot_DataModel__WEBPACK_IMPORTED_MODULE_3__["SmallQuotDataContainer"], json);
        console.log(quoteData);
        this.CtorParam.DataModel = function () { return quoteData; };
        //dataModel = quoteData;    
        this.init();
    };
    return smallQuotViewModel;
}(TomFism__WEBPACK_IMPORTED_MODULE_0__["ViewModel"]));



/***/ }),

/***/ "./src/app/app-layout/LayoutModel.ts":
/*!*******************************************!*\
  !*** ./src/app/app-layout/LayoutModel.ts ***!
  \*******************************************/
/*! exports provided: LayoutModel */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LayoutModel", function() { return LayoutModel; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var LayoutModel = /** @class */ (function () {
    function LayoutModel() {
        this.IsReady = false;
        //loginUser : any;
        this.loginUser = { userid: "tomkwan", displayName: "Tom Kwan" };
    }
    LayoutModel = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])()
    ], LayoutModel);
    return LayoutModel;
}());



/***/ }),

/***/ "./src/app/app-layout/app-layout.component.css":
/*!*****************************************************!*\
  !*** ./src/app/app-layout/app-layout.component.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC1sYXlvdXQvYXBwLWxheW91dC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app-layout/app-layout.component.html":
/*!******************************************************!*\
  !*** ./src/app/app-layout/app-layout.component.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<body class=\"nav-sm\">\n\n  <div class=\"container body\" *ngIf=\"model.IsReady\">\n    <div class=\"main_container\">\n      <div class=\"col-md-3 left_col\">\n        <div class=\"left_col scroll-view\">\n\n          <a href=\"#/home\">\n            <img src=\"assets/images/Toms_logo.png\" width=\"70px\" height=\"30px\" >\n            <!-- <img src=\"assets/images/tom-s.svg\" > -->\n          </a>\n\n          <!-- sidebar menu -->\n          <div id=\"sidebar-menu\" class=\"main_menu_side hidden-print main_menu\">\n            <div class=\"menu_section\">\n              <!--<h3>General</h3>-->\n              <ul class=\"nav side-menu\">\n\n\n                    <li class=\"\" name=\"smallQuotation\">\n                      <a [viewField]=\"viewModel.vfLinksmallQuotation\"> <i class=\"fa fa-user\"></i><span translate=\"main.smallQuotation\">smallQuotation</span></a></li>\n  \n\n                 <li class=\"\" name=\"Ridi Quot\" *ngIf=\"viewModel\">\n                    <a [viewField]=\"viewModel.vfLinkRidQuot\"> <i class=\"fa fa-laptop\"></i><span>Ridi Quot</span></a></li>\n  \n                 <li class=\"\" name=\"JCompare\">\n                  <a routerLink=\"/JCompare\"><i class=\"fa fa-print\"></i>\n                    <span>JCompare</span></a></li>\n\n\n              </ul>\n\n\n\n            </div>\n\n          </div>\n\n        </div>\n      </div>\n\n      <!-- top navigation -->\n      <div class=\"top_nav\">\n        <div class=\"nav_menu\">\n          <nav>\n            <!--\n      <div class=\"nav toggle\" style = \"width:60px\">\n              <a id=\"menu_toggle\"><i class=\"fa fa-bars\"></i></a>\n            </div>\n      -->\n            <div class=\"nav toggle title-nav\">\n              <span translate=\"main.TITLE\">ePrecious Quotation</span>\n            </div>\n\n            <div class=\"nav toggle navbar-right logout-nav text-right\">\n              <span><i class=\"icon fa fa-user-circle-o\">{{model.loginUser.displayName}}</i></span>\n\n              <span>\n                <a href=\"logout\" class=\"logout\"><i class=\"icon fa fa-sign-out\"></i><span translate=\"main.LOGOUT\">Logout</span></a>\n              </span>\n            </div>\n\n          </nav>\n        </div>\n      </div>\n      <!-- /top navigation -->\n    </div>\n\n    <!-- page content -->\n    <div class=\"right_col\" role=\"main\" ng-view=\"\" bs-loading-overlay=\"\">\n      <router-outlet></router-outlet>\n    </div>\n\n    <!-- /page content -->\n\n    <footer>\n      &copy; <span translate=\"main.FOOTER\"></span>\n      <span class=\"pull-right\"> <span translate=\"main.FOOTERVER\"></span>4.0.1 </span>\n    </footer>\n\n  </div>\n</body>"

/***/ }),

/***/ "./src/app/app-layout/app-layout.component.ts":
/*!****************************************************!*\
  !*** ./src/app/app-layout/app-layout.component.ts ***!
  \****************************************************/
/*! exports provided: AppLayoutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppLayoutComponent", function() { return AppLayoutComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _LayoutModel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./LayoutModel */ "./src/app/app-layout/LayoutModel.ts");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};





var AppLayoutComponent = /** @class */ (function () {
    function AppLayoutComponent(injector, model) {
        this.model = model;
        this.router = injector.get(_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]);
        this.activeRoute = injector.get(_angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]);
    }
    AppLayoutComponent.prototype.ngOnInit = function () {
        this.readInitData();
    };
    Object.defineProperty(AppLayoutComponent.prototype, "viewModel", {
        get: function () {
            TomFism__WEBPACK_IMPORTED_MODULE_2__["AppGlobal"].appViewModel.VirtualModelComponent = this;
            return TomFism__WEBPACK_IMPORTED_MODULE_2__["AppGlobal"].appViewModel;
        },
        enumerable: true,
        configurable: true
    });
    AppLayoutComponent.prototype.readInitData = function () {
        this.model.IsReady = true;
    };
    AppLayoutComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])(),
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-layout',
            template: __webpack_require__(/*! ./app-layout.component.html */ "./src/app/app-layout/app-layout.component.html"),
            styles: [__webpack_require__(/*! ./app-layout.component.css */ "./src/app/app-layout/app-layout.component.css")],
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"], _LayoutModel__WEBPACK_IMPORTED_MODULE_1__["LayoutModel"]])
    ], AppLayoutComponent);
    return AppLayoutComponent;
}());



/***/ }),

/***/ "./src/app/app-ridi-line/app-ridi-line.component.css":
/*!***********************************************************!*\
  !*** ./src/app/app-ridi-line/app-ridi-line.component.css ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC1yaWRpLWxpbmUvYXBwLXJpZGktbGluZS5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app-ridi-line/app-ridi-line.component.html":
/*!************************************************************!*\
  !*** ./src/app/app-ridi-line/app-ridi-line.component.html ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n  <td style=\"text-align: center\">\n    <tom-button [viewField]=\"viewModel.delete\" style=\"padding:0px;margin:0px\">\n        <span class=\"glyphicon glyphicon-trash\" style=\"padding:0px;margin:0px\"></span>\n    </tom-button>\n\n  </td>\n  <td>\n    <!-- <tom-debugger [viewModel]=\"viewModel\"></tom-debugger> -->\n    <tom-text-box [viewField]=\"viewModel.LineNo\"></tom-text-box>\n  </td>\n\n  <td>\n    <tom-select [viewField]=\"viewModel.id\"></tom-select>\n  </td>\n\n  <td>\n    <tom-text-box [viewField]=\"viewModel.desc\"></tom-text-box>\n  </td>\n\n  <td>\n      <tom-text-box [viewField]=\"viewModel.unit\"></tom-text-box>\n</td>\n  \n\n  <td>\n    <tom-text-box [viewField]=\"viewModel.price\"></tom-text-box>\n  </td>\n\n  <td>\n    <tom-input-box [viewField]=\"viewModel.qty\"></tom-input-box>\n  </td>\n\n  <td>\n    <tom-input-box [viewField]=\"viewModel.discount\"></tom-input-box>\n  </td>\n\n  <td>\n    <!-- <tom-text [viewField]=\"viewModel.amount\"></tom-text> -->\n    <tom-text-box [viewField]=\"viewModel.amount\"></tom-text-box>\n\n  </td>\n\n\n"

/***/ }),

/***/ "./src/app/app-ridi-line/app-ridi-line.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/app-ridi-line/app-ridi-line.component.ts ***!
  \**********************************************************/
/*! exports provided: AppRidiLineComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRidiLineComponent", function() { return AppRidiLineComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AppRidiLineComponent = /** @class */ (function (_super) {
    __extends(AppRidiLineComponent, _super);
    // get viewModel() : RidiLineViewModel
    // {
    //     return   <RidiLineViewModel><any> this._viewModel;
    // }
    function AppRidiLineComponent(injector) {
        return _super.call(this, injector) || this;
    }
    AppRidiLineComponent.prototype.ngOnInit = function () {
    };
    AppRidiLineComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: '[app-ridi-line]',
            template: __webpack_require__(/*! ./app-ridi-line.component.html */ "./src/app/app-ridi-line/app-ridi-line.component.html"),
            styles: [__webpack_require__(/*! ./app-ridi-line.component.css */ "./src/app/app-ridi-line/app-ridi-line.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"]])
    ], AppRidiLineComponent);
    return AppRidiLineComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_1__["ComplexComponentBase"]));



/***/ }),

/***/ "./src/app/app-ridi-quot/app-ridi-quot.component.css":
/*!***********************************************************!*\
  !*** ./src/app/app-ridi-quot/app-ridi-quot.component.css ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC1yaWRpLXF1b3QvYXBwLXJpZGktcXVvdC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app-ridi-quot/app-ridi-quot.component.html":
/*!************************************************************!*\
  !*** ./src/app/app-ridi-quot/app-ridi-quot.component.html ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<tom-debugger [viewModel]=\"viewModel\"></tom-debugger>\n<section class=\"content\" *ngIf=\"IsReady\">\n\n  <div class=\"container\">\n\n    <h1>Ridi Quot</h1>\n\n    <div class=\"panel panel-default\">\n      <div class=\"panel-body\">\n\n        <div class=\"row\">\n\n          <div class=\"form-group col-xs-6\">\n            <tom-input-box label=\"Customer\" [viewField]=\"viewModel.QuotVM.customer\"></tom-input-box>\n          </div>\n          <div class=\"form-group col-xs-6\">\n            <tom-date-box label=\"Date\" [viewField]=\"viewModel.QuotVM.transDate\"></tom-date-box>\n          </div>\n\n        </div>\n        <div class=\"row\">\n          <tom-button [viewField]=\"viewModel.QuotVM.addLine\">\n            <span class=\"glyphicon glyphicon-plus\"></span>\n          </tom-button>\n        </div>\n\n        <div class=\"row\">\n\n          <table>\n\n            <thead>\n              <tr class=\"columnHeaderRow\">\n                <th style=\"width:40px; text-align: center\">Action</th>\n                <th style=\"width:40px; text-align: center\" >#</th>\n                <th style=\"width:100px\">Item</th>\n                <th style=\"width:180px\">Desc</th>\n                <th style=\"width:80px\">Unit </th>\n                <th style=\"width:80px\">Price </th>\n                <th style=\"width:80px\">Qty </th>\n                <th style=\"width:80px\">Disc(%) </th>\n                <th style=\"width:80px\">Amount($) </th>\n\n              </tr>\n            </thead>\n            <tbody>\n               <tr app-ridi-line *ngFor=\"let line of viewModel.QuotVM.ViewModelList\" [viewModel]=\"line\"></tr> \n            </tbody>\n\n             <tfoot>\n\n              <tr>\n                  <td colspan=\"7\"></td>\n                  <td>Deposit</td>\n                  <td>\n                    <div>\n                      <tom-input-box [viewField]=\"viewModel.QuotVM.deposit\"></tom-input-box>\n                    </div>\n                  </td>\n              </tr>\n              <tr>\n                <td colspan=\"7\"></td>\n                <td>Total</td>\n                <td>\n                  <div>\n                    <tom-text-box [viewField]=\"viewModel.QuotVM.total\"></tom-text-box>\n                  </div>\n                </td>\n              </tr>\n              <tr>\n                  <td colspan=\"7\"></td>\n                  <td>Remaining</td>\n                  <td>\n                    <div>\n                      <tom-text-box [viewField]=\"viewModel.QuotVM.remaining\"></tom-text-box>\n                    </div>\n                  </td>\n              </tr>\n              <tr>\n                  <td colspan=\"2\"></td>\n                  <!-- <td>Remarks</td> -->\n                  <td colspan=\"5\">\n                    <div>\n                      <tom-input-box label=\"Remarks\" [viewField]=\"viewModel.QuotVM.remarks\"></tom-input-box>\n                    </div>\n                  </td>\n              </tr>\n\n\n            </tfoot> \n\n          </table>\n\n\n        </div>\n\n        <div class=\"row\">\n\n          <div class=\"form-group col-xs-6 th-row text-right\">\n               <tom-button  [viewField]=\"viewModel.QuotVM.save\">\n                  <span class=\"glyphicon glyphicon-floppy-save\"></span>\n               </tom-button> \n               <tom-button  [viewField]=\"viewModel.QuotVM.edit\">\n                  <span class=\"glyphicon glyphicon-pencil\"></span>\n               </tom-button> \n          </div>\n          \n        </div>\n\n\n      </div>\n    </div>\n\n  </div>\n</section>"

/***/ }),

/***/ "./src/app/app-ridi-quot/app-ridi-quot.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/app-ridi-quot/app-ridi-quot.component.ts ***!
  \**********************************************************/
/*! exports provided: AppRidiQuotComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRidiQuotComponent", function() { return AppRidiQuotComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _CommandService_RidiQuot_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../CommandService/RidiQuot.service */ "./src/app/CommandService/RidiQuot.service.ts");
/* harmony import */ var _Models_RidiQuotViewModel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Models/RidiQuotViewModel */ "./src/app/Models/RidiQuotViewModel.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AppRidiQuotComponent = /** @class */ (function (_super) {
    __extends(AppRidiQuotComponent, _super);
    function AppRidiQuotComponent(injector) {
        var _this = _super.call(this, injector) || this;
        _this.service = new _CommandService_RidiQuot_service__WEBPACK_IMPORTED_MODULE_2__["NewRidiQuotService"](function (result) {
            TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel.getActiveVM = function () { return TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel.vmRidiQuot; };
            console.log("activeVM");
            console.log(TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel.getActiveVM());
        });
        _this.service.runService();
        return _this;
    }
    Object.defineProperty(AppRidiQuotComponent.prototype, "viewModel", {
        get: function () {
            if (Object(TomFism__WEBPACK_IMPORTED_MODULE_1__["NullorEmpty"])(this._viewModel)) {
                var vm = TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel.vmRidiQuot;
                if (vm instanceof _Models_RidiQuotViewModel__WEBPACK_IMPORTED_MODULE_3__["RidiQuotContainerViewModel"]) {
                    this._viewModel = vm;
                    vm.VirtualModelComponent = this;
                    vm.bindVirtualComponent();
                }
            }
            return this._viewModel;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(AppRidiQuotComponent.prototype, "IsReady", {
        get: function () {
            return (this.viewModel != null && !Object(TomFism__WEBPACK_IMPORTED_MODULE_1__["NullorEmpty"])(this.viewModel.dataModel));
        },
        enumerable: true,
        configurable: true
    });
    AppRidiQuotComponent.prototype.ngOnInit = function () {
        var _this = this;
        TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel.getActiveVM = function () { return _this.viewModel; };
        //console.log ( this.viewModel);
    };
    AppRidiQuotComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-ridi-quot',
            template: __webpack_require__(/*! ./app-ridi-quot.component.html */ "./src/app/app-ridi-quot/app-ridi-quot.component.html"),
            styles: [__webpack_require__(/*! ./app-ridi-quot.component.css */ "./src/app/app-ridi-quot/app-ridi-quot.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"]])
    ], AppRidiQuotComponent);
    return AppRidiQuotComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_1__["ComplexComponentBase"]));



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _smequot_edit_smequot_edit_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./smequot-edit/smequot-edit.component */ "./src/app/smequot-edit/smequot-edit.component.ts");
/* harmony import */ var _smeclient_search_smeclient_search_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./smeclient-search/smeclient-search.component */ "./src/app/smeclient-search/smeclient-search.component.ts");
/* harmony import */ var _smeclient_edit_smeclient_edit_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./smeclient-edit/smeclient-edit.component */ "./src/app/smeclient-edit/smeclient-edit.component.ts");
/* harmony import */ var _test_jcompare_test_jcompare_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./test-jcompare/test-jcompare.component */ "./src/app/test-jcompare/test-jcompare.component.ts");
/* harmony import */ var _app_ridi_quot_app_ridi_quot_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-ridi-quot/app-ridi-quot.component */ "./src/app/app-ridi-quot/app-ridi-quot.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var routes = [
    { path: "editsmallQuotation", component: _smequot_edit_smequot_edit_component__WEBPACK_IMPORTED_MODULE_2__["smallQuotEditComponent"] },
    { path: "smallClientSearch", component: _smeclient_search_smeclient_search_component__WEBPACK_IMPORTED_MODULE_3__["smallClientSearchComponent"] },
    { path: "smallClientEdit", component: _smeclient_edit_smeclient_edit_component__WEBPACK_IMPORTED_MODULE_4__["smallClientEditComponent"] },
    { path: "JCompare", component: _test_jcompare_test_jcompare_component__WEBPACK_IMPORTED_MODULE_5__["TestJCompareComponent"] },
    { path: "RidiQuot", component: _app_ridi_quot_app_ridi_quot_component__WEBPACK_IMPORTED_MODULE_6__["AppRidiQuotComponent"] }
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes, { useHash: true })],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app-tomangular.ts":
/*!***********************************!*\
  !*** ./src/app/app-tomangular.ts ***!
  \***********************************/
/*! exports provided: AppTomangularModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppTomangularModule", function() { return AppTomangularModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var ngx_json_viewer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ngx-json-viewer */ "./node_modules/ngx-json-viewer/ngx-json-viewer.es5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var tomgular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tomgular */ "./dist/tomgular/fesm5/tomgular.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var AppTomangularModule = /** @class */ (function () {
    function AppTomangularModule() {
    }
    AppTomangularModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomButtonComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomDateBoxComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomCheckBoxComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomSelectComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomRadioComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomDebuggerComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomMsgListComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomInputBoxComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomVisibleDirective"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["SimDriverComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["SimpleLinkComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomButtonInputComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomCmdLinkComponent"],
                //     SafeUrlPipe,
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomClickableDirective"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["tomLink"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomCheckPointResultComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomFileComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomLogComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomPopupComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomTextAreaComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomUploaderComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomViewPaginatorComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomViewTableComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomSessionMgrComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomViewSortDirective"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomTextComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["LogViewerComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_4__["BrowserModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_5__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__["NgbModule"],
                ngx_json_viewer__WEBPACK_IMPORTED_MODULE_2__["NgxJsonViewerModule"]
            ],
            exports: [
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomButtonComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomDateBoxComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomCheckBoxComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomSelectComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomRadioComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomDebuggerComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomMsgListComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomInputBoxComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomVisibleDirective"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["SimDriverComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["SimpleLinkComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomButtonInputComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomCmdLinkComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomClickableDirective"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["tomLink"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomCheckPointResultComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomLogComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomPopupComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomTextAreaComponent"],
                // TomTextBoxComponent,
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomUploaderComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomViewPaginatorComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomViewTableComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomSessionMgrComponent"],
                tomgular__WEBPACK_IMPORTED_MODULE_6__["TomTextComponent"]
            ],
        })
    ], AppTomangularModule);
    return AppTomangularModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".loading {\r\n    z-index: 999999;\r\n    visibility: visible;\r\n    position:absolute;\r\n}\r\n\r\n#floatingBarsG{\r\n\tposition:relative;\r\n\twidth:132px;\r\n\theight:164px;\r\n    margin:auto;\r\n    z-index: 99999;\r\n    visibility: visible;\r\n}\r\n\r\n.blockG{\r\n\tposition:absolute;\r\n\tbackground-color:rgb(255,255,255);\r\n\twidth:21px;\r\n\theight:51px;\r\n\tborder-radius:17px 17px 0 0;\r\n\t\t-o-border-radius:17px 17px 0 0;\r\n\t\t-ms-border-radius:17px 17px 0 0;\r\n\t\t-webkit-border-radius:17px 17px 0 0;\r\n\t\t-moz-border-radius:17px 17px 0 0;\r\n\ttransform:scale(0.4);\r\n\t\t-o-transform:scale(0.4);\r\n\t\t-ms-transform:scale(0.4);\r\n\t\t-webkit-transform:scale(0.4);\r\n\t\t-moz-transform:scale(0.4);\r\n\tanimation-name:fadeG;\r\n\t\t-o-animation-name:fadeG;\r\n\t\t-ms-animation-name:fadeG;\r\n\t\t-webkit-animation-name:fadeG;\r\n\t\t-moz-animation-name:fadeG;\r\n\tanimation-duration:1.2s;\r\n\t\t-o-animation-duration:1.2s;\r\n\t\t-ms-animation-duration:1.2s;\r\n\t\t-webkit-animation-duration:1.2s;\r\n\t\t-moz-animation-duration:1.2s;\r\n\tanimation-iteration-count:infinite;\r\n\t\t-o-animation-iteration-count:infinite;\r\n\t\t-ms-animation-iteration-count:infinite;\r\n\t\t-webkit-animation-iteration-count:infinite;\r\n\t\t-moz-animation-iteration-count:infinite;\r\n\tanimation-direction:normal;\r\n\t\t-o-animation-direction:normal;\r\n\t\t-ms-animation-direction:normal;\r\n\t\t-webkit-animation-direction:normal;\r\n\t\t-moz-animation-direction:normal;\r\n}\r\n\r\n#rotateG_01{\r\n\tleft:0;\r\n\ttop:60px;\r\n\tanimation-delay:0.45s;\r\n\t\t-o-animation-delay:0.45s;\r\n\t\t-ms-animation-delay:0.45s;\r\n\t\t-webkit-animation-delay:0.45s;\r\n\t\t-moz-animation-delay:0.45s;\r\n\ttransform:rotate(-90deg);\r\n\t\t-o-transform:rotate(-90deg);\r\n\t\t-ms-transform:rotate(-90deg);\r\n\t\t-webkit-transform:rotate(-90deg);\r\n\t\t-moz-transform:rotate(-90deg);\r\n}\r\n\r\n#rotateG_02{\r\n\tleft:17px;\r\n\ttop:21px;\r\n\tanimation-delay:0.6s;\r\n\t\t-o-animation-delay:0.6s;\r\n\t\t-ms-animation-delay:0.6s;\r\n\t\t-webkit-animation-delay:0.6s;\r\n\t\t-moz-animation-delay:0.6s;\r\n\ttransform:rotate(-45deg);\r\n\t\t-o-transform:rotate(-45deg);\r\n\t\t-ms-transform:rotate(-45deg);\r\n\t\t-webkit-transform:rotate(-45deg);\r\n\t\t-moz-transform:rotate(-45deg);\r\n}\r\n\r\n#rotateG_03{\r\n\tleft:55px;\r\n\ttop:6px;\r\n\tanimation-delay:0.75s;\r\n\t\t-o-animation-delay:0.75s;\r\n\t\t-ms-animation-delay:0.75s;\r\n\t\t-webkit-animation-delay:0.75s;\r\n\t\t-moz-animation-delay:0.75s;\r\n\ttransform:rotate(0deg);\r\n\t\t-o-transform:rotate(0deg);\r\n\t\t-ms-transform:rotate(0deg);\r\n\t\t-webkit-transform:rotate(0deg);\r\n\t\t-moz-transform:rotate(0deg);\r\n}\r\n\r\n#rotateG_04{\r\n\tright:17px;\r\n\ttop:21px;\r\n\tanimation-delay:0.9s;\r\n\t\t-o-animation-delay:0.9s;\r\n\t\t-ms-animation-delay:0.9s;\r\n\t\t-webkit-animation-delay:0.9s;\r\n\t\t-moz-animation-delay:0.9s;\r\n\ttransform:rotate(45deg);\r\n\t\t-o-transform:rotate(45deg);\r\n\t\t-ms-transform:rotate(45deg);\r\n\t\t-webkit-transform:rotate(45deg);\r\n\t\t-moz-transform:rotate(45deg);\r\n}\r\n\r\n#rotateG_05{\r\n\tright:0;\r\n\ttop:60px;\r\n\tanimation-delay:1.05s;\r\n\t\t-o-animation-delay:1.05s;\r\n\t\t-ms-animation-delay:1.05s;\r\n\t\t-webkit-animation-delay:1.05s;\r\n\t\t-moz-animation-delay:1.05s;\r\n\ttransform:rotate(90deg);\r\n\t\t-o-transform:rotate(90deg);\r\n\t\t-ms-transform:rotate(90deg);\r\n\t\t-webkit-transform:rotate(90deg);\r\n\t\t-moz-transform:rotate(90deg);\r\n}\r\n\r\n#rotateG_06{\r\n\tright:17px;\r\n\tbottom:15px;\r\n\tanimation-delay:1.2s;\r\n\t\t-o-animation-delay:1.2s;\r\n\t\t-ms-animation-delay:1.2s;\r\n\t\t-webkit-animation-delay:1.2s;\r\n\t\t-moz-animation-delay:1.2s;\r\n\ttransform:rotate(135deg);\r\n\t\t-o-transform:rotate(135deg);\r\n\t\t-ms-transform:rotate(135deg);\r\n\t\t-webkit-transform:rotate(135deg);\r\n\t\t-moz-transform:rotate(135deg);\r\n}\r\n\r\n#rotateG_07{\r\n\tbottom:0;\r\n\tleft:55px;\r\n\tanimation-delay:1.35s;\r\n\t\t-o-animation-delay:1.35s;\r\n\t\t-ms-animation-delay:1.35s;\r\n\t\t-webkit-animation-delay:1.35s;\r\n\t\t-moz-animation-delay:1.35s;\r\n\ttransform:rotate(180deg);\r\n\t\t-o-transform:rotate(180deg);\r\n\t\t-ms-transform:rotate(180deg);\r\n\t\t-webkit-transform:rotate(180deg);\r\n\t\t-moz-transform:rotate(180deg);\r\n}\r\n\r\n#rotateG_08{\r\n\tleft:17px;\r\n\tbottom:15px;\r\n\tanimation-delay:1.5s;\r\n\t\t-o-animation-delay:1.5s;\r\n\t\t-ms-animation-delay:1.5s;\r\n\t\t-webkit-animation-delay:1.5s;\r\n\t\t-moz-animation-delay:1.5s;\r\n\ttransform:rotate(-135deg);\r\n\t\t-o-transform:rotate(-135deg);\r\n\t\t-ms-transform:rotate(-135deg);\r\n\t\t-webkit-transform:rotate(-135deg);\r\n\t\t-moz-transform:rotate(-135deg);\r\n}\r\n\r\n@keyframes fadeG{\r\n\t0%{\r\n\t\tbackground-color:rgb(247,0,247);\r\n\t}\r\n\r\n\t100%{\r\n\t\tbackground-color:rgb(255,255,255);\r\n\t}\r\n}\r\n\r\n@-webkit-keyframes fadeG{\r\n\t0%{\r\n\t\tbackground-color:rgb(247,0,247);\r\n\t}\r\n\r\n\t100%{\r\n\t\tbackground-color:rgb(255,255,255);\r\n\t}\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxnQkFBZ0I7SUFDaEIsb0JBQW9CO0lBQ3BCLGtCQUFrQjtDQUNyQjs7QUFFRDtDQUNDLGtCQUFrQjtDQUNsQixZQUFZO0NBQ1osYUFBYTtJQUNWLFlBQVk7SUFDWixlQUFlO0lBQ2Ysb0JBQW9CO0NBQ3ZCOztBQUVEO0NBQ0Msa0JBQWtCO0NBQ2xCLGtDQUFrQztDQUNsQyxXQUFXO0NBQ1gsWUFBWTtDQUNaLDRCQUE0QjtFQUMzQiwrQkFBK0I7RUFDL0IsZ0NBQWdDO0VBQ2hDLG9DQUFvQztFQUNwQyxpQ0FBaUM7Q0FDbEMscUJBQXFCO0VBQ3BCLHdCQUF3QjtFQUN4Qix5QkFBeUI7RUFDekIsNkJBQTZCO0VBQzdCLDBCQUEwQjtDQUMzQixxQkFBcUI7RUFDcEIsd0JBQXdCO0VBQ3hCLHlCQUF5QjtFQUN6Qiw2QkFBNkI7RUFDN0IsMEJBQTBCO0NBQzNCLHdCQUF3QjtFQUN2QiwyQkFBMkI7RUFDM0IsNEJBQTRCO0VBQzVCLGdDQUFnQztFQUNoQyw2QkFBNkI7Q0FDOUIsbUNBQW1DO0VBQ2xDLHNDQUFzQztFQUN0Qyx1Q0FBdUM7RUFDdkMsMkNBQTJDO0VBQzNDLHdDQUF3QztDQUN6QywyQkFBMkI7RUFDMUIsOEJBQThCO0VBQzlCLCtCQUErQjtFQUMvQixtQ0FBbUM7RUFDbkMsZ0NBQWdDO0NBQ2pDOztBQUVEO0NBQ0MsT0FBTztDQUNQLFNBQVM7Q0FDVCxzQkFBc0I7RUFDckIseUJBQXlCO0VBQ3pCLDBCQUEwQjtFQUMxQiw4QkFBOEI7RUFDOUIsMkJBQTJCO0NBQzVCLHlCQUF5QjtFQUN4Qiw0QkFBNEI7RUFDNUIsNkJBQTZCO0VBQzdCLGlDQUFpQztFQUNqQyw4QkFBOEI7Q0FDL0I7O0FBRUQ7Q0FDQyxVQUFVO0NBQ1YsU0FBUztDQUNULHFCQUFxQjtFQUNwQix3QkFBd0I7RUFDeEIseUJBQXlCO0VBQ3pCLDZCQUE2QjtFQUM3QiwwQkFBMEI7Q0FDM0IseUJBQXlCO0VBQ3hCLDRCQUE0QjtFQUM1Qiw2QkFBNkI7RUFDN0IsaUNBQWlDO0VBQ2pDLDhCQUE4QjtDQUMvQjs7QUFFRDtDQUNDLFVBQVU7Q0FDVixRQUFRO0NBQ1Isc0JBQXNCO0VBQ3JCLHlCQUF5QjtFQUN6QiwwQkFBMEI7RUFDMUIsOEJBQThCO0VBQzlCLDJCQUEyQjtDQUM1Qix1QkFBdUI7RUFDdEIsMEJBQTBCO0VBQzFCLDJCQUEyQjtFQUMzQiwrQkFBK0I7RUFDL0IsNEJBQTRCO0NBQzdCOztBQUVEO0NBQ0MsV0FBVztDQUNYLFNBQVM7Q0FDVCxxQkFBcUI7RUFDcEIsd0JBQXdCO0VBQ3hCLHlCQUF5QjtFQUN6Qiw2QkFBNkI7RUFDN0IsMEJBQTBCO0NBQzNCLHdCQUF3QjtFQUN2QiwyQkFBMkI7RUFDM0IsNEJBQTRCO0VBQzVCLGdDQUFnQztFQUNoQyw2QkFBNkI7Q0FDOUI7O0FBRUQ7Q0FDQyxRQUFRO0NBQ1IsU0FBUztDQUNULHNCQUFzQjtFQUNyQix5QkFBeUI7RUFDekIsMEJBQTBCO0VBQzFCLDhCQUE4QjtFQUM5QiwyQkFBMkI7Q0FDNUIsd0JBQXdCO0VBQ3ZCLDJCQUEyQjtFQUMzQiw0QkFBNEI7RUFDNUIsZ0NBQWdDO0VBQ2hDLDZCQUE2QjtDQUM5Qjs7QUFFRDtDQUNDLFdBQVc7Q0FDWCxZQUFZO0NBQ1oscUJBQXFCO0VBQ3BCLHdCQUF3QjtFQUN4Qix5QkFBeUI7RUFDekIsNkJBQTZCO0VBQzdCLDBCQUEwQjtDQUMzQix5QkFBeUI7RUFDeEIsNEJBQTRCO0VBQzVCLDZCQUE2QjtFQUM3QixpQ0FBaUM7RUFDakMsOEJBQThCO0NBQy9COztBQUVEO0NBQ0MsU0FBUztDQUNULFVBQVU7Q0FDVixzQkFBc0I7RUFDckIseUJBQXlCO0VBQ3pCLDBCQUEwQjtFQUMxQiw4QkFBOEI7RUFDOUIsMkJBQTJCO0NBQzVCLHlCQUF5QjtFQUN4Qiw0QkFBNEI7RUFDNUIsNkJBQTZCO0VBQzdCLGlDQUFpQztFQUNqQyw4QkFBOEI7Q0FDL0I7O0FBRUQ7Q0FDQyxVQUFVO0NBQ1YsWUFBWTtDQUNaLHFCQUFxQjtFQUNwQix3QkFBd0I7RUFDeEIseUJBQXlCO0VBQ3pCLDZCQUE2QjtFQUM3QiwwQkFBMEI7Q0FDM0IsMEJBQTBCO0VBQ3pCLDZCQUE2QjtFQUM3Qiw4QkFBOEI7RUFDOUIsa0NBQWtDO0VBQ2xDLCtCQUErQjtDQUNoQzs7QUFJRDtDQUNDO0VBQ0MsZ0NBQWdDO0VBQ2hDOztDQUVEO0VBQ0Msa0NBQWtDO0VBQ2xDO0NBQ0Q7O0FBc0JEO0NBQ0M7RUFDQyxnQ0FBZ0M7RUFDaEM7O0NBRUQ7RUFDQyxrQ0FBa0M7RUFDbEM7Q0FDRCIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxvYWRpbmcge1xyXG4gICAgei1pbmRleDogOTk5OTk5O1xyXG4gICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcclxuICAgIHBvc2l0aW9uOmFic29sdXRlO1xyXG59XHJcblxyXG4jZmxvYXRpbmdCYXJzR3tcclxuXHRwb3NpdGlvbjpyZWxhdGl2ZTtcclxuXHR3aWR0aDoxMzJweDtcclxuXHRoZWlnaHQ6MTY0cHg7XHJcbiAgICBtYXJnaW46YXV0bztcclxuICAgIHotaW5kZXg6IDk5OTk5O1xyXG4gICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcclxufVxyXG5cclxuLmJsb2NrR3tcclxuXHRwb3NpdGlvbjphYnNvbHV0ZTtcclxuXHRiYWNrZ3JvdW5kLWNvbG9yOnJnYigyNTUsMjU1LDI1NSk7XHJcblx0d2lkdGg6MjFweDtcclxuXHRoZWlnaHQ6NTFweDtcclxuXHRib3JkZXItcmFkaXVzOjE3cHggMTdweCAwIDA7XHJcblx0XHQtby1ib3JkZXItcmFkaXVzOjE3cHggMTdweCAwIDA7XHJcblx0XHQtbXMtYm9yZGVyLXJhZGl1czoxN3B4IDE3cHggMCAwO1xyXG5cdFx0LXdlYmtpdC1ib3JkZXItcmFkaXVzOjE3cHggMTdweCAwIDA7XHJcblx0XHQtbW96LWJvcmRlci1yYWRpdXM6MTdweCAxN3B4IDAgMDtcclxuXHR0cmFuc2Zvcm06c2NhbGUoMC40KTtcclxuXHRcdC1vLXRyYW5zZm9ybTpzY2FsZSgwLjQpO1xyXG5cdFx0LW1zLXRyYW5zZm9ybTpzY2FsZSgwLjQpO1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUoMC40KTtcclxuXHRcdC1tb3otdHJhbnNmb3JtOnNjYWxlKDAuNCk7XHJcblx0YW5pbWF0aW9uLW5hbWU6ZmFkZUc7XHJcblx0XHQtby1hbmltYXRpb24tbmFtZTpmYWRlRztcclxuXHRcdC1tcy1hbmltYXRpb24tbmFtZTpmYWRlRztcclxuXHRcdC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6ZmFkZUc7XHJcblx0XHQtbW96LWFuaW1hdGlvbi1uYW1lOmZhZGVHO1xyXG5cdGFuaW1hdGlvbi1kdXJhdGlvbjoxLjJzO1xyXG5cdFx0LW8tYW5pbWF0aW9uLWR1cmF0aW9uOjEuMnM7XHJcblx0XHQtbXMtYW5pbWF0aW9uLWR1cmF0aW9uOjEuMnM7XHJcblx0XHQtd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjoxLjJzO1xyXG5cdFx0LW1vei1hbmltYXRpb24tZHVyYXRpb246MS4ycztcclxuXHRhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OmluZmluaXRlO1xyXG5cdFx0LW8tYW5pbWF0aW9uLWl0ZXJhdGlvbi1jb3VudDppbmZpbml0ZTtcclxuXHRcdC1tcy1hbmltYXRpb24taXRlcmF0aW9uLWNvdW50OmluZmluaXRlO1xyXG5cdFx0LXdlYmtpdC1hbmltYXRpb24taXRlcmF0aW9uLWNvdW50OmluZmluaXRlO1xyXG5cdFx0LW1vei1hbmltYXRpb24taXRlcmF0aW9uLWNvdW50OmluZmluaXRlO1xyXG5cdGFuaW1hdGlvbi1kaXJlY3Rpb246bm9ybWFsO1xyXG5cdFx0LW8tYW5pbWF0aW9uLWRpcmVjdGlvbjpub3JtYWw7XHJcblx0XHQtbXMtYW5pbWF0aW9uLWRpcmVjdGlvbjpub3JtYWw7XHJcblx0XHQtd2Via2l0LWFuaW1hdGlvbi1kaXJlY3Rpb246bm9ybWFsO1xyXG5cdFx0LW1vei1hbmltYXRpb24tZGlyZWN0aW9uOm5vcm1hbDtcclxufVxyXG5cclxuI3JvdGF0ZUdfMDF7XHJcblx0bGVmdDowO1xyXG5cdHRvcDo2MHB4O1xyXG5cdGFuaW1hdGlvbi1kZWxheTowLjQ1cztcclxuXHRcdC1vLWFuaW1hdGlvbi1kZWxheTowLjQ1cztcclxuXHRcdC1tcy1hbmltYXRpb24tZGVsYXk6MC40NXM7XHJcblx0XHQtd2Via2l0LWFuaW1hdGlvbi1kZWxheTowLjQ1cztcclxuXHRcdC1tb3otYW5pbWF0aW9uLWRlbGF5OjAuNDVzO1xyXG5cdHRyYW5zZm9ybTpyb3RhdGUoLTkwZGVnKTtcclxuXHRcdC1vLXRyYW5zZm9ybTpyb3RhdGUoLTkwZGVnKTtcclxuXHRcdC1tcy10cmFuc2Zvcm06cm90YXRlKC05MGRlZyk7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTpyb3RhdGUoLTkwZGVnKTtcclxuXHRcdC1tb3otdHJhbnNmb3JtOnJvdGF0ZSgtOTBkZWcpO1xyXG59XHJcblxyXG4jcm90YXRlR18wMntcclxuXHRsZWZ0OjE3cHg7XHJcblx0dG9wOjIxcHg7XHJcblx0YW5pbWF0aW9uLWRlbGF5OjAuNnM7XHJcblx0XHQtby1hbmltYXRpb24tZGVsYXk6MC42cztcclxuXHRcdC1tcy1hbmltYXRpb24tZGVsYXk6MC42cztcclxuXHRcdC13ZWJraXQtYW5pbWF0aW9uLWRlbGF5OjAuNnM7XHJcblx0XHQtbW96LWFuaW1hdGlvbi1kZWxheTowLjZzO1xyXG5cdHRyYW5zZm9ybTpyb3RhdGUoLTQ1ZGVnKTtcclxuXHRcdC1vLXRyYW5zZm9ybTpyb3RhdGUoLTQ1ZGVnKTtcclxuXHRcdC1tcy10cmFuc2Zvcm06cm90YXRlKC00NWRlZyk7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTpyb3RhdGUoLTQ1ZGVnKTtcclxuXHRcdC1tb3otdHJhbnNmb3JtOnJvdGF0ZSgtNDVkZWcpO1xyXG59XHJcblxyXG4jcm90YXRlR18wM3tcclxuXHRsZWZ0OjU1cHg7XHJcblx0dG9wOjZweDtcclxuXHRhbmltYXRpb24tZGVsYXk6MC43NXM7XHJcblx0XHQtby1hbmltYXRpb24tZGVsYXk6MC43NXM7XHJcblx0XHQtbXMtYW5pbWF0aW9uLWRlbGF5OjAuNzVzO1xyXG5cdFx0LXdlYmtpdC1hbmltYXRpb24tZGVsYXk6MC43NXM7XHJcblx0XHQtbW96LWFuaW1hdGlvbi1kZWxheTowLjc1cztcclxuXHR0cmFuc2Zvcm06cm90YXRlKDBkZWcpO1xyXG5cdFx0LW8tdHJhbnNmb3JtOnJvdGF0ZSgwZGVnKTtcclxuXHRcdC1tcy10cmFuc2Zvcm06cm90YXRlKDBkZWcpO1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06cm90YXRlKDBkZWcpO1xyXG5cdFx0LW1vei10cmFuc2Zvcm06cm90YXRlKDBkZWcpO1xyXG59XHJcblxyXG4jcm90YXRlR18wNHtcclxuXHRyaWdodDoxN3B4O1xyXG5cdHRvcDoyMXB4O1xyXG5cdGFuaW1hdGlvbi1kZWxheTowLjlzO1xyXG5cdFx0LW8tYW5pbWF0aW9uLWRlbGF5OjAuOXM7XHJcblx0XHQtbXMtYW5pbWF0aW9uLWRlbGF5OjAuOXM7XHJcblx0XHQtd2Via2l0LWFuaW1hdGlvbi1kZWxheTowLjlzO1xyXG5cdFx0LW1vei1hbmltYXRpb24tZGVsYXk6MC45cztcclxuXHR0cmFuc2Zvcm06cm90YXRlKDQ1ZGVnKTtcclxuXHRcdC1vLXRyYW5zZm9ybTpyb3RhdGUoNDVkZWcpO1xyXG5cdFx0LW1zLXRyYW5zZm9ybTpyb3RhdGUoNDVkZWcpO1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06cm90YXRlKDQ1ZGVnKTtcclxuXHRcdC1tb3otdHJhbnNmb3JtOnJvdGF0ZSg0NWRlZyk7XHJcbn1cclxuXHJcbiNyb3RhdGVHXzA1e1xyXG5cdHJpZ2h0OjA7XHJcblx0dG9wOjYwcHg7XHJcblx0YW5pbWF0aW9uLWRlbGF5OjEuMDVzO1xyXG5cdFx0LW8tYW5pbWF0aW9uLWRlbGF5OjEuMDVzO1xyXG5cdFx0LW1zLWFuaW1hdGlvbi1kZWxheToxLjA1cztcclxuXHRcdC13ZWJraXQtYW5pbWF0aW9uLWRlbGF5OjEuMDVzO1xyXG5cdFx0LW1vei1hbmltYXRpb24tZGVsYXk6MS4wNXM7XHJcblx0dHJhbnNmb3JtOnJvdGF0ZSg5MGRlZyk7XHJcblx0XHQtby10cmFuc2Zvcm06cm90YXRlKDkwZGVnKTtcclxuXHRcdC1tcy10cmFuc2Zvcm06cm90YXRlKDkwZGVnKTtcclxuXHRcdC13ZWJraXQtdHJhbnNmb3JtOnJvdGF0ZSg5MGRlZyk7XHJcblx0XHQtbW96LXRyYW5zZm9ybTpyb3RhdGUoOTBkZWcpO1xyXG59XHJcblxyXG4jcm90YXRlR18wNntcclxuXHRyaWdodDoxN3B4O1xyXG5cdGJvdHRvbToxNXB4O1xyXG5cdGFuaW1hdGlvbi1kZWxheToxLjJzO1xyXG5cdFx0LW8tYW5pbWF0aW9uLWRlbGF5OjEuMnM7XHJcblx0XHQtbXMtYW5pbWF0aW9uLWRlbGF5OjEuMnM7XHJcblx0XHQtd2Via2l0LWFuaW1hdGlvbi1kZWxheToxLjJzO1xyXG5cdFx0LW1vei1hbmltYXRpb24tZGVsYXk6MS4ycztcclxuXHR0cmFuc2Zvcm06cm90YXRlKDEzNWRlZyk7XHJcblx0XHQtby10cmFuc2Zvcm06cm90YXRlKDEzNWRlZyk7XHJcblx0XHQtbXMtdHJhbnNmb3JtOnJvdGF0ZSgxMzVkZWcpO1xyXG5cdFx0LXdlYmtpdC10cmFuc2Zvcm06cm90YXRlKDEzNWRlZyk7XHJcblx0XHQtbW96LXRyYW5zZm9ybTpyb3RhdGUoMTM1ZGVnKTtcclxufVxyXG5cclxuI3JvdGF0ZUdfMDd7XHJcblx0Ym90dG9tOjA7XHJcblx0bGVmdDo1NXB4O1xyXG5cdGFuaW1hdGlvbi1kZWxheToxLjM1cztcclxuXHRcdC1vLWFuaW1hdGlvbi1kZWxheToxLjM1cztcclxuXHRcdC1tcy1hbmltYXRpb24tZGVsYXk6MS4zNXM7XHJcblx0XHQtd2Via2l0LWFuaW1hdGlvbi1kZWxheToxLjM1cztcclxuXHRcdC1tb3otYW5pbWF0aW9uLWRlbGF5OjEuMzVzO1xyXG5cdHRyYW5zZm9ybTpyb3RhdGUoMTgwZGVnKTtcclxuXHRcdC1vLXRyYW5zZm9ybTpyb3RhdGUoMTgwZGVnKTtcclxuXHRcdC1tcy10cmFuc2Zvcm06cm90YXRlKDE4MGRlZyk7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTpyb3RhdGUoMTgwZGVnKTtcclxuXHRcdC1tb3otdHJhbnNmb3JtOnJvdGF0ZSgxODBkZWcpO1xyXG59XHJcblxyXG4jcm90YXRlR18wOHtcclxuXHRsZWZ0OjE3cHg7XHJcblx0Ym90dG9tOjE1cHg7XHJcblx0YW5pbWF0aW9uLWRlbGF5OjEuNXM7XHJcblx0XHQtby1hbmltYXRpb24tZGVsYXk6MS41cztcclxuXHRcdC1tcy1hbmltYXRpb24tZGVsYXk6MS41cztcclxuXHRcdC13ZWJraXQtYW5pbWF0aW9uLWRlbGF5OjEuNXM7XHJcblx0XHQtbW96LWFuaW1hdGlvbi1kZWxheToxLjVzO1xyXG5cdHRyYW5zZm9ybTpyb3RhdGUoLTEzNWRlZyk7XHJcblx0XHQtby10cmFuc2Zvcm06cm90YXRlKC0xMzVkZWcpO1xyXG5cdFx0LW1zLXRyYW5zZm9ybTpyb3RhdGUoLTEzNWRlZyk7XHJcblx0XHQtd2Via2l0LXRyYW5zZm9ybTpyb3RhdGUoLTEzNWRlZyk7XHJcblx0XHQtbW96LXRyYW5zZm9ybTpyb3RhdGUoLTEzNWRlZyk7XHJcbn1cclxuXHJcblxyXG5cclxuQGtleWZyYW1lcyBmYWRlR3tcclxuXHQwJXtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6cmdiKDI0NywwLDI0Nyk7XHJcblx0fVxyXG5cclxuXHQxMDAle1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjpyZ2IoMjU1LDI1NSwyNTUpO1xyXG5cdH1cclxufVxyXG5cclxuQC1vLWtleWZyYW1lcyBmYWRlR3tcclxuXHQwJXtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6cmdiKDI0NywwLDI0Nyk7XHJcblx0fVxyXG5cclxuXHQxMDAle1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjpyZ2IoMjU1LDI1NSwyNTUpO1xyXG5cdH1cclxufVxyXG5cclxuQC1tcy1rZXlmcmFtZXMgZmFkZUd7XHJcblx0MCV7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOnJnYigyNDcsMCwyNDcpO1xyXG5cdH1cclxuXHJcblx0MTAwJXtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6cmdiKDI1NSwyNTUsMjU1KTtcclxuXHR9XHJcbn1cclxuXHJcbkAtd2Via2l0LWtleWZyYW1lcyBmYWRlR3tcclxuXHQwJXtcclxuXHRcdGJhY2tncm91bmQtY29sb3I6cmdiKDI0NywwLDI0Nyk7XHJcblx0fVxyXG5cclxuXHQxMDAle1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjpyZ2IoMjU1LDI1NSwyNTUpO1xyXG5cdH1cclxufVxyXG5cclxuQC1tb3ota2V5ZnJhbWVzIGZhZGVHe1xyXG5cdDAle1xyXG5cdFx0YmFja2dyb3VuZC1jb2xvcjpyZ2IoMjQ3LDAsMjQ3KTtcclxuXHR9XHJcblxyXG5cdDEwMCV7XHJcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOnJnYigyNTUsMjU1LDI1NSk7XHJcblx0fVxyXG59Il19 */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<sim-driver></sim-driver>\n\n<app-layout></app-layout>\n<!-- <test-page></test-page> -->\n\n\n<div [hidden]=\"!LoadingSpin\" style=\"position: fixed; z-index: 99999; width: 100%; height: 100%; top: 0; left: 0; background-color: rgba(255,255,255,0.7);\">\n        <div id=\"floatingCirclesG\">\n                <div class=\"f_circleG\" id=\"frotateG_01\"></div>\n                <div class=\"f_circleG\" id=\"frotateG_02\"></div>\n                <div class=\"f_circleG\" id=\"frotateG_03\"></div>\n                <div class=\"f_circleG\" id=\"frotateG_04\"></div>\n                <div class=\"f_circleG\" id=\"frotateG_05\"></div>\n                <div class=\"f_circleG\" id=\"frotateG_06\"></div>\n                <div class=\"f_circleG\" id=\"frotateG_07\"></div>\n                <div class=\"f_circleG\" id=\"frotateG_08\"></div>\n        </div>\n\n</div>\n\n<!-- <h1>test</h1>  -->\n<!-- <app-test></app-test> -->"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _setting_NgbDatePicker__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./setting/NgbDatePicker */ "./src/app/setting/NgbDatePicker.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

//import { Router, RouterEvent, NavigationStart, NavigationCancel, NavigationEnd, NavigationError } from '@angular/router';


// import {
//   Http,
//   ConnectionBackend,
//   RequestOptions,
//   RequestOptionsArgs,
//   Response,
//   Headers,
//   Request
// } from '@angular/http';
// import 'rxjs/Rx';
var AppComponent = /** @class */ (function () {
    function AppComponent(injector) {
        //super(injector);
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")],
            providers: [
                { provide: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__["NgbDateParserFormatter"], useClass: _setting_NgbDatePicker__WEBPACK_IMPORTED_MODULE_2__["NgbDateFRParserFormatter"] },
                { provide: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__["NgbDateAdapter"], useClass: _setting_NgbDatePicker__WEBPACK_IMPORTED_MODULE_2__["NgbDateFRStructAdapter"] }
            ]
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_layout_app_layout_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-layout/app-layout.component */ "./src/app/app-layout/app-layout.component.ts");
/* harmony import */ var _app_layout_LayoutModel__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app-layout/LayoutModel */ "./src/app/app-layout/LayoutModel.ts");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _service_SMQuot_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./service/SMQuot.service */ "./src/app/service/SMQuot.service.ts");
/* harmony import */ var _Models_SmallAppViewModel__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./Models/SmallAppViewModel */ "./src/app/Models/SmallAppViewModel.ts");
/* harmony import */ var _setting_SmallUrl__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./setting/SmallUrl */ "./src/app/setting/SmallUrl.ts");
/* harmony import */ var _smeclient_search_smeclient_search_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./smeclient-search/smeclient-search.component */ "./src/app/smeclient-search/smeclient-search.component.ts");
/* harmony import */ var _service_SmallApp_service__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./service/SmallApp.service */ "./src/app/service/SmallApp.service.ts");
/* harmony import */ var _smeclient_edit_smeclient_edit_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./smeclient-edit/smeclient-edit.component */ "./src/app/smeclient-edit/smeclient-edit.component.ts");
/* harmony import */ var _test_page_test_page_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./test-page/test-page.component */ "./src/app/test-page/test-page.component.ts");
/* harmony import */ var _test_jcompare_test_jcompare_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./test-jcompare/test-jcompare.component */ "./src/app/test-jcompare/test-jcompare.component.ts");
/* harmony import */ var _setting_SmallDIMap__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./setting/SmallDIMap */ "./src/app/setting/SmallDIMap.ts");
/* harmony import */ var _app_ridi_quot_app_ridi_quot_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./app-ridi-quot/app-ridi-quot.component */ "./src/app/app-ridi-quot/app-ridi-quot.component.ts");
/* harmony import */ var _app_ridi_line_app_ridi_line_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./app-ridi-line/app-ridi-line.component */ "./src/app/app-ridi-line/app-ridi-line.component.ts");
/* harmony import */ var _smequot_edit_smequot_edit_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./smequot-edit/smequot-edit.component */ "./src/app/smequot-edit/smequot-edit.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _xtext_box_xtext_box_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./xtext-box/xtext-box.component */ "./src/app/xtext-box/xtext-box.component.ts");
/* harmony import */ var _app_tomangular__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./app-tomangular */ "./src/app/app-tomangular.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};









//import { ViewField} from "TomFism";



















var AppModule = /** @class */ (function (_super) {
    __extends(AppModule, _super);
    function AppModule(injector) {
        var _this = _super.call(this, injector) || this;
        _this.AppData = new _Models_SmallAppViewModel__WEBPACK_IMPORTED_MODULE_11__["SmallAppDataModel"]();
        //AppGlobal.isAjaxLogging = true;
        //console.log ( this.router);
        //AppGlobal.AjaxLogReader.initRead("09281928");
        //AppGlobal.isReplaying = true;
        //AppGlobal.setting = new smallAppSetting (injector);
        TomFism__WEBPACK_IMPORTED_MODULE_9__["AppGlobal"].url = new _setting_SmallUrl__WEBPACK_IMPORTED_MODULE_12__["SmallUrl"]();
        var firstParam = { DataModel: function () { return _this.AppData; } };
        // console.log ("first Param");
        // console.log ( firstParam);
        TomFism__WEBPACK_IMPORTED_MODULE_9__["AppGlobal"].appViewModel = TomFism__WEBPACK_IMPORTED_MODULE_9__["tomjector"].create(_Models_SmallAppViewModel__WEBPACK_IMPORTED_MODULE_11__["SmallAppViewModel"].name, firstParam, { params: [] });
        //console.log ( AppGlobal.appViewModel);
        //SmallAppViewModel.build( { DataModel : () =>  this.AppData}, []);
        TomFism__WEBPACK_IMPORTED_MODULE_9__["AppGlobal"].appViewModel.init();
        TomFism__WEBPACK_IMPORTED_MODULE_9__["AppGlobal"].appViewModel.furnish();
        //console.log ( AppGlobal.appViewModel);
        TomFism__WEBPACK_IMPORTED_MODULE_9__["AppGlobal"].appViewModel.cmdRouter = TomFism__WEBPACK_IMPORTED_MODULE_9__["AppGlobal"].setting.cmdRouter;
        TomFism__WEBPACK_IMPORTED_MODULE_9__["AppGlobal"].appMode = TomFism__WEBPACK_IMPORTED_MODULE_9__["AppMode"].debug;
        injector.get(_service_SmallApp_service__WEBPACK_IMPORTED_MODULE_14__["smallAppService"]).getInitInfo();
        return _this;
        // console.log ( "testing x---------------");
        // console.log ( AppGlobal.appViewModel.dataModel)
        // let x = CloneTraversorInArg.clone( AppGlobal.appViewModel.dataModel, outArg => outArg.nodeKey == "shadowSeq")
        // console.log (x);
        //AppGlobal.checkPointMode = CheckPointMode.CheckPointLogging;
        //AppGlobal.checkPointMode = CheckPointMode.CheckPointCompare;
        //AppGlobal.checkPointReader.initRead("10261625");
        //let service = new InitNewQuotService(  (result) => AppGlobal.appViewModel.SimVM.simStartPlayFullContent("10031032")) ;
        //  let service = new InitNewQuotService();
        //  service.runService();
        //  let ridiService = new NewRidiQuotService();
        //  ridiService.runService();
        //console.log ( AppGlobal.appViewModel.ActiveVM);
        //this.init(injector, quotService , translator, RestfulSetting );
    }
    //protected router : Router;
    AppModule.prototype.setupDIMap = function () {
        _super.prototype.setupDIMap.call(this);
        _setting_SmallDIMap__WEBPACK_IMPORTED_MODULE_18__["SmallDIMap"].overwriteDI();
    };
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                //  AngularDateTimePickerModule, 
                _app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"],
                _smequot_edit_smequot_edit_component__WEBPACK_IMPORTED_MODULE_21__["smallQuotEditComponent"],
                _smeclient_search_smeclient_search_component__WEBPACK_IMPORTED_MODULE_13__["smallClientSearchComponent"],
                //TomViewSortDirective,
                _smeclient_edit_smeclient_edit_component__WEBPACK_IMPORTED_MODULE_15__["smallClientEditComponent"],
                _app_layout_app_layout_component__WEBPACK_IMPORTED_MODULE_7__["AppLayoutComponent"],
                _test_page_test_page_component__WEBPACK_IMPORTED_MODULE_16__["TestPageComponent"],
                _test_jcompare_test_jcompare_component__WEBPACK_IMPORTED_MODULE_17__["TestJCompareComponent"],
                _app_ridi_quot_app_ridi_quot_component__WEBPACK_IMPORTED_MODULE_19__["AppRidiQuotComponent"],
                _app_ridi_line_app_ridi_line_component__WEBPACK_IMPORTED_MODULE_20__["AppRidiLineComponent"],
                _xtext_box_xtext_box_component__WEBPACK_IMPORTED_MODULE_23__["XTextBoxComponent"],
            ],
            imports: [
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
                // ReactiveFormsModule,
                _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
                //RouterModule.forRoot(routes),
                _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_0__["NgbModule"].forRoot(),
                //RouterModule.forRoot( routes, { useHash: true }),
                //epLibModule,
                //TomModule,
                _app_tomangular__WEBPACK_IMPORTED_MODULE_24__["AppTomangularModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_22__["AppRoutingModule"],
            ],
            //schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
            providers: [_angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"],
                _app_layout_LayoutModel__WEBPACK_IMPORTED_MODULE_8__["LayoutModel"],
                _service_SMQuot_service__WEBPACK_IMPORTED_MODULE_10__["smallQuotService"],
                _service_SmallApp_service__WEBPACK_IMPORTED_MODULE_14__["smallAppService"],
                TomFism__WEBPACK_IMPORTED_MODULE_9__["TAjaxCaller"],
                {
                    provide: "Tajax",
                    useFactory: function () { return function () { return new TomFism__WEBPACK_IMPORTED_MODULE_9__["Tajax"](); }; },
                },
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"]]
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injector"]])
    ], AppModule);
    return AppModule;
}(TomFism__WEBPACK_IMPORTED_MODULE_9__["tomfismApp"]));



/***/ }),

/***/ "./src/app/service/SMQuot.service.ts":
/*!*******************************************!*\
  !*** ./src/app/service/SMQuot.service.ts ***!
  \*******************************************/
/*! exports provided: smallQuotService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallQuotService", function() { return smallQuotService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _Models_SmallQuot_ViewModel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Models/SmallQuot.ViewModel */ "./src/app/Models/SmallQuot.ViewModel.ts");
/* harmony import */ var _Models_SmallQuot_DataModel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Models/SmallQuot.DataModel */ "./src/app/Models/SmallQuot.DataModel.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




var smallQuotService = /** @class */ (function () {
    function smallQuotService() {
    }
    // createQuot (handler : (vm : ViewModel) => void){
    //     let QuotData : smallQuotDataModel = new smallQuotDataModel();
    //     QuotData.clientname = "tom"
    //     let QuotVM  : smallQuotViewModel = new smallQuotViewModel();
    //     QuotVM.dataModel = QuotData;
    //     QuotVM.parentViewModel = AppGlobal.appViewModel;
    //     AppGlobal.appViewModel.appendPageRootModel( QuotVM)
    //     QuotVM.init();
    //     QuotVM.furnish();
    //     handler( QuotVM);
    // }
    smallQuotService.prototype.test_QuotEdit = function (handler) {
        var CallItems = [
            TomFism__WEBPACK_IMPORTED_MODULE_1__["CallItem"].buildCallItem("QuotEdit", function () { return TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].url.QuotEdit; }, null),
            TomFism__WEBPACK_IMPORTED_MODULE_1__["CallItem"].buildCallItem("ClientList", function () { return TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].url.AllClient; }, null),
            TomFism__WEBPACK_IMPORTED_MODULE_1__["CallItem"].buildCallItem("Codes_BusinessType", function () { return TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].url.getCodeListByCodeType("smallProduct"); }, null),
            TomFism__WEBPACK_IMPORTED_MODULE_1__["CallItem"].buildCallItem("Codes_City", function () { return TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].url.getCodeListByCodeType("City"); }, null)
        ];
        TomFism__WEBPACK_IMPORTED_MODULE_1__["TAjaxCaller"].BatchCall("test_QuotEdit", CallItems, function (RawContainer) {
            console.log(RawContainer);
            var QuotEdit = _Models_SmallQuot_DataModel__WEBPACK_IMPORTED_MODULE_3__["smallQuotDataModel"].deserialize(RawContainer.QuotEdit);
            QuotEdit.producer1 = TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel.dataModel.loginUser.userid;
            var ClientList = RawContainer.ClientList.map(function (c) { return _Models_SmallQuot_DataModel__WEBPACK_IMPORTED_MODULE_3__["smallClientDataModel"].deserialize(c); });
            var Codes_BusinessType = TomFism__WEBPACK_IMPORTED_MODULE_1__["KeyValueItem"].buildKeyValueFromCodeTableList(RawContainer.Codes_BusinessType.map(function (epCode) { return ({ Code: epCode.codevalue, Description: epCode.codedesc }); }));
            var Codes_City = TomFism__WEBPACK_IMPORTED_MODULE_1__["KeyValueItem"].buildKeyValueFromCodeTableList(RawContainer.Codes_City.map(function (epCode) { return ({ Code: epCode.codevalue, Description: epCode.codedesc }); }));
            var dataContainer = new _Models_SmallQuot_DataModel__WEBPACK_IMPORTED_MODULE_3__["SmallQuotDataContainer"]();
            dataContainer.smallQuotModel = QuotEdit;
            dataContainer.Codes_BusinessType = Codes_BusinessType;
            dataContainer.Codes_City = Codes_City;
            //dataContainer.ClientList = ClientList;
            // console.log ("container");
            // console.log ( dataContainer);
            var QuotVM = new _Models_SmallQuot_ViewModel__WEBPACK_IMPORTED_MODULE_2__["smallQuotViewModel"]({
                DataModel: function () { return dataContainer; },
            });
            QuotVM.parentViewModel = TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel;
            //AppGlobal.appViewModel.subModels.push ( QuotVM);
            TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel.appendPageRootModel(QuotVM);
            QuotVM.init();
            QuotVM.furnish();
            //console.log ( QuotVM)  ;
            handler(QuotVM);
            setTimeout(function () {
                QuotVM.traverseNodes(function (k, vf) {
                    // if ( !NullorEmpty( vf.assignValidators ) )
                    //   vf.assignValidators();
                    // if ( !NullorEmpty(vf.enable))
                    //   vf.enable();
                    // if ( !NullorEmpty(vf.markClean))
                    //   vf.markClean();
                    if (!Object(TomFism__WEBPACK_IMPORTED_MODULE_1__["NullorEmpty"])(vf.VirtualFieldComponent)) {
                        //console.log ("startComponentValidation")
                        vf.startComponentValidation();
                    }
                });
            }, 500);
            //console.log ( QuotVM.dataModel );          
        });
    };
    smallQuotService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])()
    ], smallQuotService);
    return smallQuotService;
}());



/***/ }),

/***/ "./src/app/service/SmallApp.service.ts":
/*!*********************************************!*\
  !*** ./src/app/service/SmallApp.service.ts ***!
  \*********************************************/
/*! exports provided: smallAppService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallAppService", function() { return smallAppService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _setting_SmallConfig__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../setting/SmallConfig */ "./src/app/setting/SmallConfig.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var smallAppService = /** @class */ (function () {
    function smallAppService() {
        this.ServiceName = "smallAppService";
    }
    smallAppService.prototype.getInitInfo = function () {
        var CallItems = [
            TomFism__WEBPACK_IMPORTED_MODULE_1__["CallItem"].buildCallItem("config", function () { return TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].url.config; }, null),
        ];
        TomFism__WEBPACK_IMPORTED_MODULE_1__["TAjaxCaller"].BatchCall(this.ServiceName, CallItems, function (RawContainer) {
            //  console.log ( RawContainer);
            //  (<SmallAppViewModel>AppGlobal.appViewModel).dataModel.loginUser = RawContainer.LoginUser;
            //  console.log ( AppGlobal.appViewModel.dataModel);
            var serilizer = new TomFism__WEBPACK_IMPORTED_MODULE_1__["tomDeserializer"]();
            var config = serilizer.deserialize(_setting_SmallConfig__WEBPACK_IMPORTED_MODULE_2__["SmallConfig"], RawContainer.config);
            TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].setting.config = config;
            //console.log ( AppGlobal.setting);
        });
    };
    smallAppService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])()
    ], smallAppService);
    return smallAppService;
}());



/***/ }),

/***/ "./src/app/setting/NgbDatePicker.ts":
/*!******************************************!*\
  !*** ./src/app/setting/NgbDatePicker.ts ***!
  \******************************************/
/*! exports provided: ngToDate, NgbDateFRParserFormatter, NgbDateFRStructAdapter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ngToDate", function() { return ngToDate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgbDateFRParserFormatter", function() { return NgbDateFRParserFormatter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NgbDateFRStructAdapter", function() { return NgbDateFRStructAdapter; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "./node_modules/@ng-bootstrap/ng-bootstrap/fesm5/ng-bootstrap.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


function padNumber(value, length) {
    if (length === void 0) { length = 2; }
    if (isNumber(value)) {
        return ("0" + value).slice(-length);
    }
    else {
        return "";
    }
}
function isNumber(value) {
    return !isNaN(toInteger(value));
}
function toInteger(value) {
    return parseInt("" + value, 10);
}
function ngToDate(value) {
    if (value) {
        var dateParts = value.trim().split('/');
        if (dateParts.length === 1 && isNumber(dateParts[0])) {
            return { year: toInteger(dateParts[0]), month: null, day: null };
        }
        else if (dateParts.length === 2 && isNumber(dateParts[0]) && isNumber(dateParts[1])) {
            return { year: toInteger(dateParts[1]), month: toInteger(dateParts[0]), day: null };
        }
        else if (dateParts.length === 3 && isNumber(dateParts[0]) && isNumber(dateParts[1]) && isNumber(dateParts[2])) {
            return { year: toInteger(dateParts[2]), month: toInteger(dateParts[1]), day: toInteger(dateParts[0]) };
        }
    }
    return null;
}
function ngToString(date) {
    var stringDate = "";
    if (date) {
        stringDate += isNumber(date.day) ? padNumber(date.day) + "/" : "";
        stringDate += isNumber(date.month) ? padNumber(date.month) + "/" : "";
        stringDate += date.year;
        // let year = isNumber(date.year) ? padNumber(date.year) : "";
        // let month = isNumber(date.month) ? padNumber(date.month) : "";
        // let day = isNumber(date.day) ? padNumber(date.day) : "";
        // stringDate += year + "-" + month + "-" +  day;
    }
    return stringDate;
}
var NgbDateFRParserFormatter = /** @class */ (function (_super) {
    __extends(NgbDateFRParserFormatter, _super);
    function NgbDateFRParserFormatter() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    NgbDateFRParserFormatter.prototype.parse = function (value) {
        return ngToDate(value);
    };
    NgbDateFRParserFormatter.prototype.format = function (date) {
        return ngToString(date);
        // let stringDate: string = ""; 
        // if(date) {
        //     // stringDate += isNumber(date.day) ? padNumber(date.day) + "/" : "";
        //     // stringDate += isNumber(date.month) ? padNumber(date.month) + "/" : "";
        //     // stringDate += date.year;
        //     //let year = isNumber(date.year) ? padNumber(date.year) : "";
        //     let month = isNumber(date.month) ? padNumber(date.month) : "";
        //     let day = isNumber(date.day) ? padNumber(date.day) : "";
        //     stringDate += date.year + "-" + month + "-" +  day;
        // }
        // return stringDate;
    };
    NgbDateFRParserFormatter = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])()
    ], NgbDateFRParserFormatter);
    return NgbDateFRParserFormatter;
}(_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__["NgbDateParserFormatter"]));

var NgbDateFRStructAdapter = /** @class */ (function (_super) {
    __extends(NgbDateFRStructAdapter, _super);
    function NgbDateFRStructAdapter() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    NgbDateFRStructAdapter.prototype.fromModel = function (value) {
        //console.log (date);
        // var d = ngToDate(date);
        // //console.log (d);
        // return d;
        if (value) {
            var dateParts = value.trim().split('-');
            if (dateParts.length === 1 && isNumber(dateParts[0])) {
                return { year: toInteger(dateParts[0]), month: null, day: null };
            }
            else if (dateParts.length === 2 && isNumber(dateParts[0]) && isNumber(dateParts[1])) {
                return { year: toInteger(dateParts[0]), month: toInteger(dateParts[1]), day: null };
            }
            else if (dateParts.length === 3 && isNumber(dateParts[0]) && isNumber(dateParts[1]) && isNumber(dateParts[2])) {
                return { year: toInteger(dateParts[0]), month: toInteger(dateParts[1]), day: toInteger(dateParts[2]) };
            }
        }
        return null;
    };
    NgbDateFRStructAdapter.prototype.toModel = function (date) {
        //return ngToString(date);
        var stringDate = "";
        if (date) {
            // stringDate += isNumber(date.day) ? padNumber(date.day) + "/" : "";
            // stringDate += isNumber(date.month) ? padNumber(date.month) + "/" : "";
            // stringDate += date.year;
            var year = date.year; //  isNumber(date.year) ? padNumber(date.year) : "";
            var month = isNumber(date.month) ? padNumber(date.month) : "";
            var day = isNumber(date.day) ? padNumber(date.day) : "";
            stringDate += year + "-" + month + "-" + day;
        }
        return stringDate;
    };
    NgbDateFRStructAdapter = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])()
    ], NgbDateFRStructAdapter);
    return NgbDateFRStructAdapter;
}(_ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_1__["NgbDateAdapter"]));



/***/ }),

/***/ "./src/app/setting/SmallConfig.ts":
/*!****************************************!*\
  !*** ./src/app/setting/SmallConfig.ts ***!
  \****************************************/
/*! exports provided: SmallConfig */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SmallConfig", function() { return SmallConfig; });
var SmallConfig = /** @class */ (function () {
    function SmallConfig() {
        this.NameRegex = null;
        this.AddressRegex = null;
        this.EmailRegex = null;
    }
    return SmallConfig;
}());



/***/ }),

/***/ "./src/app/setting/SmallDIMap.ts":
/*!***************************************!*\
  !*** ./src/app/setting/SmallDIMap.ts ***!
  \***************************************/
/*! exports provided: SmallDIMap */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SmallDIMap", function() { return SmallDIMap; });
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _Models_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Models/RidiQuotDataModel */ "./src/app/Models/RidiQuotDataModel.ts");
/* harmony import */ var _SmallSetting__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./SmallSetting */ "./src/app/setting/SmallSetting.ts");
/* harmony import */ var _Models_SmallAppViewModel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Models/SmallAppViewModel */ "./src/app/Models/SmallAppViewModel.ts");
/* harmony import */ var _Models_RidiQuotDataOverrideModels__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Models/RidiQuotDataOverrideModels */ "./src/app/Models/RidiQuotDataOverrideModels.ts");







var SmallDIMap = /** @class */ (function () {
    function SmallDIMap() {
    }
    SmallDIMap.overwriteDI = function () {
        var jectorSetting = new TomFism__WEBPACK_IMPORTED_MODULE_0__["tomjectorSetting"](_Models_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiQuotContainer"].name, function (paramContainer) { return new _Models_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiQuotContainer"](); });
        TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].DIMap[jectorSetting.id] = jectorSetting;
        // console.log ( "App setting")
        // console.log ( AppSetting.name);
        jectorSetting = new TomFism__WEBPACK_IMPORTED_MODULE_0__["tomjectorSetting"](TomFism__WEBPACK_IMPORTED_MODULE_0__["AppSetting"].name, function (paramContainer) { return new _SmallSetting__WEBPACK_IMPORTED_MODULE_2__["smallAppSetting"](TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].injector); });
        TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].DIMap[jectorSetting.id] = jectorSetting;
        jectorSetting = new TomFism__WEBPACK_IMPORTED_MODULE_0__["tomjectorSetting"](_Models_SmallAppViewModel__WEBPACK_IMPORTED_MODULE_3__["SmallAppViewModel"].name, function (paramContainer) {
            //console.log( paramContainer);
            var p = _Models_SmallAppViewModel__WEBPACK_IMPORTED_MODULE_3__["SmallAppViewModel"].build(paramContainer.firstParam, paramContainer.paramInfo.params[0]);
            return p;
        });
        TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].DIMap[jectorSetting.id] = jectorSetting;
        jectorSetting = new TomFism__WEBPACK_IMPORTED_MODULE_0__["tomjectorSetting"](_Models_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiLine"].name, 
        //!!!!!! DI overriding
        // (paramContainer) => new RidiLine ( )
        function (paramContainer) { return new _Models_RidiQuotDataOverrideModels__WEBPACK_IMPORTED_MODULE_4__["OverrideRidiLine"](); });
        TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].DIMap[jectorSetting.id] = jectorSetting;
        jectorSetting = new TomFism__WEBPACK_IMPORTED_MODULE_0__["tomjectorSetting"](_Models_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiQuot"].name, function (paramContainer) { return new _Models_RidiQuotDataModel__WEBPACK_IMPORTED_MODULE_1__["RidiQuot"](); });
        TomFism__WEBPACK_IMPORTED_MODULE_0__["AppGlobal"].DIMap[jectorSetting.id] = jectorSetting;
    };
    return SmallDIMap;
}());



/***/ }),

/***/ "./src/app/setting/SmallSetting.ts":
/*!*****************************************!*\
  !*** ./src/app/setting/SmallSetting.ts ***!
  \*****************************************/
/*! exports provided: smallAppSetting */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallAppSetting", function() { return smallAppSetting; });
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var smallAppSetting = /** @class */ (function (_super) {
    __extends(smallAppSetting, _super);
    //readonly RegexName : string = "^(?!.*\s{2,}.*)(?!.*(.)\1{3,}.*)(?!.*[^a-zA-Z0-9][\-',].*)(?!.*[\-'][^a-zA-Z0-9].*)(?!.*[,][^\s].*)[a-zA-Z0-9 \-',/()&#%]+$"
    //readonly RegexEmail : string
    function smallAppSetting(injector) {
        var _this = _super.call(this, injector) || this;
        _this.PostHeader = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]({ 'Content-Type': 'application/json; charset=utf-8', "userid": "abcd" });
        _this.GetHeader = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]({ 'Content-Type': 'application/json; charset=utf-8', "userid": "abcd" });
        _this.UploadHeader = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]({ "userid": "abcd" });
        // should be configurable by server json
        _this.config = null;
        return _this;
    }
    return smallAppSetting;
}(TomFism__WEBPACK_IMPORTED_MODULE_1__["AppSetting"]));



/***/ }),

/***/ "./src/app/setting/SmallUrl.ts":
/*!*************************************!*\
  !*** ./src/app/setting/SmallUrl.ts ***!
  \*************************************/
/*! exports provided: SmallUrl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SmallUrl", function() { return SmallUrl; });
var SmallUrl = /** @class */ (function () {
    function SmallUrl() {
        //  private host: string = "http://localhost:4200/assets/MockWS/";
        //  private jsonHost : string = "http://localhost:4200/assets/MockWS/";
        this.host = "http://localhost/aeotest1/assets/MockWS/";
        this.jsonHost = "http://localhost/aeotest1/assets/MockWS/";
        this.suffix = ".json";
    }
    Object.defineProperty(SmallUrl.prototype, "config", {
        //suffix = "";
        get: function () {
            return this.jsonHost + "small/config.json";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SmallUrl.prototype, "QuotEdit", {
        get: function () {
            return this.jsonHost + "small/QuotEdit.json";
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SmallUrl.prototype, "AllClient", {
        get: function () {
            //return  this.host + "ClientList.json";
            //return `http://10.11.9.153:8080/eprecious-ws/" + "Clients/getAll`;
            //return "http://10.11.9.153:8080/eprecious-ws/Clients/getAll";
            return this.host + "Clients/getAll" + this.suffix;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SmallUrl.prototype, "newQuotation", {
        get: function () {
            //return "http://10.11.9.153:8080/eprecious-ws/QuotationRegistration/newQuotation";
            return this.host + "QuotationRegistration/newQuotation" + this.suffix;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SmallUrl.prototype, "newClient", {
        get: function () {
            //return "http://10.11.9.153:8080/eprecious-ws/Clients/newClient";
            return this.host + "Clients/newClient" + this.suffix;
            //return "http://10.10.17.20:8082/eprecious-ws-ph/Clients/newClient";
        },
        enumerable: true,
        configurable: true
    });
    SmallUrl.prototype.getCodeListByCodeType = function (codeType) {
        //return `http://10.11.9.153:8080/eprecious-ws/CodeList/getCodeListByCodeType/${codeType}`
        return this.host + ("CodeList/getCodeListByCodeType/" + codeType) + this.suffix;
    };
    Object.defineProperty(SmallUrl.prototype, "newRidiQuot", {
        get: function () {
            return this.host + "RidiQuot/NewRidiQuot" + this.suffix;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SmallUrl.prototype, "RidiQuotItem", {
        get: function () {
            return this.host + "RidiQuot/items" + this.suffix;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SmallUrl.prototype, "newRidiLine", {
        get: function () {
            return this.host + "RidiQuot/NewRidiLine" + this.suffix;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SmallUrl.prototype, "visibilitySetting", {
        get: function () {
            return this.host + "dressing/visibility" + this.suffix;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(SmallUrl.prototype, "editabilitySetting", {
        get: function () {
            return this.host + "dressing/editability" + this.suffix;
        },
        enumerable: true,
        configurable: true
    });
    return SmallUrl;
}());



/***/ }),

/***/ "./src/app/smeclient-edit/smeclient-edit.component.css":
/*!*************************************************************!*\
  !*** ./src/app/smeclient-edit/smeclient-edit.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NtZWNsaWVudC1lZGl0L3NtZWNsaWVudC1lZGl0LmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/smeclient-edit/smeclient-edit.component.html":
/*!**************************************************************!*\
  !*** ./src/app/smeclient-edit/smeclient-edit.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"content\" *ngIf=\"IsReady\" >\n\n  <tom-debugger [viewModel]=\"viewModel\"></tom-debugger>\n  <div class=\"panel panel-default\">\n    <div class=\"panel-body\">\n      <div class=\"row\">\n        <div class=\"form-group col-xs-6\">\n          <tom-input-box label=\"Company Name\" [viewField]=viewModel.clientname></tom-input-box>\n        </div>\n      </div>\n\n      <div class=\"row\">\n\n        <div class=\"form-group col-xs-6\" class=\"input-box-min-spacing\">\n          <label>Address</label>\n          <tom-input-box [viewField]=\"viewModel.address1\" ></tom-input-box>\n          <tom-input-box [viewField]=\"viewModel.address2\" ></tom-input-box>\n          <tom-input-box [viewField]=\"viewModel.address3\" ></tom-input-box>\n          <tom-input-box [viewField]=\"viewModel.address4\" ></tom-input-box>\n\n        </div>\n        <div class=\"form-group col-xs-6\">\n          <div class=\"form-group\">\n            <tom-select label=\"City\" [viewField]=\"viewModel.citycode\"></tom-select>\n            <tom-input-box label=\"Postal Code\" [viewField]=\"viewModel.postalcode\" ></tom-input-box>\n            <tom-input-box label=\"Telephone *\" [viewField]=\"viewModel.telephone\" ></tom-input-box>\n            <tom-input-box label=\"Fax\" [viewField]=\"viewModel.fax\" ></tom-input-box>\n            <tom-input-box label=\"Person in Charge *\" [viewField]=\"viewModel.personincharge\" ></tom-input-box>\n            <tom-input-box label=\"Position\" [viewField]=\"viewModel.position\" ></tom-input-box>\n            <tom-input-box label=\"Email Address*\" [viewField]=\"viewModel.email\" ></tom-input-box>\n\n          </div>\n        </div>\n\n      </div>\n\n      <div class=\"row\">\n\n        <div class=\"form-group col-xs-6 th-row text-right\">\n          <tom-button label=\"Save\" [viewField]=\"viewModel.SaveClient\"></tom-button>\n        </div>\n      </div>\n      \n\n    </div>\n  </div>\n\n</section>"

/***/ }),

/***/ "./src/app/smeclient-edit/smeclient-edit.component.ts":
/*!************************************************************!*\
  !*** ./src/app/smeclient-edit/smeclient-edit.component.ts ***!
  \************************************************************/
/*! exports provided: smallClientEditComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallClientEditComponent", function() { return smallClientEditComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _service_SMQuot_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/SMQuot.service */ "./src/app/service/SMQuot.service.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var smallClientEditComponent = /** @class */ (function (_super) {
    __extends(smallClientEditComponent, _super);
    function smallClientEditComponent(injector) {
        var _this = _super.call(this, injector) || this;
        _this.service = _this.injector.get(_service_SMQuot_service__WEBPACK_IMPORTED_MODULE_2__["smallQuotService"]);
        return _this;
    }
    Object.defineProperty(smallClientEditComponent.prototype, "IsReady", {
        get: function () {
            return (this.viewModel != null && !Object(TomFism__WEBPACK_IMPORTED_MODULE_1__["NullorEmpty"])(this.viewModel.dataModel));
        },
        enumerable: true,
        configurable: true
    });
    smallClientEditComponent.prototype.ngOnInit = function () {
        //console.log ( this.viewModel);
    };
    smallClientEditComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'smeclient-edit',
            template: __webpack_require__(/*! ./smeclient-edit.component.html */ "./src/app/smeclient-edit/smeclient-edit.component.html"),
            styles: [__webpack_require__(/*! ./smeclient-edit.component.css */ "./src/app/smeclient-edit/smeclient-edit.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"]])
    ], smallClientEditComponent);
    return smallClientEditComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_1__["ComplexComponentBase"]));



/***/ }),

/***/ "./src/app/smeclient-search/smeclient-search.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/smeclient-search/smeclient-search.component.css ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NtZWNsaWVudC1zZWFyY2gvc21lY2xpZW50LXNlYXJjaC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/smeclient-search/smeclient-search.component.html":
/*!******************************************************************!*\
  !*** ./src/app/smeclient-search/smeclient-search.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div *ngIf = \"IsReady\">\n\n  <tom-debugger [viewModel]=\"viewModel\"></tom-debugger>\n\n  <!-- <a class=\"btn input-sm btn-warning pull-right\" style=\"color: #fff; margin-right: 0; margin-top: 6px;\" my_access=\"ClientsNew\"  href=\"#/createClient\" translate=\"main.Client.NEW\"></a> -->\n  \n  <div class=\"pull-right\">\n    <tom-button label=\"Search\" [viewField]=\"viewModel.SearchClient\"   ></tom-button>\n    <tom-button label=\"New Client\" [viewField]=\"viewModel.CreateClient\"   ></tom-button>\n  </div>\n\n  <br/>\n  <br/>\n  \n  <tom-view-table [SourceList]=\"viewModel.ViewModelList\" #container >\n    <thead>\n    <tr class=\"columnHeaderRow\">\n      <th st-ratio=\"14.29\" tom-sort=\"clientname\" >Name</th>\n      <th st-ratio=\"14.29\" tom-sort=\"address1\"  >Address</th>\n      <th st-ratio=\"14.29\" tom-sort=\"personincharge\"  >Person in Charge</th>\n      <th st-ratio=\"14.29\" tom-sort=\"telephone\" >Contact </th>\n      <th st-ratio=\"14.29\" tom-sort=\"email\" >Email </th>\n      \n    </tr>\n    </thead>\n    <tbody>\n    <tr *ngFor=\"let row of container.DisplaySource\"  [tom-clickable]=\"row.PickForQuot\" > \n      <!-- <td ><a routerLink=\"/viewQuotationVersion/{{row.quotationno}}\"> {{row.quotationno}} </a></td> -->\n            \n      <td> \n        <tom-text class=\"tom-fake-link\" [viewField]=\"row.clientname\" ></tom-text>\n     </td>\n      <td> \n        <tom-text [viewField]=\"row.address1\" ></tom-text>\n      </td>\n      <td> \n        <tom-text [viewField]=\"row.personincharge\" ></tom-text>\n      </td>\n      <td> \n        <tom-text [viewField]=\"row.telephone\" ></tom-text>\n      </td>\n      <td> \n          <tom-text [viewField]=\"row.email\" style=\"word-break: break-all;\" ></tom-text>\n      </td>\n\n      \n\n    </tr>\n    </tbody>\n  \n    <tfoot >\n        <tr>\n          <td colspan=\"7\" class=\"pagination-cell\">\n            <div>\n                <tom-view-paginator></tom-view-paginator>\n              </div>\n          </td>\n        </tr>\n      </tfoot>    \n  </tom-view-table>\n\n</div>"

/***/ }),

/***/ "./src/app/smeclient-search/smeclient-search.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/smeclient-search/smeclient-search.component.ts ***!
  \****************************************************************/
/*! exports provided: smallClientSearchComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallClientSearchComponent", function() { return smallClientSearchComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _service_SMQuot_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../service/SMQuot.service */ "./src/app/service/SMQuot.service.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var smallClientSearchComponent = /** @class */ (function (_super) {
    __extends(smallClientSearchComponent, _super);
    function smallClientSearchComponent(injector) {
        var _this = _super.call(this, injector) || this;
        _this.service = _this.injector.get(_service_SMQuot_service__WEBPACK_IMPORTED_MODULE_2__["smallQuotService"]);
        _this.IsReady = true;
        return _this;
    }
    smallClientSearchComponent.prototype.ngOnInit = function () {
        // this.service.test_QuotEdit(
        //   (vm : smallQuotViewModel) => 
        //   {
        //     this.viewModel = vm.ClientList;
        //     //console.log ( this.viewModel);
        //     this.IsReady = true;
        //   }
        // )
    };
    smallClientSearchComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'smeclient-search',
            template: __webpack_require__(/*! ./smeclient-search.component.html */ "./src/app/smeclient-search/smeclient-search.component.html"),
            styles: [__webpack_require__(/*! ./smeclient-search.component.css */ "./src/app/smeclient-search/smeclient-search.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"]])
    ], smallClientSearchComponent);
    return smallClientSearchComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_1__["ComplexComponentBase"]));



/***/ }),

/***/ "./src/app/smequot-edit/smequot-edit.component.css":
/*!*********************************************************!*\
  !*** ./src/app/smequot-edit/smequot-edit.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NtZXF1b3QtZWRpdC9zbWVxdW90LWVkaXQuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/smequot-edit/smequot-edit.component.html":
/*!**********************************************************!*\
  !*** ./src/app/smequot-edit/smequot-edit.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"content\" *ngIf=\"IsReady\">\n  <tom-debugger [viewModel]=\"viewModel\"></tom-debugger>\n\n  <tom-popup [viewModel]=\"viewModel.clientPopupModel\" PopupTitle=\"Select Client\">\n    <smeclient-search [viewModel]=\"viewModel.ClientList\"></smeclient-search>\n  </tom-popup>\n\n  <tom-popup  [viewModel]=\"viewModel.CreatingClientPopupModel\" PopupTitle=\"Create Client\" class=\"creating-client-popup\">\n    <smeclient-edit [viewModel]=\"viewModel.CreatingClientModel\"></smeclient-edit>\n  </tom-popup>\n  \n \n\n  <div class=\"container\">\n\n    <div style=\"color:red \"  >\n          <h4>{{viewModel.DisplayMsg}} </h4>\n          <tom-msg-list *ngIf=\"!viewModel.valid\" [MsgList]=\"viewModel.ErrMsgs\"></tom-msg-list>\n    </div>\n      \n\n    <div class=\"panel panel-default\">\n      <div class=\"panel-body\">\n\n\n        <!-- Quot No. & BizType-->\n        <div class=\"row\">\n\n          <div class=\"form-group col-xs-6\">\n            <tom-button-input label=\"Client\" [viewField]=viewModel.clientname></tom-button-input>\n          </div>\n          <div class=\"form-group col-xs-6\">\n            <tom-select label=\"Order Type\" [viewField]=viewModel.BusinessType></tom-select>\n          </div>\n\n        </div>\n\n        <div class=\"row\">\n          <div class=\"form-group col-xs-6\">\n            <tom-date-box label=\"Transaction Date *\" [viewField]=\"viewModel.Commdate\"></tom-date-box>\n          </div>\n\n          <div class=\"form-group col-xs-6\">\n            <tom-text-box label=\"Sales\" [viewField]=\"viewModel.Producer\"></tom-text-box>\n          </div>\n\n        </div>\n\n      </div>\n\n      <div class=\"row\">\n        <div class=\"form-group col-xs-6\">\n        </div>\n\n        <div class=\"form-group col-xs-6 th-row text-right\">\n          <tom-button label=\"Save\" [viewField]=\"viewModel.saveQuot\"></tom-button>\n        </div>\n      </div>\n    </div>\n\n\n  </div>\n</section>"

/***/ }),

/***/ "./src/app/smequot-edit/smequot-edit.component.ts":
/*!********************************************************!*\
  !*** ./src/app/smequot-edit/smequot-edit.component.ts ***!
  \********************************************************/
/*! exports provided: smallQuotEditComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "smallQuotEditComponent", function() { return smallQuotEditComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _CommandService_SMQuot_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../CommandService/SMQuot.service */ "./src/app/CommandService/SMQuot.service.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var smallQuotEditComponent = /** @class */ (function (_super) {
    __extends(smallQuotEditComponent, _super);
    function smallQuotEditComponent(injector) {
        var _this = _super.call(this, injector) || this;
        var service = new _CommandService_SMQuot_service__WEBPACK_IMPORTED_MODULE_2__["InitNewQuotService"](function (result) {
            TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel.getActiveVM = function () { return TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel.vmQuot; };
            console.log("activeVM");
            console.log(TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel.getActiveVM());
        });
        service.runService();
        return _this;
        // AppGlobal.appViewModel.cmdRouter.callInitServiceCmd( 
        //   RoutableInitCmd.build(
        //      smallServices.smallQuotCmdService, 
        //      smallQuotInitCmds.initNewQuot,
        //      null, 
        //     (vm : ViewModel)=>{
        //     } 
        //    )
        // );
    }
    Object.defineProperty(smallQuotEditComponent.prototype, "IsReady", {
        //service : smallQuotService =  new smallQuotService();  //this.injector.get (smallQuotService);
        get: function () {
            return (!Object(TomFism__WEBPACK_IMPORTED_MODULE_1__["NullorEmpty"])(this.viewModel));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(smallQuotEditComponent.prototype, "viewModel", {
        get: function () {
            return TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel.vmQuot;
        },
        enumerable: true,
        configurable: true
    });
    smallQuotEditComponent.prototype.ngOnInit = function () {
        // AppGlobal.appViewModel.cmdRouter.callInitServiceCmd( 
        //   RoutableInitCmd.build(
        //      smallServices.smallQuotCmdService, 
        //      smallQuotInitCmds.initNewQuot,
        //      null, 
        //     (vm : ViewModel)=>{
        //       this.viewModel = vm;
        //       this.IsReady = true;
        //     } 
        //    )
        // );
        // (vm) => 
        // {
        //   this.viewModel = vm,
        //   this.IsReady = true;
        //   //(<smallQuotViewModel>this.viewModel).BusinessType.markClean();
        // }
    };
    smallQuotEditComponent.prototype.ngAfterViewChecked = function () {
        if (this.IsReady) {
            // if ( (<smallQuotViewModel>this.viewModel).BusinessType.markClean != undefined ){
            //   console.log ("cleaning");
            //   (<smallQuotViewModel>this.viewModel).BusinessType.markClean();
            // }
        }
    };
    smallQuotEditComponent.prototype.ngAfterContentChecked = function () {
        // if ( this.IsReady){
        //   console.log ( "content");
        //   if ( (<smallQuotViewModel>this.viewModel).BusinessType.markClean != undefined )
        //     (<smallQuotViewModel>this.viewModel).BusinessType.markClean();
        // }  
    };
    smallQuotEditComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'smequot-edit',
            template: __webpack_require__(/*! ./smequot-edit.component.html */ "./src/app/smequot-edit/smequot-edit.component.html"),
            styles: [__webpack_require__(/*! ./smequot-edit.component.css */ "./src/app/smequot-edit/smequot-edit.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"]])
    ], smallQuotEditComponent);
    return smallQuotEditComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_1__["ComplexComponentBase"]));



/***/ }),

/***/ "./src/app/test-jcompare/test-jcompare.component.css":
/*!***********************************************************!*\
  !*** ./src/app/test-jcompare/test-jcompare.component.css ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Rlc3QtamNvbXBhcmUvdGVzdC1qY29tcGFyZS5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/test-jcompare/test-jcompare.component.html":
/*!************************************************************!*\
  !*** ./src/app/test-jcompare/test-jcompare.component.html ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div>\n    <tom-debugger [viewModel]=\"viewModel\"></tom-debugger>\n<!-- \n  <div class=\"row json-compare\">\n\n    <div class=\"form-group col-xs-6\">\n      <tom-text-area label=\"json1\"></tom-text-area>\n    </div>\n    <div class=\"form-group col-xs-6\">\n      <tom-text-area label=\"json2\"></tom-text-area>\n    </div>\n  </div> -->\n\n  <!-- <button (click)=\"test()\" >test</button> -->\n\n  <h2>Check Point Results</h2>\n  <tom-check-point-result [viewModel]=\"viewModel\"></tom-check-point-result>\n\n  <tom-session-mgr [viewModel]=\"viewModel.vmSessionIO\"></tom-session-mgr>\n\n  <h2> Log details</h2>\n  <div class=\"row\">\n    <div class=\"form-group col-xs-6\">\n      <tom-log [viewModel]=\"viewModel.vmLeftLogDB\"></tom-log>\n    </div>\n    <div class=\"form-group col-xs-6\">\n      <tom-log [viewModel]=\"viewModel.vmRightLogDB\"></tom-log>\n    </div>\n  </div>\n\n\n\n</div>"

/***/ }),

/***/ "./src/app/test-jcompare/test-jcompare.component.ts":
/*!**********************************************************!*\
  !*** ./src/app/test-jcompare/test-jcompare.component.ts ***!
  \**********************************************************/
/*! exports provided: TestJCompareComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestJCompareComponent", function() { return TestJCompareComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var TestJCompareComponent = /** @class */ (function (_super) {
    __extends(TestJCompareComponent, _super);
    function TestJCompareComponent(injector) {
        return _super.call(this, injector) || this;
    }
    Object.defineProperty(TestJCompareComponent.prototype, "viewModel", {
        get: function () {
            return TomFism__WEBPACK_IMPORTED_MODULE_1__["AppGlobal"].appViewModel.AutoTestVM;
        },
        enumerable: true,
        configurable: true
    });
    TestJCompareComponent.prototype.ngOnInit = function () {
    };
    TestJCompareComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'test-jcompare',
            template: __webpack_require__(/*! ./test-jcompare.component.html */ "./src/app/test-jcompare/test-jcompare.component.html"),
            styles: [__webpack_require__(/*! ./test-jcompare.component.css */ "./src/app/test-jcompare/test-jcompare.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"]])
    ], TestJCompareComponent);
    return TestJCompareComponent;
}(TomFism__WEBPACK_IMPORTED_MODULE_1__["ComplexComponentBase"]));



/***/ }),

/***/ "./src/app/test-page/test-page.component.css":
/*!***************************************************!*\
  !*** ./src/app/test-page/test-page.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "p\r\n{\r\n    color: white;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGVzdC1wYWdlL3Rlc3QtcGFnZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztJQUVJLGFBQWE7Q0FDaEIiLCJmaWxlIjoic3JjL2FwcC90ZXN0LXBhZ2UvdGVzdC1wYWdlLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJwXHJcbntcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/test-page/test-page.component.html":
/*!****************************************************!*\
  !*** ./src/app/test-page/test-page.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<p>\n  test-page works!\n</p>\n"

/***/ }),

/***/ "./src/app/test-page/test-page.component.ts":
/*!**************************************************!*\
  !*** ./src/app/test-page/test-page.component.ts ***!
  \**************************************************/
/*! exports provided: person, TestPageComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "person", function() { return person; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestPageComponent", function() { return TestPageComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var TomFism__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! TomFism */ "./dist/tomfism/fesm5/tomfism.js");
/* harmony import */ var _Models_SmallQuot_DataModel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Models/SmallQuot.DataModel */ "./src/app/Models/SmallQuot.DataModel.ts");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var person = /** @class */ (function () {
    function person(par) {
        this.name = par.name;
        this.sex = par.sex;
    }
    return person;
}());

var SampleContent = /** @class */ (function (_super) {
    __extends(SampleContent, _super);
    function SampleContent() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.SampleContent = "testing string";
        return _this;
    }
    return SampleContent;
}(TomFism__WEBPACK_IMPORTED_MODULE_1__["LogContent"]));
var TestPageComponent = /** @class */ (function () {
    function TestPageComponent() {
    }
    TestPageComponent.prototype.ngOnInit = function () {
        console.log("testing");
        //this.testSize();
        //this.testOptionalInterface();
        this.testAsync();
        //this.testLogger();
        //this.testLocalStorageKeys();
        //this.testLogReader();
        //this.testMaptoJson();
    };
    TestPageComponent.prototype.testMaptoJson = function () {
        var ChildrenSeqs = new Map();
        var subSeqs = new Map();
        subSeqs.set("a", 1);
        subSeqs.set("b", 2);
        var subSeqs2 = new Map();
        subSeqs2.set("a 3", 3);
        subSeqs2.set("b 4", 4);
        ChildrenSeqs.set(1, subSeqs);
        ChildrenSeqs.set(2, subSeqs2);
        console.log(ChildrenSeqs);
        var s = JSON.stringify(ChildrenSeqs);
        console.log(s);
        localStorage.setItem("testMap", s);
    };
    TestPageComponent.prototype.testLocalStorageKeys = function () {
        var keys = Array.apply(0, new Array(localStorage.length)).map(function (o, i) {
            return localStorage.key(i);
        });
        console.log("keys");
        console.log(keys);
    };
    TestPageComponent.prototype.testLogger = function () {
        // let logger = new tomLogger ();
        // let content = new SampleContent();
        // content.ContentType = ContentTypes.cmd;
        // content.time = new Date();
        // console.log ( content);
        // let item = new LogItem<SampleContent>( content);
        // item.seq =1 ,
        // item.Session = "12345"
        // logger.log (item);
        var reader = new TomFism__WEBPACK_IMPORTED_MODULE_1__["tomLogReader"](TomFism__WEBPACK_IMPORTED_MODULE_1__["CmdContent"]);
        console.log("max session");
        console.log(reader.MaxSession);
        console.log(reader.AllSessions);
    };
    TestPageComponent.prototype.testLogReader = function () {
        var DataModelReader = new TomFism__WEBPACK_IMPORTED_MODULE_1__["tomLogReader"](TomFism__WEBPACK_IMPORTED_MODULE_1__["DataModelContent"]);
        DataModelReader.initRead("09221240");
        var content = DataModelReader.readNext();
        console.log(content);
        var deserializer = new TomFism__WEBPACK_IMPORTED_MODULE_1__["tomDeserializer"]();
        //console.log ( json);
        var quoteData = deserializer.deserialize(_Models_SmallQuot_DataModel__WEBPACK_IMPORTED_MODULE_2__["SmallQuotDataContainer"], content.content);
        console.log(quoteData);
    };
    TestPageComponent.prototype.testOptionalInterface = function () {
        var p = new person({ name: "tom" });
        console.log(p);
    };
    TestPageComponent.prototype.testAsync = function () {
        this.sumTwentyAfterTwoSeconds(40);
        //this.sumTwentyAfterTwoSeconds(20);    
    };
    TestPageComponent.prototype.sumTwentyAfterTwoSeconds = function (value) {
        return __awaiter(this, void 0, void 0, function () {
            var remainder, a, remainder2, a2;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        remainder = this.afterTwoSeconds(40);
                        return [4 /*yield*/, remainder];
                    case 1:
                        a = _a.sent();
                        console.log(a);
                        remainder2 = this.afterTwoSeconds(20);
                        return [4 /*yield*/, remainder2];
                    case 2:
                        a2 = _a.sent();
                        console.log(a2);
                        return [2 /*return*/, value + a];
                }
            });
        });
    };
    TestPageComponent.prototype.afterTwoSeconds = function (value) {
        return new Promise(function (resolve) {
            setTimeout(function () { resolve(value); }, value * 100);
        });
    };
    TestPageComponent.prototype.testSize = function () {
        console.log(localStorage.getItem('size'));
        if (localStorage && !localStorage.getItem('size')) {
            var i = 0;
            try {
                // Test up to 10 MB
                for (i = 250; i <= 10000; i += 250) {
                    localStorage.setItem('test', new Array((i * 1024) + 1).join('a'));
                }
                console.log("size ok");
            }
            catch (e) {
                //localStorage.removeItem('test');
                localStorage.setItem('size', (i - 250).toString());
                console.log("oversize");
            }
        }
    };
    TestPageComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'test-page',
            template: __webpack_require__(/*! ./test-page.component.html */ "./src/app/test-page/test-page.component.html"),
            styles: [__webpack_require__(/*! ./test-page.component.css */ "./src/app/test-page/test-page.component.css")]
        }),
        __metadata("design:paramtypes", [])
    ], TestPageComponent);
    return TestPageComponent;
}());



/***/ }),

/***/ "./src/app/xtext-box/xtext-box.component.html":
/*!****************************************************!*\
  !*** ./src/app/xtext-box/xtext-box.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!-- <p>\n  xtext-box works!\n</p> -->\n\n\n<label *ngIf=\"label\">{{label}}</label>\n\n <input disabled  style=\"word-break: break-word;\"\n     [ngModel]=\"viewField.FieldValue\"\n      placeholder=\"{{placeholder}}\" value=\"\" class=\"form-control form-control-sm\"> \n\n"

/***/ }),

/***/ "./src/app/xtext-box/xtext-box.component.ts":
/*!**************************************************!*\
  !*** ./src/app/xtext-box/xtext-box.component.ts ***!
  \**************************************************/
/*! exports provided: XTextBoxComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "XTextBoxComponent", function() { return XTextBoxComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var tomgular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tomgular */ "./dist/tomgular/fesm5/tomgular.js");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var XTextBoxComponent = /** @class */ (function (_super) {
    __extends(XTextBoxComponent, _super);
    function XTextBoxComponent(injector) {
        return _super.call(this, injector) || this;
    }
    XTextBoxComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'tom-text-box',
            template: __webpack_require__(/*! ./xtext-box.component.html */ "./src/app/xtext-box/xtext-box.component.html")
        }),
        __metadata("design:paramtypes", [_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"]])
    ], XTextBoxComponent);
    return XTextBoxComponent;
}(tomgular__WEBPACK_IMPORTED_MODULE_1__["TomTextBoxComponent"]));



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! F:\angular2\lib7DI\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map