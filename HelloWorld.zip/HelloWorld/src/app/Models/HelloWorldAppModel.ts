import { DataModelBase, ViewModel, ViewField, AppGlobal, AppViewModel, ViewModel_CtorParam , AppDataModel} from "TomFism"
import { HelloWorldDataModel, HelloWorldViewModel } from "./HelloWorld.model";

export class HellowWroldAppDataModel extends AppDataModel{

}

export class HelloWorldAppView extends AppViewModel {
    constructor( ctroParam: ViewModel_CtorParam) {
        super(ctroParam);

    }

    get dataModel() : HellowWroldAppDataModel {
        return <HellowWroldAppDataModel><any>this._getDataModel<HelloWorldDataModel>();
    }

    getStatusValue( status : string) : string{
        return "";
    }

    vmHelloWorld : HelloWorldViewModel = null ;
}