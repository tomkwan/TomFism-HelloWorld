import { DataModelBase, ViewModel, ViewField, ButtonViewField, DirectCmd} from "TomFism"

export class HelloWorldDataModel extends DataModelBase{
    HelloName : string = null;
    
}


export class HelloWorldViewModel extends ViewModel {
    
    get dataModel() : HelloWorldDataModel{
        return this._getDataModel()
    }


    HelloName : ViewField = new ViewField(
        {
            getViewModel : () => this,
            fieldName : "HelloName",
            
        }
    )

    TitleColor : string = "blue";


    test (){
        console.log ( this.ChangeColorButton.routableCmd);
        this.ChangeColorButton.routableCmd.runCmd();


    }
    ChangeColorButton : ButtonViewField = new ButtonViewField(
        {
            getViewModel : () => this,
            fieldName : "ChangeColorButton",
            getFieldValue : () => "Change Color",
            routableCmd : new DirectCmd(
                {
                    CmdName : "changeColor",
                    directCmd : () => {
                        if ( this.TitleColor == "blue"){
                            this.TitleColor = "yellow"
                        }
                        else{
                            this.TitleColor = "blue"
                        }
                    }
                }
            )
        }
    );
}