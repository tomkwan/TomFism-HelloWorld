import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import {TomModule} from "tomgular"
import {NgbModule  } from '@ng-bootstrap/ng-bootstrap';
import { HelloWorldAppView, HellowWroldAppDataModel } from "./Models/HelloWorldAppModel"
import { AppGlobal, DressingRule, DressingSetting, AppMode } from 'TomFism';
import { HelloWorldSetting} from "./setting/HelloWorldSetting"
import { HellowWorldComponent} from "./hellow-world/hellow-world.component"



@NgModule({
  declarations: [
    AppComponent,
    HellowWorldComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    TomModule,
    NgbModule.forRoot(),    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
  constructor (injector : Injector){
    
    AppGlobal.setting = new HelloWorldSetting(injector);
    

    const appData = new HellowWroldAppDataModel();
    const appView = new HelloWorldAppView(
      {
        DataModel : () => appData
      }
    );
    AppGlobal.appViewModel = appView;
    AppGlobal.appViewModel.cmdRouter = AppGlobal.setting.cmdRouter;
   

  


    // AppGlobal.appViewModel.VisibleSettings = 
    // [
    //   <DressingSetting>
    //   {
    //     SettingName  : "ChangeColr",
    //     TargetPath    : "HelloWorldAppView.HelloWorldViewModel.ChangeColorButton",
    //     TargetValue : false,
    //   } ,
    // ];

    // AppGlobal.appViewModel.EditSettings = 
    // [
    //   <DressingSetting>
    //   {
    //     SettingName  : "HelloName",
    //     TargetPath    : "HelloWorldAppView.HelloWorldViewModel.HelloName",
    //     TargetValue : false,
    //   } ,      
    // ];

    AppGlobal.appMode = AppMode.production;
    AppGlobal.appViewModel.init();
    AppGlobal.appViewModel.furnish();
  }
  
}
