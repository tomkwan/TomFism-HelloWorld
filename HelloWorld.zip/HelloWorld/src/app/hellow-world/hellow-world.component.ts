import { Component, OnInit, Injector } from '@angular/core';
import { HelloWorldViewModel, HelloWorldDataModel} from "../Models/HelloWorld.model"
import { ComplexComponentBase, FieldComponentBase, AppGlobal } from "TomFism"
import { HelloWorldAppView} from "../Models/HelloWorldAppModel"
@Component({
  selector: 'app-hellow-world',
  templateUrl: './hellow-world.component.html',
  styleUrls: ['./hellow-world.component.css']
})
export class HellowWorldComponent extends ComplexComponentBase implements OnInit {

  get viewModel() : HelloWorldViewModel{
    return <HelloWorldViewModel><any>  this._viewModel;
  }

   IsReady : boolean = false;

  constructor(injector: Injector) {
    super(injector);

    const hData = new HelloWorldDataModel();
    hData.HelloName = "tom name";
    

    this._viewModel = new HelloWorldViewModel(
      {
        DataModel : () => hData
      }
    );

    const appView = (<HelloWorldAppView> AppGlobal.appViewModel );
    appView.vmHelloWorld = this.viewModel;
    this.viewModel.parentViewModel = appView;
    this.viewModel.init();
     this.viewModel.furnish();

    this.IsReady = true;
  };
  

  ngOnInit() {
  }

}
