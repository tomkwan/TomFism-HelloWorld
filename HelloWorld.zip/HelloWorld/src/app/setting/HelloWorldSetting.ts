import { AppSetting} from "TomFism"
import { Injectable, Injector } from '@angular/core';

export class HelloWorldSetting extends AppSetting{
    constructor ( injector : Injector){
        super(injector)
    }
}