﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace DoGx.Primitive
{
    public class baseE : gxBaseE<baseE>
    {
        public baseE(string prefix, string localName, string namespaceURI, XmlDocument doc)
          : base(prefix, localName, namespaceURI, doc)
        {
        }

    }
}
