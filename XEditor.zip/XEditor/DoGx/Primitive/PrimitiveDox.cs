﻿using System;
using System.Collections.Generic;
using System.Text;
using DoGx;
using tUtil;
using System.Xml;
using tUtil.xml;
using Tomflection;
using DoGx.Pre.DoGEs;


namespace DoGx.Primitive
{
    public class PrimitiveDox : gxDocBase<baseE>
    {

        public const string PreURI = "urn:PreDox";
        public const string PrePRX = "pre";

        public PrimitiveDox( ) : 
            base(
                new IElFactory<baseE>[] { FactoryBuilder.CreateFactory<baseE, baseE>() }
               , typeof(baseE)
                , false)
        {
        }



    }
}
