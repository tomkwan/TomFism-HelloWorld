﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using Tomflection;
using tUtil.xml;

namespace DoGx
{
    /// <summary>
    /// XmlDocument with Namespaces, provided in a Dict
    /// </summary>
    public class NSxDocBase : XmlDocument, IPropertyStorable
    {
        public XmlNamespaceManager NSG;

        public NSxDocBase(IEnumerable<Dictionary<string, string>> NamespaceList)
        {
            this.NSG = new XmlNamespaceManager(this.NameTable);



            foreach (var namespaces in NamespaceList. Where( p => p !=null))
            {
                foreach (string k in namespaces.Keys)
                {
                    NSG.AddNamespace(k, namespaces[k]);
                }
            }

        }

        public XmlNamespaceManager RetrivedNSG => this.readProp_obj( ()=> DocumentElement.BuildXmlNamespaceManager());

        public NSxDocBase(string prefix, string urn) : this
            (new Dictionary<string, string>[] {
                    new Dictionary<string, string>(){ { prefix, urn} }
                }
            )
        {
        }

        public Dictionary<string, object> PropertyStorage => new Dictionary<string, object>();
    }
}
