﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace DoGx
{
    public class SimpleDox<BASE_T, ROOT_T> : gxDocBase<BASE_T> where ROOT_T : BASE_T where BASE_T : XmlElement
    {
        public SimpleDox(bool preProcess = true)
            : base(
                    new IElFactory<BASE_T>[] { new SimpleIEFactory<BASE_T, ROOT_T>() },
                    preProcess
                  )
        {
        }
    }
}
