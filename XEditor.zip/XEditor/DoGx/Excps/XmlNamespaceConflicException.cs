﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoGx.Excps
{
    public class XmlNamespaceConflicException : Exception
    {
        public XmlNamespaceConflicException(string msg)
            : base(msg)
        {
        }

    }
}
