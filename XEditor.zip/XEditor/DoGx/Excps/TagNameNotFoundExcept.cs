﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DoGx.Excps
{
    public class TagNameNotFoundExcept: Exception
    {
        public TagNameNotFoundExcept(string msg)
            : base(msg)
        {
        }



    }
}
