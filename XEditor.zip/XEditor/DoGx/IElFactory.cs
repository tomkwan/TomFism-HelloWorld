﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Reflection;
using Tomflection;
using System.Xml.Linq;

namespace DoGx
{
    public interface IElFactory<CLASS_T>
    {
        XmlElement CreateElement(string prefix, string localName, string namespaceURI, XmlDocument doc);
        Dictionary<string, string> NSDict
        {
            get;
        }
    }
}
