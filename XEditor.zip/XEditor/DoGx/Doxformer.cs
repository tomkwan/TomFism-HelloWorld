﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using tUtil.conversion;

namespace DoGx
{
    public abstract class Doxformer<T> : IDoxformable where T: gxBaseE<T> 
    {

        Type defaultEType;
        protected IElFactory<T>[] Factoreis;

        protected gxDocBase<T> Dox  => new gxDocBase<T>( this.Factoreis, this.defaultEType);


        protected Doxformer(IElFactory<T>[] factoreis, Type defaultE= null)
        {
            Factoreis = factoreis;
            this.defaultEType = defaultE;
        }

        public abstract void Transform(Stream inStream, Stream outStream);


        
    }
}
