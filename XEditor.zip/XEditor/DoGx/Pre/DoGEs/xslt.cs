

using DoGx;
using System;
using System.Collections.Generic;
using System.Text;
using Tomflection;
using System.Xml;
using System.Linq;
using tUtil.Exception;
using System.Xml.Xsl;
using System.IO;
using tUtil.validations;

namespace DoGx.Pre.DoGEs
{


    [gxElattrib(namespaceURI =PreDox.PreURI, TagName = "xslt", prefix =PreDox.PrePRX)]
    public class xslt: baseE
    {
        public xslt(string prefix, string localName, string namespaceURI, XmlDocument doc)
          : base(prefix, localName, namespaceURI, doc)
        {
        }



        string XsltFile => GetAttribute(nameof(XsltFile));

        string DataFile => GetAttribute(nameof(DataFile));

        XmlElement DataElement => this.readProp_obj(() => this.ChildrenEs.FirstOrDefault());



        [ValidatorAttrib]
        public ValidationResult<gxBaseE<baseE>> validate_XsltFile_existence()
        {
            if (!File.Exists(XsltFile))
                return new ValidationResult<gxBaseE<baseE>>(enServerity.fatal, this, 
                    $"{nameof(XsltFile)}  File does not exist : {XsltFile}");

            return null;
        }

        [ValidatorAttrib]
        public ValidationResult<gxBaseE<baseE>> validate_DataContent_existence()
        {
            if (this.DataElement == null && string.IsNullOrEmpty(DataFile))
                return new ValidationResult<gxBaseE<baseE>>(enServerity.fatal, this,
                    $"Both { nameof(DataFile)} " +
                    $" and  {nameof(DataElement) }  " +
                    $" are absent");
            else if (!string.IsNullOrEmpty(DataFile) && !File.Exists(DataFile))
                return new ValidationResult<gxBaseE<baseE>>(enServerity.fatal, this,
                    $"{nameof(DataFile)}  File does not exist : {DataFile}");
            
            else if ( this.DataElement != null && ChildrenEs.Count() > 1)
                return new ValidationResult<gxBaseE<baseE>>(enServerity.fatal, this,
                    $"There must be ONLY 1 immediate child node in pre:xslt as data element  ");

            return null;
        }


        public override void Copy(XmlWriter xWriter)
        {

            if (this.DataElement == null && string.IsNullOrEmpty(DataFile))
            {
                throw new tUtil.Exception.EmptyException(
                    $"Both { nameof(DataFile)} " +
                    $" and  {nameof(DataElement) }  " +
                    $" are absent");
            }

            XslCompiledTransform cxslt = new XslCompiledTransform();

            try
            {
                cxslt.Load(XsltFile);
            
                if ( DataElement == null)
                    cxslt.Transform(DataFile, xWriter);
                else
                    cxslt.Transform(DataElement.CreateNavigator() , xWriter);

                xWriter.Flush();
            }
            catch (System.Exception e)
            {
                throw new TomXsltException(XsltFile, DataFile, e);
            }

        }

    }
}

