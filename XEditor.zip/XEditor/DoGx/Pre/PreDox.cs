﻿using System;
using System.Collections.Generic;
using System.Text;
using DoGx;
using tUtil;
using System.Xml;
using tUtil.xml;
using Tomflection;
using DoGx.Pre.DoGEs;


namespace DoGx.Pre
{
    public class PreDox : gxDocBase<baseE>
    {

        public const string PreURI = "urn:PreDox";
        public const string PrePRX = "pre";

        public PreDox( ) : 
            base(
                new IElFactory<baseE>[] { FactoryBuilder.CreateFactory<baseE, xslt>() }
               , typeof(baseE)
                , false)
        {
        }

        public bool AnyPreElement => this.root.SearchDown<baseE>(p => p.NamespaceURI == PreURI) != null;


    }
}
