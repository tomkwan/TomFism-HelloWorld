﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace DoGx
{
    public class FactoryBuilder
    {
        public static gxElfactoryBase<T> CreateFactory<T,G>() where T: gxBaseE<T> where G : gxBaseE<T>
        {
            Type t = typeof(G);
            Assembly assm = Assembly.GetAssembly(t);
            string ns = t.Namespace;
            gxElfactoryBase<T> factory = new gxElfactoryBase<T>(assm, ns);
            return factory;
        }


    }
}
