﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Reflection;
using Tomflection;
using System.Xml.Linq;

namespace DoGx
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="BASE_T">Base CLASS the retrieved class should be inherited to ( inclusive )</typeparam>
    public  class SimpleIEFactory<BASE_T, ROOT_T> : IElFactory<BASE_T> where ROOT_T : BASE_T 
    {

        public static XmlElement invokeInstance(Type EleType, string prefix, string localName, string namespaceURI, XmlDocument doc)
        {
            Type stringT = typeof(string);
            Type XmlDocT = typeof(XmlDocument);

            ConstructorInfo ci = 
            EleType.GetConstructor(new Type[] 
            {
                stringT, stringT, stringT, XmlDocT
            });

            XmlElement xe = ci.Invoke(new object[] { prefix, localName, namespaceURI, doc }) as XmlElement;
            return xe;

        }


        bool firstElement = true;
        public XmlElement CreateElement(string prefix, string localName, string namespaceURI, XmlDocument doc)
        {
            Type t = typeof(BASE_T);
            if (firstElement)
            {
                firstElement = false;
                t = typeof(ROOT_T);

            }

            return invokeInstance(t, prefix, localName, namespaceURI, doc);
        }




        Dictionary<string, string> IElFactory<BASE_T>.NSDict => null;



    }
}
