﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using tUtil.conversion;
using tUtil.xml;
using System.Xml;

namespace DoGx
{
    public class XsltDoxformer : IDoxformable
    {
        protected string XsltPath;

        public XsltDoxformer(string xsltPath)
        {
            XsltPath = xsltPath;
        }

        public void Transform(Stream inStream, Stream outStream)
        {
            XmlWriter xWriter = XmlWriter.Create(outStream, new XmlWriterSettings() { Indent = true, OmitXmlDeclaration = true });
            xWriter.XsltTrans(this.XsltPath, inStream);
            inStream.Flush();
            inStream.Close();
        }
    }
}
