﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Tomflection;
using tUtil.xml;
using tUtil.validations;

namespace DoGx
{
    public abstract class gxBaseE<T> : XmlElement, IPropertyStorable where T : gxBaseE<T>
    {
        private Dictionary<string, object> _PropertyStorage = new Dictionary<string, object>();

        protected internal gxBaseE(string prefix, string localName, string namespaceURI, XmlDocument doc) : base(prefix, localName, namespaceURI, doc)
        {
        }

        public virtual IEnumerable<T> ChildrenEs =>
            this.ChildNodes.Cast<XmlNode>().Where(
                    n => n.NodeType == XmlNodeType.Element).Cast<T>();

        public Dictionary<string, object> PropertyStorage
        {
            get
            {
                return this._PropertyStorage;
            }
        }

        public gxDocBase<T> ParentGxDoc
        {
            get
            {
                return this.OwnerDocument as gxDocBase<T>;
            }
        }

        /// <summary>
        /// travers down untill handler returns true;
        /// </summary>
        /// <param name="handler"></param>
        /// <returns></returns>
        public bool travers(Func<gxBaseE<T>, bool> handler)
        {
            bool continu = handler(this);
            if (!continu)
            {
                return false;
            }

            foreach (var be in ChildrenEs)
            {
                be.travers(handler);
            }

            return true;

        }



        public void traverse2root(Action<gxBaseE<T>> handler)
        {
            handler(this);
            if (this == this.OwnerDocument.DocumentElement)
                return;

            gxBaseE<T> bParent = this.ParentNode as gxBaseE<T>;
            bParent.traverse2root(handler);
        }

        public String FullXPath
        {
            get
            {
                string xpath = "";
                traverse2root(LeBaseE =>
                        xpath = LeBaseE.RetrieveRelativeXPath() + "/" + xpath);

                return xpath.Remove(xpath.Length - 1);
            }
        }


        public virtual List<ValidationResult<gxBaseE<T>>> Validate(List<ValidationResult<gxBaseE<T>>> result = null)
        {
            if (result == null)
                result = new List<ValidationResult<gxBaseE<T>>>();


            this.ExecuteValidators<gxBaseE<T>>(result);

            foreach (gxBaseE<T> be in ChildrenEs)
            {
                List<ValidationResult<gxBaseE<T>>> childsults = be.Validate(result);
            }
            return result;
        }

        protected gxBaseE<T> ParentBaseE => this.ParentNode as gxBaseE<T>;


        public virtual void WriteValidation(List<ValidationResult<gxBaseE<T>>> voilations, XmlWriter xwriter)
        {

            // method internal use only, because will be called in 2 spots
            Action callWriteVoilation = () =>
           {
               xwriter.CompleteElement(this,
                   () =>
                   {
                       xwriter.CopyAllAttributes(this);

                       if (!string.IsNullOrEmpty(this.SelfInnerText()))
                       {
                           xwriter.WriteAttributeString(ResultXWriter<gxBaseE<T>>.PREFIX, ResultXWriter<gxBaseE<T>>.INNER_TEXT, ResultXWriter<gxBaseE<T>>.URI, InnerText);

                       }
                       var myVoilations = voilations.Where(p => p.Spot == this);
                       foreach (var voilation in myVoilations)
                       {
                           voilation.WriteXResult(xwriter);
                       }
                       foreach (var be in ChildrenEs)
                       {
                           be.WriteValidation(voilations, xwriter);
                       }

                   }
                );

           };

            /// in case before start, write the root 
            if (xwriter.WriteState == WriteState.Start)
            {
                ResultXWriter<gxBaseE<T>>.WriteRoot(xwriter, () =>
               {
                   if (voilations.Count() == 0)
                   {
                       xwriter.WriteString(ResultXWriter<gxBaseE<T>>.NO_VOILATION);

                   }
                   else
                   {
                       callWriteVoilation();
                   }
               }
               );

            }
            else
            {
                callWriteVoilation();
            }

        }


        public virtual XmlNamespaceManager NsManager => this.readProp_obj(() => this.BuildXmlNamespaceManager());

        /// <summary>
        /// search the first match of type G
        /// </summary>
        /// <typeparam name="G"></typeparam>
        /// <returns></returns>
        public G SearchUp<G>(Func<G, bool> filter = null) where G : T
        {
            T pe = ParentBaseE as T;

            if (pe == null)
                return null;

            G ge = pe as G;

            if (ge != null)
            {
                if (filter == null)
                    return ge;
                else if (filter(ge))
                    return ge;
            }

            return pe.SearchUp<G>(filter);
        }

        public G SearchDown<G>(Func<G, bool> filter = null) where G : T
        {
            var ces = ChildrenEs.ToArray();

            G ge = ces.FirstOrDefault(p => p is G) as G;

            if (ge != null)
            {
                if (filter == null)
                    return ge;
                else if (filter(ge))
                    return ge;
            }

            foreach (T be in ces)
            {
                G innerGarget = be.SearchDown<G>();
                if (innerGarget != null)
                {
                    return innerGarget;
                }
            }

            return null;
        }


        public virtual void Copy(XmlWriter xWriter)
        {
            using (xeWriter xew = new xeWriter(this, xWriter))
            {
                xWriter.CopyAllAttributes(this);
                foreach (T be in ChildrenEs)
                {
                    be.Copy(xWriter);
                }
                string text = this.SelfInnerText();
                if (!string.IsNullOrEmpty(text))
                {
                    xWriter.WriteString(text);
                }

            }
            xWriter.Flush();
        }



        public virtual void Copy ( XmlWriter xWriter, Func<gxBaseE<T>, bool> condition)
        {
            if (!condition(this))
                return;

            using (xeWriter xew = new xeWriter(this, xWriter))
            {
                xWriter.CopyAllAttributes(this);
                foreach (T be in ChildrenEs)
                {
                    be.Copy(xWriter, condition);
                }
                string text = this.SelfInnerText();
                if (!string.IsNullOrEmpty(text))
                {
                    xWriter.WriteString(text);
                }

            }
            xWriter.Flush();

        }


    }
}
