﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tomflection;

namespace DoGx
{
    public class NsTagDict : Dictionary<string, TypeN_Attr<gxElattrib>>
    {
        public string Namespace;
        public string Prefix;

        public NsTagDict(string @namespace, string prefix)
        {
            Namespace = @namespace;
            this.Prefix = prefix;
        }


    }
}
