﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;
using tUtil.log;

namespace DoGx
{
    /// <summary>
    /// life cycle of load
    /// 1. check if vasox.LE_Vasox is set, 
    /// 2. if so, vasoxize the loading content
    /// 3. if gxDocBase.PreProcess is set
    /// 4. and element <xslt> </xslt> exists
    /// 5. perform xslt transform
    /// 6. load the transformed content as the final content.
    /// </summary>
    /// <typeparam name="CLASS_T"></typeparam>
    public class gxDocBase<CLASS_T> : NSxDocBase where CLASS_T : XmlElement
    {
        public IEnumerable<IElFactory<CLASS_T>> ElFactories;

        protected virtual Func<string, string, string, CLASS_T> DefaultElementCreator
        {
            get; set;
        }

        protected Type DefaultElementType;

        public gxDocBase(IEnumerable<IElFactory<CLASS_T>> ElFactories, bool preProcess = true)
            : base(ElFactories.Select(p => p.NSDict))
        {

            this.ElFactories = ElFactories;
            this.PreProccess = preProcess;
        }


        public gxDocBase(IEnumerable<IElFactory<CLASS_T>> ElFactories,
            Func<string, string, string, CLASS_T> defaultElementCreator, bool preProcess = true)
            : this(ElFactories, preProcess)
        {

            this.DefaultElementCreator = defaultElementCreator;
        }

        public gxDocBase(IEnumerable<IElFactory<CLASS_T>> ElFactories,
            Type defaultElementType, bool preProcess = true)
            : this(ElFactories, preProcess)
        {

            this.DefaultElementType = defaultElementType;
        }


        public override XmlElement CreateElement(string prefix, string localName, string namespaceURI)
        {
            XmlElement xe = null;
            foreach (var factory in this.ElFactories)
            {
                xe = factory.CreateElement(prefix, localName, namespaceURI, this);

                if (xe != null)
                    return xe;
            }


            if (this.DefaultElementCreator != null)
                return this.DefaultElementCreator(prefix, localName, namespaceURI);

            if (this.DefaultElementType != null)
                return gxElfactoryBase<CLASS_T>.invokeInstance(DefaultElementType, prefix, localName, namespaceURI, this);

            throw new Excps.TagNameNotFoundExcept("TagName not found in dict --> " + localName
                + "\nremedy : provide DefaultElementCreator or DefaultElementType at constructor "
                );


            //if (xe == null)
            //    return base.CreateElement(prefix, localName, namespaceURI);
            //else
            //    return xe;

        }

        CLASS_T _root;
        public CLASS_T root
        {
            get
            {
                if (_root == null)
                    _root = DocumentElement as CLASS_T;

                return _root;
            }
        }


        public bool PreProccess = false;

        bool PreProccessed = false;

        protected string PreXsltPath = null;


        public override void Load(string filename)
        {
            XmlReader xreader = XmlReader.Create(File.OpenRead(filename));
            this.Load(xreader);
        }

        public override void Load(Stream inStream)
        {
            XmlReader xreader = XmlReader.Create(inStream);
            this.Load(xreader);
        }

        public override void Load(TextReader txtReader)
        {
            XmlReader xreader = XmlReader.Create(txtReader);
            base.Load(xreader);
        }

        public override void LoadXml(string xml)
        {
            StringReader seader = new StringReader(xml);
            this.Load(seader);
        }

        public override void Load(XmlReader reader)
        {

            var LE_Vasox = tUtil.xml.vasox.LE_Vasox;
            if ( LE_Vasox != null)
            {
                XmlDocument _dox = new XmlDocument();
                _dox.Load(reader);
                LE_Vasox.vasoxize(_dox);

                reader = new XmlNodeReader(_dox);
            }


            if (!this.PreProccess || this.PreProccessed)
            {
                base.Load(reader);
                return;
            }

            DoGx.Pre.PreDox dox = new Pre.PreDox();
            dox.Load(reader);
            
            if (!dox.AnyPreElement)
            {

                reader = new XmlNodeReader(dox);
                base.Load(reader);
                return;

            }


            var validationResult = dox.root.Validate();

            if ( validationResult != null && validationResult.Count() > 0)
            {
                if (TomLog.IsIninited) {
                    var r = TomLog.newFileStream();
                    string file = r.Item1;
                    Stream fileStream = r.Item2;

                    XmlWriter xwriter = XmlWriter.Create(fileStream, new XmlWriterSettings() { Indent = true });
                    dox.root.WriteValidation(validationResult, xwriter);
                    xwriter.Flush();
                    fileStream.Close();
                }
                else
                {
                    XmlWriter xwriter = XmlWriter.Create( Console.Out, new XmlWriterSettings() { Indent = true });
                    dox.root.WriteValidation(validationResult, xwriter);
                    xwriter.Flush();
                }

                throw new tUtil.Exception.InconsistentException("Error in xml file at Pre Processing stage. " +
                    "Please see error printed in xml ");
            }


            Stream intermStream;
            string itermFile = null;

            if (TomLog.IsIninited)
            {
                var result = TomLog.newFileStream();
                intermStream = result.Item2;
                itermFile = result.Item1;
            }
            else
            {
                intermStream = new MemoryStream();
            }

            XmlWriter intermWriter = XmlWriter.Create(intermStream, new XmlWriterSettings() { Indent = true, OmitXmlDeclaration = true });
            dox.root.Copy(intermWriter);


            intermWriter.Flush();

            this.PreProccessed = true;

            
            if (TomLog.IsIninited)
            {
                intermStream.Close();
                
                dox.Load( itermFile );
            }
            else
            {
                intermStream.Position = 0;
                dox.Load(intermStream);
            }

            reader = new XmlNodeReader(dox);
            base.Load(reader);
        }


    }
}
