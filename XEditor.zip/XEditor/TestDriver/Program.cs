﻿// See https://aka.ms/new-console-template for more information
using System.Xml.Linq;


//tUtil.DataStructure.SelectableList.ext.Test();
XodeVM.zTest.Test();
//Schemox.Test.test();