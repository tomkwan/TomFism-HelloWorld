
console.log("js loading");

window.triggerFileDownload = (fileName, url) => {

        const anchorElement = document.createElement('a');
        anchorElement.href = url;
        anchorElement.download = fileName ?? '';
        anchorElement.click();
        anchorElement.remove();
    }

console.log("js loaded");


function openDialog() {
    var d = document.getElementById("d1");
    d.showModal();

}