console.log("new 3 js");

export function showDialog(element, parm) {

    console.log("js :");
    console.log(parm);
    element.showModal();
    //element.style.position = "absolute";
//    element.style.display = 'block';
//    element.style.zIndex = '10100';
//    element.style.width = "500px";
//    element.style.color = "red";
//    element.style.top = parm.pageY;
//    element.style.left = parm.pageX;
}

export function closeDialog(element, parm) {
    return element.close();
}