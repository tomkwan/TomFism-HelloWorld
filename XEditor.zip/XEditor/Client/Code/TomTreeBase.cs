﻿using Microsoft.AspNetCore.Components;
using TreeNodx.DoGEs;

namespace x
{
    public class TomTreeBase: ComponentBase
    {

        [Parameter]
        public node LeNode { get; set; }


        public string Expanded { get; set; }


        protected override Task OnInitializedAsync()
        {
            return base.OnInitializedAsync();
        }


        protected override Task OnParametersSetAsync()
        {
            //This will check if the first item in the
            // list/collection has a "parentId" then remove the "parentId" from it. 
            //Because we use the first item as a reference in the razor file, so it must not have "parentId".

            return base.OnParametersSetAsync();
        }


            

    }



}