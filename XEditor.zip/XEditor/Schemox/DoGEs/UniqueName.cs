

using DoGx;
using System;
using System.Collections.Generic;
using System.Text;
using Tomflection;
using System.Xml;
using System.Linq;
using tUtil.Exception;
using Schemox.consts;
using Schemox.Basics;
using System.IO;
using System.Xml.Xsl;

namespace Schemox.DoGEs
{

    [gxElattrib(TagName = nameof(UniqueName), namespaceURI = DoxCONST.shemoxURI, prefix = DoxCONST.schemoxPrx)]
    public class UniqueName : SchDefE
    {
        public UniqueName(string prefix, string localName, string namespaceURI, XmlDocument doc)
          : base(prefix, localName, namespaceURI, doc)
        {
        }


        public string ns => GetAttribute(nameof(ns));

        //public string TargetName => string.IsNullOrEmpty(ns) ? this.LocalName : ns + ":" + this.LocalName;

        //public override IEnumerable<SchoxValidationResult> CheckChildQuantity(ContentBaseE content)
        //{

        //}

    }
}

