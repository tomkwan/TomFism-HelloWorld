

using DoGx;
using System;
using System.Collections.Generic;
using System.Text;
using Tomflection;
using System.Xml;
using System.Linq;
using tUtil.Exception;
using Schemox.consts;
using Schemox.Basics;
using System.IO;
using System.Xml.Xsl;
using tUtil.conversion;

namespace Schemox.DoGEs
{

    [gxElattrib(TagName = nameof(ValidationScript), namespaceURI = DoxCONST.shemoxURI, prefix = DoxCONST.schemoxPrx)]
    public class ValidationScript : baseE
    {
        public ValidationScript(string prefix, string localName, string namespaceURI, XmlDocument doc)
          : base(prefix, localName, namespaceURI, doc)
        {
            this.seq = (this.OwnerDocument as Schox).ValidationScript_Seq++;
        }

        public string RawCode => this.InnerText;

        /// <summary>
        /// generated uid
        /// </summary>
        public readonly int seq;

        public string ScriptId => "vs_" + seq.ToString().Trim();


        /// <summary>
        /// Ancestor level for param content
        /// </summary>
        public int ExpandContentLevel => GetAttribute(nameof(ExpandContentLevel)).Convert(0);


        /// <summary>
        /// if the @esc:pin-point should added to the input param for the focused node
        /// </summary>
        public bool pin => GetAttribute(nameof(pin)).Convert(false);
    }
}

