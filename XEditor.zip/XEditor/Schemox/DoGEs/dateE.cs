

using DoGx;
using System;
using System.Collections.Generic;
using System.Text;
using Tomflection;
using System.Xml;
using System.Linq;
using tUtil.Exception;
using Schemox.consts;
using Schemox.Basics;
using System.IO;
using System.Xml.Xsl;

namespace Schemox.DoGEs
{

    [gxElattrib(TagName = "date", namespaceURI = DoxCONST.shemoxURI, prefix = DoxCONST.schemoxPrx)]
    public class dateE : NumbericBaseE
    {
        public dateE(string prefix, string localName, string namespaceURI, XmlDocument doc)
          : base(prefix, localName, namespaceURI, doc)
        {
        }

        public string DateFormat
        {
            get
            {
               culture c = (this.OwnerDocument as Schox).CultureE;
                if (c == null || string.IsNullOrEmpty( c.DateFormat ))
                    return "d";
                else
                    return c.DateFormat;
            }
        }

        public override bool TryParse(string value)
        {
            DateTime i;
            return DateTime.TryParseExact(value, DateFormat, null, System.Globalization.DateTimeStyles.None, out i);
        }

        DateTime parse ( string value)
        {
            return DateTime.ParseExact(value, DateFormat, null, System.Globalization.DateTimeStyles.None);

        }

        protected override SchoxValidationResult DetailValidateValue(string value)
        {
            SchoxValidationResult result = new SchoxValidationResult();
            if (!string.IsNullOrEmpty(this.min))
            {
                if (!this.TryParse(this.min))
                {
                    throw new tUtil.Exception.CastFailureException(typeof(string), typeof(DateTime), "content : " + this.min);
                }

                if ( this.parse(value) < this.parse(this.min))
                {
                    result.ResultType = SchoxValidationResultType.ValueOutOfRange;
                    return result;
                }
            }

            if (!string.IsNullOrEmpty(this.max))
            {
                if (!this.TryParse(this.max))
                {
                    throw new tUtil.Exception.CastFailureException(typeof(string), typeof(DateTime), "content : " + this.max);
                }

                if (this.parse(value) > this.parse(this.max))
                {
                    result.ResultType = SchoxValidationResultType.ValueOutOfRange;
                    return result;
                }
            }


            return null;

        }
    }
}

