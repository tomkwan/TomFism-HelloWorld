

using DoGx;
using System;
using System.Collections.Generic;
using System.Text;
using Tomflection;
using System.Xml;
using System.Linq;
using tUtil.Exception;
using Schemox.consts;
using Schemox.Basics;
using System.IO;
using System.Xml.Xsl;

namespace Schemox.DoGEs
{

    [gxElattrib(TagName = "float", namespaceURI = DoxCONST.shemoxURI, prefix = DoxCONST.schemoxPrx)]
    public class floatE : NumbericBaseE
    {
        public floatE(string prefix, string localName, string namespaceURI, XmlDocument doc)
          : base(prefix, localName, namespaceURI, doc)
        {
        }

        public override bool TryParse(string value)
        {
            float i;
            return float.TryParse(value, out i);
        }

        protected override SchoxValidationResult DetailValidateValue(string value)
        {
            SchoxValidationResult result = new SchoxValidationResult();
            if (!string.IsNullOrEmpty(this.min))
            {
                if (!this.TryParse(this.min))
                {
                    throw new tUtil.Exception.CastFailureException(typeof(string), typeof(float), "content : " + this.min);
                }

                if (float.Parse(value) < float.Parse(this.min))
                {
                    result.ResultType = SchoxValidationResultType.ValueOutOfRange;
                    return result;
                }
            }

            if (!string.IsNullOrEmpty(this.max))
            {
                if (!this.TryParse(this.max))
                {
                    throw new tUtil.Exception.CastFailureException(typeof(string), typeof(int), "content : " + this.max);
                }

                if (float.Parse(value) > float.Parse(this.max))
                {
                    result.ResultType = SchoxValidationResultType.ValueOutOfRange;
                    return result;
                }
            }


            return result;

        }

    }
}

