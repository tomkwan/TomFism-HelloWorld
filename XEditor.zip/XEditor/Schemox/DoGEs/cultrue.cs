

using DoGx;
using System;
using System.Collections.Generic;
using System.Text;
using Tomflection;
using System.Xml;
using System.Linq;
using tUtil.Exception;
using Schemox.consts;
using Schemox.Basics;
using System.IO;
using System.Xml.Xsl;

namespace Schemox.DoGEs
{

    [gxElattrib(TagName = nameof(culture), namespaceURI = DoxCONST.shemoxURI, prefix = DoxCONST.schemoxPrx)]
    public class culture : baseE
    {
        public culture(string prefix, string localName, string namespaceURI, XmlDocument doc)
          : base(prefix, localName, namespaceURI, doc)
        {
        }

        public string DateFormat => GetAttribute(nameof(DateFormat));

    }
}

