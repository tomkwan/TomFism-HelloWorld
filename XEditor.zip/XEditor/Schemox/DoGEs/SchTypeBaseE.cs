

using DoGx;
using System;
using System.Collections.Generic;
using System.Text;
using Tomflection;
using System.Xml;
using System.Linq;
using tUtil.Exception;
using Schemox.consts;
using Schemox.Basics;
using System.IO;
using System.Xml.Xsl;

namespace Schemox.DoGEs
{

    public abstract class SchTypeBaseE : baseE
    {
        public SchTypeBaseE(string prefix, string localName, string namespaceURI, XmlDocument doc)
          : base(prefix, localName, namespaceURI, doc)
        {
        }

        public abstract bool TryParse(string value);


        protected bool nullable
        {
            get
            {
                string s = GetAttribute(nameof(nullable));
                if (string.IsNullOrEmpty(s))
                    return true;
                else
                    return bool.Parse(s);
            }
        }

        protected virtual SchoxValidationResult DetailValidateValue( string value)
        {
            return new SchoxValidationResult();

        }

        public virtual SchoxValidationResult ValidateValue(string value)
        {
            var result = new SchoxValidationResult();
            

            if (string.IsNullOrEmpty(value) && !this.nullable)
            {
                result.ResultType = SchoxValidationResultType.NullNotAllowed;
            }
            else if (!TryParse(value))
            {
                result.ResultType = SchoxValidationResultType.DataTypeParsingError;
            }
            else
            {
                result = DetailValidateValue(value);
            }
            return result;

        }

    }
}

