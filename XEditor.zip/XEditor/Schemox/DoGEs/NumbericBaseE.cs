

using DoGx;
using System;
using System.Collections.Generic;
using System.Text;
using Tomflection;
using System.Xml;
using System.Linq;
using tUtil.Exception;
using Schemox.consts;
using Schemox.Basics;
using System.IO;
using System.Xml.Xsl;

namespace Schemox.DoGEs
{

    public abstract class  NumbericBaseE : SchTypeBaseE
    {
        public NumbericBaseE(string prefix, string localName, string namespaceURI, XmlDocument doc)
          : base(prefix, localName, namespaceURI, doc)
        {
        }


        protected override SchoxValidationResult DetailValidateValue(string value)
        {
            return base.DetailValidateValue(value);
        }


        protected string max => GetAttribute(nameof(max));

        protected string min => GetAttribute(nameof(min));

    }
}

