﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Schemox
{
    [System.Text.Json.Serialization.JsonConverter(typeof(System.Text.Json.Serialization.JsonStringEnumConverter))]
    public enum SchoxValidationResultType
    {
        [EnumMember(Value = nameof(success))]
        success,
        [EnumMember(Value = nameof(DefNotFound))]
        DefNotFound,
        [EnumMember(Value = nameof(ChildElementDefNotFoud))]
        ChildElementDefNotFoud,

        [EnumMember(Value = nameof(AttributeDefNotFoud))]
        AttributeDefNotFoud,

        [EnumMember(Value = nameof(AttributeMissing))]
        AttributeMissing,


        [EnumMember(Value = nameof(DataTypeError))]
        DataTypeError,
        [EnumMember(Value = nameof(QuantityError))]
        QuantityError,
        [EnumMember(Value = nameof(DataTypeError))]
        DataTypeParsingError,
        [EnumMember(Value = nameof(ValueOutOfRange))]
        ValueOutOfRange,
        [EnumMember(Value = nameof(NullNotAllowed))]
        NullNotAllowed,
    }
}
