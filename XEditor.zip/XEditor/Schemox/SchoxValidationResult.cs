﻿using System;
using System.Collections.Generic;
using System.Text;
using tUtil.validations;

namespace Schemox
{
    public class SchoxValidationResult: tUtil.validations.ValidationResult<IContentNode>
    {
        public SchoxValidationResult(enServerity serverity, IContentNode spot, string description) : base(serverity, spot, description)
        {

        }
        public SchoxValidationResult() : base(enServerity.none, null, null )
        {

        }
        



        [System.Text.Json.Serialization.JsonConverter(typeof(System.Text.Json.Serialization.JsonStringEnumConverter))]
        public SchoxValidationResultType ResultType { get; set; }
        public Basics.SchDefE DefNode { get; set; }
        public IContentNode ContentNode { get; set; }

    }
}
