﻿using Schemox.Basics;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Linq;
using tUtil.conversion;

namespace Schemox
{
    public class ContentAttribute : XmlAttribute, IContentNode
    {
        protected internal ContentAttribute(string prefix, string localName, string namespaceURI, XmlDocument doc) : base(prefix, localName, namespaceURI, doc)
        {
        }


        public SchDefE AttachedSchoxDef => ((OwnerElement as ContentBaseE).AttachedSchoxDef as defaultE)?.ChildAttributeDefs
                  .FirstOrDefault(p => p.TargetAttributeName == this.Name);

        public IEnumerable<SchDefE> Appendables => Enumerable.Empty<SchDefE>();


        public void AddPin(string targetAttribName = null)
        {
            (this.OwnerElement as ContentBaseE).AddPin( this.Name  );
        }

        public ContentBaseE getExpandContent(int expandLevel)
        {
            throw new NotImplementedException();
        }

        public void RemovePin()
        {
            (this.OwnerElement as ContentBaseE).RemovePin();
        }

        public SchoxValidationResult ValidateValue(string value)
        {
            return this.AttachedSchoxDef.ValidateValue(value);
        }
        public void writeDebug(XmlWriter xWriter)
        {
            throw new NotImplementedException();
        }
    }
}
