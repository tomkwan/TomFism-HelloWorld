﻿using DoGx;
using System;
using System.Reflection;
using Schemox.Basics;
using Schemox.DoGEs;
using System.Collections.Generic;
using tUtil.xml;
using System.Linq;

namespace Schemox
{
    public class Schox : gxDocBase<baseE>
    {

        public Schox() : base(new IElFactory<baseE>[] { new SchoxFactory () })
        {
        }


        public culture CultureE => (root as root).CultrueE;


        public int ValidationScript_Seq = 0;

        public IEnumerable<ValidationScript> ValidationScripts =>
            this.root.NsSelectNodes($"//{consts.DoxCONST.schemoxPrx}:{nameof(ValidationScript)}").Cast<ValidationScript>();


        public IEnumerable<DeclaredType> DeclaredTypes => root.ChildrenEs.Where(p => p is DeclaredType).Cast<DeclaredType>();

    }
}
