﻿using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Text.Json;
namespace Schemox.JS
{
    public class CodeGenResult
    {
        //ystem.Text.Json.Serialization.JsonConverter (typeof(System.Text.Json.Serialization.JsonStringEnumConverter))]
        public CodeGenResultType ResultType { get; set; } // = CodeGenResultType.NotSet;
        public string ClientException { get; set; }
        public string ItemId { get; set; }

        public JsonElement RawCode { get; set; }

    }
}
