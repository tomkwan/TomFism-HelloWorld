﻿using Schemox;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schemox.JS
{
    public interface IJsValidatorExecutor
    {
        Task<SchoxValidationResult> Validate(IContentNode content);


        Task<SchoxValidationResult> CallValidateById(string id, IContentNode content);

    }
}
