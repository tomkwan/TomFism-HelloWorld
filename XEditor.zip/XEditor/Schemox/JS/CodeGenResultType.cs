﻿using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using System.Runtime.Serialization;

namespace Schemox.JS
{
    [System.Text.Json.Serialization.JsonConverter(typeof(System.Text.Json.Serialization.JsonStringEnumConverter))]
    public enum CodeGenResultType
    {
        [EnumMember(Value = nameof(NotSet))] 
        NotSet ,
        [EnumMember(Value = nameof(success))]
        success,
        [EnumMember(Value = nameof(UnknowException))]
        UnknowException,
        [EnumMember(Value = nameof(RawCodeParsingError))]
        RawCodeParsingError,
        [EnumMember(Value = nameof( ItemCreationError))]
        ItemCreationError,
    }
}
