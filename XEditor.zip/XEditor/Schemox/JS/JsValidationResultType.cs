﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Schemox.JS
{
    [System.Text.Json.Serialization.JsonConverter(typeof(System.Text.Json.Serialization.JsonStringEnumConverter))]
    public enum JsValidationResultType
    {
        [EnumMember(Value = nameof(success))]
        success,
        [EnumMember(Value = nameof(JsException))]
        JsException,
        [EnumMember(Value = nameof(OverTime))]
        OverTime,
        [EnumMember(Value = nameof(CallException))]
        CallException,
        [EnumMember(Value = nameof(ClientJsMissing))]
        ClientJsMissing
    }
}
