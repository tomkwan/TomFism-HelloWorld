﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Schemox.JS
{
    public class JsCode
    {
        public string id { get; set; }
        public string RawCode { get; set; }
    }
}
