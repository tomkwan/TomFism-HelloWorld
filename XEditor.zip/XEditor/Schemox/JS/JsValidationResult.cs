﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Schemox.JS
{
    public class JsValidationResult
    {
        public JsValidationResultType ResultType = JsValidationResultType.OverTime;
        public bool IsValid;
        public string MsgCode;
    }
}
