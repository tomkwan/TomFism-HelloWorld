﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.IO;
using tUtil.xml;
using DoGx;
using Schemox.Basics;
using System.Xml.Linq;
using System.Linq;

namespace Schemox
{
    public class Test
    {
        public static void test()
        {
            //test_1();
            //test_2();
            test_3();
        }

        static string BASEPath = @"C:\TomCode\XEditor\Schemox\Sample";
        static void test_1()
        {
            string file = "1.xml";

            Schox dox = new Schox();

            using (FileStream fs = File.OpenRead(Path.Combine(BASEPath, file)))
            {
                dox.Load(fs);
            }
            dox.root.WellPrint(Console.Out);

        }


        //static void test_2()
        //{
        //    string contentFile = "content_1.xml";
        //    string defFile = "1.xml";
        //    ContentDox contentDox = null;


        //    using (FileStream fs = File.OpenRead(Path.Combine(BASEPath, contentFile)))
        //    using (FileStream def_fs = File.OpenRead(Path.Combine(BASEPath, defFile)))
        //    {

        //        Schox schox = new Schox();
        //        schox.Load(def_fs);
        //        contentDox = new ContentDox(schox);
        //        contentDox.Load(fs);
        //    }
        //    var result = contentDox.root.Match();
        //    Console.WriteLine(result.ResultType.ToString());


        //}

        static void test_3()
        {
            string contentFile = "content_1.xml";
            string defFile = "1.xml";
            ContentDox contentDox = null;


            using (FileStream fs = File.OpenRead(Path.Combine(BASEPath, contentFile)))
            using (FileStream def_fs = File.OpenRead(Path.Combine(BASEPath, defFile)))
            {

                Schox schox = new Schox();
                schox.Load(def_fs);
                contentDox = new ContentDox(schox);
                contentDox.Load(fs);
            }
            var result = contentDox.root.Validate();

            contentDox.root.QuotaXView.toXmlDoc().DocumentElement.WellPrint(Console.Out);


            Console.WriteLine();

            XElement xe = new XElement("Appendables",
                contentDox.root.Appendables.Select(p =>
                    new XElement("item", p.Name)
                    )
                );
            xe.toXmlDoc().DocumentElement.WellPrint(Console.Out);

        }


    }
}
