﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using DoGx;
using Schemox.DoGEs;
using Schemox.Basics;
using System.Linq;
using tUtil.validations;

namespace Schemox
{
    public class ContentRoot : ContentBaseE
    {
        public ContentRoot(string prefix, string localName, string namespaceURI, XmlDocument doc) : base(prefix, localName, namespaceURI, doc)
        {


        }

        public override SchDefE AttachedSchoxDef => (OwnerDocument as ContentDox).LeSchox.root as SchDefE;

        public override List<ValidationResult<gxBaseE<ContentBaseE>>> Validate(List<ValidationResult<gxBaseE<ContentBaseE>>> result = null)
        {
            return ChildrenEs.SelectMany(p => p.Validate(null)).ToList();
        }

    }
}
