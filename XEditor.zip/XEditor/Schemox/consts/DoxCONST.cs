

using System;
using System.Collections.Generic;
using System.Text;

namespace Schemox.consts
{
    public class DoxCONST
    {
        public const string shemoxURI = "urn:schemox";
        public const string schemoxPrx = "sch";

        public const string shAttributeURI = "urn:schemox-attribute";
        public const string shAttributePrx = "sca";

        public const string ESC_PREFIX = "esc";
        public const string ESC_URN = "urn:embedded-state-control";
        public const string PINPOINT = "pin-point";


    }
}

