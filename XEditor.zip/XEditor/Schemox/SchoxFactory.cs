﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Xml;
using DoGx;
using Schemox.Basics;
using Schemox.DoGEs;
using Tomflection;

namespace Schemox
{
    public class SchoxFactory : gxElfactoryBase<baseE>
    {
        //Dictionary<string, object> _PropertyStorage = new Dictionary<string, object>();

        static Type TARGET_TYPE = typeof(SchTypeBaseE);
        public SchoxFactory() : base(  TARGET_TYPE.Assembly , TARGET_TYPE.Namespace )
        {
        }

        bool rootCreated = false;

        public override XmlElement CreateElement(string prefix, string localName, string namespaceURI, XmlDocument doc)
        {

            XmlElement result = null;
        
            if (!rootCreated)
            {
                result = new Basics.root(prefix, localName, namespaceURI, doc);
                rootCreated = true;
            }
            else if (namespaceURI == consts.DoxCONST.shAttributeURI)
            {
                result = new DoGEs.scaE(prefix, localName, namespaceURI, doc);
            }

            else if (namespaceURI == consts.DoxCONST.shemoxURI)
            {
                result = CreateByTagName(prefix, localName, namespaceURI, doc);
                if (result == null)
                    throw new tUtil.Exception.MemberNotFoundException(localName, " while creating xml element for Schox");
            }
            else
                result =new Basics.defaultE(prefix, localName, namespaceURI, doc);

            return result;
        }

    }
}
