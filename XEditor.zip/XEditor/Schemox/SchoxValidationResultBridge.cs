﻿using System;
using System.Collections.Generic;
using System.Text;
using tUtil.validations;
using DoGx;
using Schemox.Basics;

namespace Schemox
{
    public class SchoxValidationResultBridge : ValidationResult<gxBaseE<ContentBaseE>>
    {

        public SchoxValidationResult SchoxResult;

        public SchoxValidationResultBridge(SchoxValidationResult schoxResult) : base(enServerity.none, null, null)
        {
            SchoxResult = schoxResult;
        }

    }
}
