

using DoGx;
using System;
using System.Collections.Generic;
using System.Text;
using Tomflection;
using System.Xml;
using System.Linq;
using tUtil.Exception;
using Schemox.consts;
using System.Xml.Xsl;
using Schemox.DoGEs;

namespace Schemox.Basics
{

    [gxElattrib(TagName = nameof(root))]
    public class root : defaultE
    {
        public root(string prefix, string localName, string namespaceURI, XmlDocument doc)
          : base(prefix, localName, namespaceURI, doc)
        {
        }

        public culture CultrueE => ChildrenEs.FirstOrDefault(p => p is culture) as culture;


        public override IEnumerable<baseE> ChildrenEs => this.ChildNodes.Cast<XmlNode>().Where(
                                                n => n is baseE).Cast<baseE>();


    }
}

