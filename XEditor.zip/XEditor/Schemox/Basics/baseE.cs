

using DoGx;
using System;
using System.Collections.Generic;
using System.Text;
using Tomflection;
using System.Xml;
using System.Linq;
using tUtil.Exception;
using System.IO;
using System.Xml.Xsl;

namespace Schemox.Basics
{
    public abstract class baseE : gxBaseE<baseE>
    {
        public baseE(string prefix, string localName, string namespaceURI, XmlDocument doc)
          : base(prefix, localName, namespaceURI, doc)
        {
        }
        public bool IsValueType => this.ChildrenEs.FirstOrDefault(p => p is Schemox.DoGEs.SchTypeBaseE) != null;


        public bool UIHidden
        {
            get
            {
                string s = GetAttribute(nameof(UIHidden));
                if (string.IsNullOrEmpty(s))
                    return false;

                return (bool.Parse(s));
            }
        }

    }
}

