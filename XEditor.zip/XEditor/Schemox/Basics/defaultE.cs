using DoGx;
using System;
using System.Collections.Generic;
using System.Text;
using Tomflection;
using System.Xml;
using System.Linq;
using tUtil.Exception;
using tUtil.xml;
using Schemox.DoGEs;
using System.Diagnostics;
using System.ComponentModel;
using tUtil.conversion;

namespace Schemox.Basics
{
    public class defaultE : SchDefE
    {

        public defaultE(string prefix, string localName, string namespaceURI, XmlDocument doc)
          : base(prefix, localName, namespaceURI, doc)
        {
        }


        public int min
        {
            get
            {
                XmlAttribute xa = this.Attributes[nameof(min), consts.DoxCONST.shemoxURI];

                if (xa == null || string.IsNullOrEmpty(xa.Value))
                    return 0;
                else
                    return int.Parse(xa.Value);
            }
        }

        public int? max
        {
            get
            {
                XmlAttribute xa = this.Attributes[nameof(max), consts.DoxCONST.shemoxURI];

                if (xa == null || string.IsNullOrEmpty(xa.Value))
                    return null;
                else
                    return int.Parse(xa.Value);
            }
        }



        /// <summary>
        /// get the available quota for this EntityDef that the param Content Node can add as child
        /// </summary>
        /// <param name="contentNode"></param>
        /// <returns>null:infinity
        ///     <list>
        ///         <item> 
        ///             <term>null</term> 
        ///             <description>infinity</description>
        ///         </item>
        ///         <item> 
        ///             <term>negative</term> 
        ///             <description>quota exceeded</description>
        ///         </item>
        ///     </list>
        /// </returns>
        public virtual int? GetAvailableQuota ( ContentBaseE contentNode)
        {
            if (this.max == null)
                return null;
            
            int usedQuota = contentNode.ChildrenEs.Where(p => p.Name == this.Name).Count();

            return this.max - usedQuota;
        }







    }
}

