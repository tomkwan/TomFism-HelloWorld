﻿using Schemox.DoGEs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Xml;

namespace Schemox.Basics
{
    public class SchDefE : baseE
    {
        protected SchDefE(string prefix, string localName, string namespaceURI, XmlDocument doc) : base(prefix, localName, namespaceURI, doc)
        {
        }

        //public abstract ValidationResult ValidateValue(string value);
        public virtual SchoxValidationResult ValidateValue(string value)
        {
            var typeE = this.ChildrenEs.FirstOrDefault(p => p is SchTypeBaseE);

            if (typeE == null)
                throw new tUtil.Exception.EmptyException($"unexpected null for the {nameof(SchTypeBaseE)} in entity definition element");

            return (typeE as SchTypeBaseE).ValidateValue(value);

        }



        public IEnumerable<ValidationScript> ValidatorScripts => this.ChildrenEs.Where(p => p is ValidationScript).Cast<ValidationScript>();

        public IEnumerable<defaultE> ChildEntityDefs => ChildrenEs.Where(p => p is defaultE).Cast<defaultE>();
        public IEnumerable<UniqueName> ChildrenUniqueNames => ChildrenEs.Where(p => p is UniqueName).Cast<UniqueName>();


        protected string TypeRef => GetAttribute(nameof(TypeRef),  consts.DoxCONST.shemoxURI);


        public DeclaredType RefDelcaredType => (OwnerDocument as Schox).DeclaredTypes.FirstOrDefault(p => p.id == this.TypeRef);


        public override IEnumerable<baseE> ChildrenEs
        {
            get
            {

                var refType = this.RefDelcaredType;
                //Console.WriteLine("children for " + this.LocalName);
                if (refType == null)
                    return base.ChildrenEs;
                else
                {
                    return base.ChildrenEs.Union(refType.ChildrenEs);
                }
            }
        }


        public virtual IEnumerable<SchoxValidationResult> CheckChildQuantity(ContentBaseE content)
        {
            foreach (var ced in ChildEntityDefs)
            {
                int cCount = content.ChildrenEs.Where(p => p.Name == ced.Name).Count();
                string s = ced.Name;
                //Console.WriteLine(s);

                if ((ced.max != null && ced.max < cCount) || ced.min > cCount)
                {
                    yield return new SchoxValidationResult()
                    {
                        ResultType = SchoxValidationResultType.QuantityError,
                        ContentNode = content,
                        DefNode = ced,
                        Description = $"No. of <{ced.Name}> must between {ced.min.ToString()}  :  " + (ced.max == null ? "infinity" : ced.max.ToString())
                    };
                }
            }

            var uniqueChildNodes = content.ChildrenEs.Where(p => p.AttachedSchoxDef is UniqueName);
            var violateUniques = from u in uniqueChildNodes
                                 group u by u.Name into grp
                                 where grp.Count() > 1
                                 select grp;

            foreach ( var g in violateUniques.SelectMany( p => p))
            {
                yield return new SchoxValidationResult()
                {
                    ResultType = SchoxValidationResultType.QuantityError,
                    ContentNode = g,
                    DefNode = g.AttachedSchoxDef,
                    Description = $"UniqueName should be max one for {g.Name}"
                };
            }
        }

        public virtual IEnumerable<SchoxValidationResult> CheckMissingAttributes(ContentBaseE content)
        {
            var compulsoryAttrs = ChildAttributeDefs.Where(p => !p.IsNullable);
            var contentAttbNames = content.Attributes.Cast<XmlAttribute>().Select(p => p.Name).ToArray();

            foreach (var ca in compulsoryAttrs)
            {
                if (!contentAttbNames.Any(p => p == ca.TargetAttributeName))
                {
                    yield return new SchoxValidationResult()
                    {
                        ResultType = SchoxValidationResultType.AttributeMissing,
                        ContentNode = content,
                        Description = $"@{ca.TargetAttributeName} is missing"
                    };
                }
            }
        }

        public IEnumerable<scaE> ChildAttributeDefs => ChildrenEs.Where(p => p is scaE).Cast<scaE>();

        public IEnumerable<scaE> GetAttributesAppendable(ContentBaseE contentNode)
        {

            var allContentAttrNames = from a in contentNode.Attributes.Cast<XmlAttribute>()
                                      select a.Name;

            var allScas = from c in ChildrenEs
                          where c is scaE
                          select c as scaE;

            var result = from c in allScas
                         where !allContentAttrNames.Any(a => a == c.TargetAttributeName)
                         select c;

            return result;

        }


    }
}
