﻿using Schemox.Basics;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace Schemox
{
    public interface IContentNode
    {
         SchDefE AttachedSchoxDef { get; }
        void writeDebug(XmlWriter xWriter);
        //IEnumerable< SchoxValidationResult> Validate();
        SchoxValidationResult ValidateValue(string value);
        IEnumerable<SchDefE> Appendables { get; }

        string Name { get; }

        string Value { get; set; }


        /// <summary>
        /// serves for 2 purposes
        /// 1. UI level: retrieve the focused node after rebuilding UI tree from XML
        /// 2. JS script validation, 
        /// - @expandLevel of ValidatorScript requests input param of content of level(s) of current ancetster
        /// causing multiple elements of the same name as the focused node.
        /// - in case the validation script needs retrieve the focused node, the bool @pin should be specified 
        /// - if specified true, the @esc:pin-point is added TEMPORAILY to the same content xml just before serialization the 
        /// ancestor content as param to validation script, but is removed immediately after, vs. kept for purpose 1
        /// </summary>
        void AddPin( string targetAttribName = null);
        void RemovePin();

        ContentBaseE getExpandContent(int expandLevel);

        string LocalName { get; }
        string Prefix { get; }
    }
}
