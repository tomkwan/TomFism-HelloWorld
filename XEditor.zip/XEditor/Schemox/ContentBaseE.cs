﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using DoGx;
using Schemox.DoGEs;
using Schemox.Basics;
using System.Linq;
using System.Xml.Linq;
using tUtil;
using tUtil.xml;
using tUtil.validations;
using System.Resources;
using System.Runtime.CompilerServices;
using tUtil.conversion;

namespace Schemox
{
    public class ContentBaseE : gxBaseE<ContentBaseE>, IContentNode
    {
        public ContentBaseE(string prefix, string localName, string namespaceURI, XmlDocument doc) : base(prefix, localName, namespaceURI, doc)
        {
        }

        public virtual SchDefE AttachedSchoxDef
        {
            get
            {
                var parentDef = ((ParentNode as ContentBaseE).AttachedSchoxDef as SchDefE);

                if (parentDef == null)
                    return null;


                //parentDef = parentDef.RefDelcaredType ?? parentDef;

                var def =  parentDef.ChildEntityDefs.FirstOrDefault(p => p.Name == this.Name) as SchDefE;
                
                if (def == null)
                {
                    def = parentDef.ChildrenUniqueNames.FirstOrDefault(p => this.Prefix == p.ns);
                }

                return def;

            }
        }



        public virtual void writeDebug(XmlWriter xWriter)
        {
            xWriter.WriteStartElement(this.Prefix, this.LocalName, null);
            xWriter.CopyAllAttributes(this);

            if (this.AttachedSchoxDef == null)
            {
                xWriter.WriteAttributeString(Schemox.consts.DoxCONST.schemoxPrx, "NoSchemaMatching", null, "");
            }
            else
            {

                xWriter.WriteStartElement(Schemox.consts.DoxCONST.schemoxPrx, this.AttachedSchoxDef.LocalName, Schemox.consts.DoxCONST.shemoxURI);
                xWriter.CopyAllAttributes(this.AttachedSchoxDef);
                xWriter.WriteEndElement();


            }

            foreach (var c in ChildrenEs)
            {
                c.writeDebug(xWriter);
            }
            xWriter.WriteEndElement();
        }

        //public override IEnumerable<SchoxValidationResult> Validate()

        [ValidatorAttrib]
        
        protected IEnumerable<SchoxValidationResult> ValidateStructure()
        {
            var def = this.AttachedSchoxDef as SchDefE;
            if (def == null)
            {
                return
                    new SchoxValidationResult()
                    {
                        ResultType = SchoxValidationResultType.DefNotFound,
                        ContentNode = this
                    }.ToEnumerable();

            }
            else
            {

                var cNoDefElements = this.ChildrenEs.Where(p => p.AttachedSchoxDef == null).Select(
                    q => new SchoxValidationResult()
                    {
                        ResultType = SchoxValidationResultType.ChildElementDefNotFoud,
                        ContentNode = this,
                        Description = $"<{q.Name}>: definition not found in schema"
                    }).ToArray();

                var attrbs = this.Attributes.Cast<ContentAttribute>().ToArray();
                var cNoDefAttributes = attrbs.Where(p => p.AttachedSchoxDef == null).Select(
                    q => new SchoxValidationResult()
                    {
                        ResultType = SchoxValidationResultType.AttributeDefNotFoud,
                        ContentNode = q,
                    }).ToArray();
                
                var cNoDefAttributes_parent = cNoDefAttributes.Select(
                    q => new SchoxValidationResult()
                    {
                        ResultType = q.ResultType,
                        ContentNode = this,
                        Description = $"@{q.ContentNode.Name}: definition not found in schema"
                    }).ToArray();

                if ( attrbs.Any( p => p.Name.Contains("type")))
                {
                    var x = cNoDefAttributes.ToArray();

                }

                var cMissingAttributes = def.CheckMissingAttributes(this).ToArray();

                var elementQtyResults = def.CheckChildQuantity(this).ToArray();




                return elementQtyResults.Union(cNoDefElements)
                    .Union(cMissingAttributes).Union(cNoDefAttributes).Union( cNoDefAttributes_parent);

            }
        }

        public override List<ValidationResult<gxBaseE<ContentBaseE>>> Validate(List<ValidationResult<gxBaseE<ContentBaseE>>> result = null)
        {

            var structRes = ValidateStructure().
                Select(p => new SchoxValidationResultBridge(p) as ValidationResult<gxBaseE<ContentBaseE>>).ToList();

            if ( result == null)
            {
                result = structRes;
            }
            else
            {
                foreach (var s in structRes)
                    result.Add(s);
            }

            return base.Validate(result);
        }


        public SchoxValidationResult ValidateValue(string value)
        {
            if (this.ChildrenEs.Count() > 0)
                throw new tUtil.Exception.InconsistentException($"method {nameof(ValidateValue)} should NOT be called by complex element ");

            if (this.AttachedSchoxDef == null)
                throw new tUtil.Exception.InconsistentException($"method {nameof(ValidateValue)} should be called ONLY by element with {nameof(AttachedSchoxDef)}");


            var result = this.AttachedSchoxDef.ValidateValue(value);
            result.ContentNode = this;
            return result;



        }

        public void AddPin(string targetAttribName = null)
        {
            var xa = this.OwnerDocument.CreateAttribute(consts.DoxCONST.ESC_PREFIX, consts.DoxCONST.PINPOINT, null);
            xa.Value = targetAttribName;
            this.Attributes.Append(xa);
        }

        public void RemovePin()
        {
            var xa = this.Attributes[ContentDox.PINPOINT_ATTNAME];
            if (xa != null)
            {
                this.RemoveAttribute(ContentDox.PINPOINT_ATTNAME);
            }
        }

        public ContentBaseE getExpandContent(int expandLevel)
        {
            if (expandLevel <= 0)
                return this;

            ContentBaseE result = this;

            for (int i = 0; i < expandLevel; i++)
            {
                result = result.ParentNode as ContentBaseE;
            }
            return result;
        }

        protected IEnumerable<defaultE> ChildEntityDefs => (AttachedSchoxDef as  SchDefE).ChildEntityDefs;


        [ValidatorAttrib]
        public ValidationResult<gxBaseE<ContentBaseE>> validate_value()
        {
            if (this.AttachedSchoxDef == null || !this.AttachedSchoxDef.IsValueType || this.ChildrenEs.Count() > 0)
                return null;

            var result = ValidateValue(this.SelfInnerText());
            if (result.ResultType != SchoxValidationResultType.success)
                return new SchoxValidationResultBridge(result);
            else
                return null;
        }


        [ValidatorAttrib(IsMultiple =true)]
        public IEnumerable< ValidationResult<gxBaseE<ContentBaseE>> > validate_Attributes()
        {
            if (this.AttachedSchoxDef == null )
                return null;

            var r1 = from a in this.Attributes.Cast<ContentAttribute>()
                     where a.AttachedSchoxDef != null
                     let b = a.AttachedSchoxDef.ValidateValue(a.Value)
                     where b != null && b.ResultType != SchoxValidationResultType.success
                     select
                     new SchoxValidationResultBridge(
                         new SchoxValidationResult()
                         {
                             ResultType = b.ResultType,
                             ContentNode = a
                         }
                     );

            return r1;
        }


        public IEnumerable<SchDefE> Appendables
        {
            get
            {
                var def = this.AttachedSchoxDef as SchDefE;
                if (def == null)
                    return null;
                var attrs = def.GetAttributesAppendable(this).Cast<SchDefE>();
                var childDefs = (from c in def.ChildEntityDefs
                                 let q = c.GetAvailableQuota(this)
                                 where q == null || q > 0  
                                 select c).Cast<SchDefE>();


                var uniques = def.ChildrenUniqueNames.Cast<SchDefE>();

                //if (def.RefDelcaredType == null)
                //    Console.WriteLine("null " + def.Name);

                //var refDefs = def.RefDelcaredType?.ChildrenEs.Cast<SchDefE>();

                return attrs.Union(childDefs).Union(uniques); //.Union( refDefs?? Enumerable.Empty<SchDefE>());

            }
        }

        public XElement QuotaXView => new XElement(nameof(QuotaXView),
            new XAttribute("ContentNode", this.LocalName),
            (this.AttachedSchoxDef as defaultE)?.ChildEntityDefs.Select(p =>
                        new XElement(p.Name,
                                new XAttribute(nameof(p.GetAvailableQuota),
                                                (p.GetAvailableQuota(this).toNonNullString())
                                    )
                            )
                ),
            (this.AttachedSchoxDef as defaultE)?.GetAttributesAppendable(this).Select(p =>
                    new XElement("AttributeAppendable", p.TargetAttributeName))
            //,this.Attributes.Cast<XmlAttribute>().Select( q => new XElement( "ContentAttribute", q.Name))
            );

        public new string Value { get => this.SelfInnerText(); set => this.InnerText = value; }
        //string IContentNode.Name => this.Name;
    }
}
