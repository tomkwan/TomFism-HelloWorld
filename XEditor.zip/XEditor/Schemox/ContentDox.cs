﻿using DoGx;
using Schemox.Basics;
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using tUtil.Exception;
using tUtil.xml;

namespace Schemox
{
    public class ContentDox : SimpleDox<ContentBaseE, ContentRoot> 
    {
        public readonly Schox LeSchox;
        public ContentDox(Schox leSchox) : base()
        {
            this.LeSchox = leSchox;
        }

        public override XmlAttribute CreateAttribute(string prefix, string localName, string namespaceURI)
        {
            return new ContentAttribute  (prefix, localName, namespaceURI, this);
        }

        public override void Load(XmlReader reader)
        {
            base.Load(reader);

            ContentRoot contentRoot = this.root as ContentRoot;

            if (contentRoot == null)
                throw new EmptyException("unexpected null root after loading dox");

            root defRoot = this.LeSchox.root as root;

            if ( defRoot == null )
                throw new EmptyException("unexpected null schox root ");


        }

        public static string PINPOINT_ATTNAME => $"{consts.DoxCONST.ESC_PREFIX}:{consts.DoxCONST.PINPOINT}";

        public IContentNode FirstPinPoint
        {
            get
            {
                
                var ce = root.NsSelectSingle($"//*[@{PINPOINT_ATTNAME}]") as ContentBaseE;
                if (ce == null)
                    return null;

                var pinXa = ce.Attributes[PINPOINT_ATTNAME];

                string targetXa = pinXa.Value;

                if (string.IsNullOrEmpty(targetXa))
                    return ce;
                else
                {
                    var xa = ce.Attributes[targetXa];
                    if (xa == null)
                        throw new tUtil.Exception.EmptyException($"the target pin-point attribute @{targetXa} NOT found");
                    else
                        return xa as IContentNode;
                }

            }
        }
            
    }
}
