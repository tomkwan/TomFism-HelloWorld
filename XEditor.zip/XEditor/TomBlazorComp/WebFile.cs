﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components.WebAssembly.Http;
using tUtil.Exception;

using static System.Net.WebRequestMethods;

namespace TomBlazorComp
{
    public class WebFile : tUtil.FileIO.RemotableFile
    {

        protected MemoryStream  CacheStream;

        protected string Url;

        protected Task<HttpResponseMessage> readTask;

        public WebFile(string url)
        {
            Url = url;
        }

        public override Stream Read()
        {
            if (this.CacheStream == null)
                throw new InconsistentException("CacheStream is null : pls call CacheFiles before reading stream ");

            this.CacheStream.Position = 0;
            return CacheStream;
        }

        public void ReplaceCache ( string content)
        {
            MemoryStream ms = new MemoryStream();
            StreamWriter sw = new StreamWriter(ms);
            sw.Write(content);
            sw.Flush();
            this.CacheStream = ms;
        }
        public void ReplaceCache(MemoryStream ms)
        {
            this.CacheStream = ms;
        }


        public async static Task CacheFiles(IEnumerable<WebFile> webFiles, HttpClient http)
        {

            foreach (var wf in webFiles)
            {
                using var Req_content = new HttpRequestMessage(HttpMethod.Get, wf.Url);
                Req_content.SetBrowserRequestCache(BrowserRequestCache.NoCache);

                wf.readTask = http.SendAsync(Req_content);
                
            }

            await Task.WhenAll( webFiles.Select( p => p.readTask) );

            foreach (var wf in webFiles)
            {
                Stream sm = wf.readTask.Result.Content.ReadAsStream();
                wf.CacheStream = new MemoryStream();
                sm.CopyTo(wf.CacheStream);

            }

            //return Task.CompletedTask;
        }


    }
}
