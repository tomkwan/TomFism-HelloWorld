﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;

namespace TomBlazorComp.KeyNavigator
{
    public abstract class NavigatableBase : ComponentBase, INavigatable
    {

        protected ElementReference FocusingElement;

        [Inject]
        protected Navigator LeNavigator { get; set; }

        [Inject]
        protected IJSRuntime JS { get; set; }

        [CascadingParameter]
        protected ClickArea HostClickArea { get; set; }


        public abstract string NavigatableId { get; }
        public string AreaId
        {
            get
            {
                if (HostClickArea == null)
                    return null;

                return HostClickArea.AreaId;
            }
        }

        protected override void OnParametersSet()
        {
            base.OnParametersSet();
            this.LeNavigator.AddNavigatable(this);
        }

        public async virtual void SetFocus(bool skipJsFocuseArea = false)
        {
            await JS.InvokeVoidAsync("setFocus", this.FocusingElement);
             await JS.InvokeVoidAsync("setCurrentArea", AreaId);

        }

    }
}
