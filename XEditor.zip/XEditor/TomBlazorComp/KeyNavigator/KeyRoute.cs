﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TomBlazorComp.KeyNavigator
{
    public class KeyRoute
    {
        public string ObservorId;
        public string ObserveeId;
        public KeyCombination Keys;
        public Func<object, bool> MatchingHandler;

        public KeyRoute(string observorId, string observeeId, KeyCombination keys, Func<object, bool> matchingHandler = null)
        {
            ObservorId = observorId;
            ObserveeId = observeeId;
            this.Keys = keys;
            MatchingHandler = matchingHandler;
        }
    }
}
