﻿using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Blazored.LocalStorage;
namespace TomBlazorComp.KeyNavigator
{
    public class Navigator
    {
        Dictionary<string, ClickAreaBase> ClickAreas = new Dictionary<string, ClickAreaBase>();

        Dictionary<string, INavigatable> Navigatables = new Dictionary<string, INavigatable>();

        public IEnumerable<KeyRoute> KeyRoutes;

        public Dictionary<KeyCombination, Action> GlobalKeyActions = new Dictionary<KeyCombination, Action>();


        public IJSRuntime JS { get; set; }

        public Blazored.LocalStorage.ISyncLocalStorageService LocalStorage { get; set; }

        public Navigator(IJSRuntime jS)
        {
            JS = jS;
            STATIC_INSTANCE = this;
        }


        public INavigatable FindMatchingNavigatable(ClickAreaBase fromArea, KeyCombination keys, object sender)
        {
            if (this.KeyRoutes == null)
                return null;



            var validNavigatables = from n in this.Navigatables
                                    where n.Value != null
                                    select n.Value;
            var validRoutes = (from r in KeyRoutes
                              join n in validNavigatables
                              on r.ObservorId equals n.NavigatableId
                              select new
                              {
                                  route = r,
                                  obeservor = n
                              }).ToArray();

            //Console.WriteLine("Navigatables");
            //foreach (var x in Navigatables)
            //{
            //    Console.WriteLine(x.Key);
            //}


            //Console.WriteLine("routes ");
            //foreach (var x in KeyRoutes )
            //{
            //    Console.WriteLine(x.ObservorId);
            //}


            //Console.WriteLine("validRoutes:");
            //foreach ( var x in validRoutes)
            //{
            //    Console.WriteLine(x.route.ObserveeId);
            //}


            var firstMatch = (from vr in validRoutes
                              let obserserveeId = vr?.route?.ObserveeId
                              let matcher = vr.route.MatchingHandler
                              where
                              ( string.IsNullOrEmpty(obserserveeId) ? true : obserserveeId == fromArea.AreaId) &&
                              ( vr.route.MatchingHandler == null ? true : vr.route.MatchingHandler(sender) ) &&
                              vr.route.Keys.Equals(keys)
                              select vr.obeservor
                             ).FirstOrDefault();



            return firstMatch;

        }



        public void AddNavigatable (  INavigatable navigatable)
        {
            if (this.Navigatables.ContainsKey(navigatable.NavigatableId))
            {
                this.Navigatables[navigatable.NavigatableId] = navigatable;
            }
            else
                this.Navigatables.Add(navigatable.NavigatableId, navigatable);

            this.refreshJSInfo();
        }

        public void AddArea(ClickAreaBase area)
        {
            this.ClickAreas.Add(area.AreaId, area);
            this.refreshJSInfo();
        }

        public void RemoveArea ( string AreaId)
        {
            if (this.ClickAreas.ContainsKey(AreaId))
            {
                ClickAreas.Remove(AreaId);
                this.refreshJSInfo();

            }
        }

        async void   refreshJSInfo ()
        {
            LocalStorage.SetItem("JsAreaKeyInfos", this.JsAreaKeyInfos);
            await JS.InvokeVoidAsync("CreateClickAreas");

        }

        public IEnumerable<JsAreaKeyInfo> JsAreaKeyInfos
        {
            get
            {
                //var flatAreaKeys = from c in ClickAreas.Values.Where( p => p?.KeyActions != null).Select( p => p)
                //                   from k in c.KeyActions
                //                   select new
                //                   {
                //                       AreaId = c.AreaId,
                //                       Keys = k.Key
                //                   };

                List<Tuple<string, KeyCombination>> areas = new List<Tuple<string, KeyCombination>>();
                foreach ( var c in ClickAreas.Values)
                {
                    if (c != null && c.KeyActions != null )
                    {
                        foreach ( var k in c.KeyActions)
                        {
                            areas.Add(new Tuple<string, KeyCombination> ( c.AreaId, k.Key));
                        }
                    }
                }

                var flatAreaKeys = areas.Select( k => new
                {
                    AreaId = k.Item1,
                    Keys = k.Item2
                });

                //var x = flatAreaKeys.ToArray();
                var observeeKeyRoutes = from k in KeyRoutes
                                            //where k.ObserveeId 
                                        select new
                                        {
                                            AreaId = k.ObserveeId,
                                            Keys = k.Keys
                                        };
                var y = observeeKeyRoutes.ToArray();




                var allRoutes = flatAreaKeys.Union(observeeKeyRoutes).Union(
                    GlobalKeyActions.Keys.Select(p => new { AreaId = "", Keys = p}));

                    //Append( new {AreaId ="", Keys = GlobalKeyActions.Keys });


                var areaRoutes = from r in allRoutes
                                 group r by r.AreaId into g
                                 select new JsAreaKeyInfo(
                                     g.Key,
                                     g.Select( p => p.Keys)
                                     );

                var z = areaRoutes.ToArray();
                return z;
            }
        }


        public string FocusAreaCss = "FocusArea";

        ClickAreaBase focusArea;

        public bool ModalMode = false;


        public async void SetModalMode( bool mode, bool jsSet= false)
        {
            this.ModalMode = mode;
            if ( jsSet )
                await JS.InvokeVoidAsync("SetModalMode", false);

        }



        public void SetFoucusArea(string AreaId, bool skipJsFocuseArea = false)
        {

            if (string.IsNullOrEmpty(AreaId))
                focusArea = null;
            else
            {
                focusArea = ClickAreas[AreaId];
                //focusArea.SetFocus(skipJsFocuseArea);
            }

            FireFocusAreaChanged();


        }

        public bool InFocus ( ClickAreaBase area)
        {
            return this.focusArea == area;
        }


        public event EventHandler FocusAreaChanged;

        void FireFocusAreaChanged()
        {
            if (this.FocusAreaChanged != null)
            {
                EventArgs e = new EventArgs();
                FocusAreaChanged(this, e);
            }

        }

        static TomBlazorComp.KeyNavigator.Navigator STATIC_INSTANCE;

        [JSInvokable]
        public static Task FocusArea(string AreaId)
        {

            //Console.WriteLine("ASM got id " + AreaId);
              Navigator.STATIC_INSTANCE.SetFoucusArea(AreaId);

            return Task.CompletedTask;
        }


    }
}
