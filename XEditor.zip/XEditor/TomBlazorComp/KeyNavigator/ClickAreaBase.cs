﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.JSInterop;

namespace TomBlazorComp.KeyNavigator
{
    public class ClickAreaBase : ComponentBase, INavigatable, IDisposable
    {
        [Inject]
        protected Navigator LeNavigator { get; set; }

        [Inject]
        protected IJSRuntime JS { get; set; }


        protected ElementReference DivRef;

        public const string AREA_POSTFIX = "_ClickArea";

        public string NavigatableId => this.AreaId;

        [Parameter]
        public Func<object> ObservingSenderHandler { get; set; }

        protected virtual void DivKeyDown(KeyboardEventArgs e)
        {
            if (LeNavigator.InFocus(this) && !LeNavigator.ModalMode)
            {
                if (!KeyCombination.KEY_CODES.ContainsKey(e.Code))
                {
                    Console.WriteLine("key not found in dict : " + e.Key);
                    Console.WriteLine(e.Code);
                    return;
                }

                KeyCombination k = new KeyCombination(KeyCombination.KEY_CODES[e.Code], e.CtrlKey, e.AltKey, e.ShiftKey);



                if (KeyActions != null && KeyActions.ContainsKey(k))
                {
                    KeyActions[k]();
                    return;
                }
                if (LeNavigator.GlobalKeyActions.ContainsKey(k))
                {
                    LeNavigator.GlobalKeyActions[k]();
                    return;

                }

                object senderObj = this.ObservingSenderHandler == null ? null : this.ObservingSenderHandler();
                INavigatable navigateTo = LeNavigator.FindMatchingNavigatable(this, k, senderObj);
                if (navigateTo != null)
                {
                    LeNavigator.SetFoucusArea(navigateTo.AreaId);
                    navigateTo.SetFocus();
                }

            }
        }


        [Parameter]
        public virtual RenderFragment ChildContent { get; set; }

        [Parameter]
        public virtual string style { get; set; }

        [Parameter]
        public virtual Dictionary<KeyCombination, Action> KeyActions { get; set; }

        [Parameter]
        public virtual string AreaName { get; set; }

        protected string backgroundCss => LeNavigator.InFocus(this) ? LeNavigator.FocusAreaCss : "";

        public string AreaId => AreaName + AREA_POSTFIX;

        bool added2Navigator = false;
        protected override void OnParametersSet()
        {

            base.OnParametersSet();
            if (!added2Navigator)
            {
                LeNavigator.AddArea(this);
                this.LeNavigator.AddNavigatable(this);

                added2Navigator = true;
            }

        }

        //public void SetFocus ()
        //{
        //    JS.InvokeAsync<bool>("setFocus", this.DivRef);
        //    JS.InvokeAsync<bool>("setCurrentArea", AreaId);
        //    //SetAsCurrentArea();
        //}

        protected override void OnAfterRender(bool firstRender)
        {
            base.OnAfterRender(firstRender);
            if (firstRender)
            {
                ObjectReference = DotNetObjectReference.Create(this);
            }
        }

        public async virtual void SetFocus(bool skipJsFocuseArea = false)
        {
            if ( ! skipJsFocuseArea)
                await JS.InvokeVoidAsync("setFocus", this.DivRef);

            await JS.InvokeVoidAsync("setCurrentArea", AreaId);

        }
        DotNetObjectReference<ClickAreaBase> ObjectReference;

        public void Dispose()
        {
            //Console.WriteLine("area disposed");
            LeNavigator.RemoveArea(AreaId);
            GC.SuppressFinalize(this);

            if (ObjectReference != null)
            {
                //Now dispose our object reference so our component can be garbage collected
                ObjectReference.Dispose();
            }
        }



        

    }
}
