﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TomBlazorComp.KeyNavigator
{
    public class KeyDownEventArg :EventArgs
    {
        public object CoreObj;

        public KeyDownEventArg(object coreObj)
        {
            CoreObj = coreObj;
        }
    }
}
