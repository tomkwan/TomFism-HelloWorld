﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TomBlazorComp.KeyNavigator
{
    public  class JsAreaKeyInfo
    {
        public string areaId { get; set; }
        public KeyCombination[] keys { get; set; }

        public JsAreaKeyInfo(string areaId, IEnumerable<KeyCombination> keys)
        {
            this.areaId = areaId;
            if (keys != null)
                this.keys = keys.ToArray();
        }
    }
}
