﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using tUtil.DataStructure.Linq;

namespace TomBlazorComp.KeyNavigator
{
     public abstract class IncrementalAreaBase<T>: ClickAreaBase
    {


        public virtual KeyCombination IncremtKey => new KeyCombination("ArrowDown");
        public virtual KeyCombination DecremtKey => new KeyCombination("ArrowUp");

        public virtual Dictionary<KeyCombination, Action> OtherKeyActions { get; }


        public virtual void IncrementAction()
        {
            
             var c = this.Items.ToList().Next(this.CurrentItem);
            if (c != null)
                this.CurrentItem = c;
        }
        public virtual void DecrementAction()
        {
            var c = this.Items.ToList().Previous(this.CurrentItem);
            if (c != null)
                this.CurrentItem = c;

        }

        public override Dictionary<KeyCombination, Action> KeyActions { 
            get
            {
                Dictionary<KeyCombination, Action> d = new Dictionary<KeyCombination, Action>();
                d.Add(this.IncremtKey, IncrementAction);
                d.Add(this.DecremtKey, DecrementAction);


                var e = (base.KeyActions == null) ? d: d.Concat(base.KeyActions).ToDictionary(p => p.Key, p => p.Value);
                var f = (this.OtherKeyActions == null) ? e : e.Concat(OtherKeyActions).ToDictionary(p => p.Key, p => p.Value);

                return f;

            }
            
            set => base.KeyActions = value; 
        }

        protected abstract IEnumerable<T> Items { get; }

        public virtual T CurrentItem { get; set; }


    }
}
