﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TomBlazorComp.KeyNavigator
{
    public class JsNavMiddleMan
    {

        public bool IsModalMode { get; set; }
        public string FocusingAreaId { get; set; }
        public IEnumerable<JsAreaKeyInfo> AreaInfo { get; set; }

        public JsNavMiddleMan(bool isModalMode, string focusingAreaId, IEnumerable<JsAreaKeyInfo> areaInfo)
        {
            IsModalMode = isModalMode;
            FocusingAreaId = focusingAreaId;
            AreaInfo = areaInfo;
        }
    }
}
